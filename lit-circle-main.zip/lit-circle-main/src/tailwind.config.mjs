/** @type {import('tailwindcss').Config} */
export default {
    content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}', './public/**/*.html'],
    theme: {
        extend: {
            fontSize: {
                xs: ['0.75rem', { lineHeight: '1.2', letterSpacing: '0.02em', fontWeight: '400' }],
                sm: ['0.875rem', { lineHeight: '1.3', letterSpacing: '0.02em', fontWeight: '400' }],
                base: ['1rem', { lineHeight: '1.5', letterSpacing: '0.02em', fontWeight: '400' }],
                lg: ['1.125rem', { lineHeight: '1.5', letterSpacing: '0.01em', fontWeight: '600' }],
                xl: ['1.5rem', { lineHeight: '1.4', letterSpacing: '0em', fontWeight: '700' }],
                '2xl': ['2rem', { lineHeight: '1.3', letterSpacing: '-0.01em', fontWeight: '700' }],
                '3xl': ['2.5rem', { lineHeight: '1.2', letterSpacing: '-0.02em', fontWeight: '800' }],
                '4xl': ['3rem', { lineHeight: '1.1', letterSpacing: '-0.03em', fontWeight: '800' }],
                '5xl': ['3.75rem', { lineHeight: '1.1', letterSpacing: '-0.04em', fontWeight: '900' }],
                '6xl': ['4.5rem', { lineHeight: '1.05', letterSpacing: '-0.05em', fontWeight: '900' }],
                '7xl': ['5.5rem', { lineHeight: '1.05', letterSpacing: '-0.06em', fontWeight: '900' }],
                '8xl': ['6.5rem', { lineHeight: '1', letterSpacing: '-0.07em', fontWeight: '900' }],
                '9xl': ['8rem', { lineHeight: '1', letterSpacing: '-0.08em', fontWeight: '900' }],
            },
            fontFamily: {
                heading: "avenir-lt-w01_85-heavy1475544",
                paragraph: "baskervillemtw01-smbdit"
            },
            colors: {
                subtleborder: '#E2E8F0',
                mutedgray: '#94A3B8',
                foreground: '#1E293B',
                background: '#FFFFFF',
                secondary: '#475569',
                'secondary-foreground': '#FFFFFF',
                'primary-foreground': '#FFFFFF',
                primary: '#1E40AF'
            },
            screens: {
                'xs': '475px',
                'sm': '640px',
                'md': '768px',
                'lg': '1024px',
                'xl': '1280px',
                '2xl': '1536px',
                '3xl': '1600px',
                // Mobile-specific breakpoints
                'mobile-sm': '320px',
                'mobile-md': '375px',
                'mobile-lg': '414px',
                // Tablet-specific breakpoints
                'tablet-sm': '768px',
                'tablet-lg': '1024px',
                // Desktop-specific breakpoints
                'desktop-sm': '1280px',
                'desktop-lg': '1440px',
                'desktop-xl': '1920px',
                // Landscape orientation support
                'landscape': {'raw': '(orientation: landscape)'},
                'portrait': {'raw': '(orientation: portrait)'},
            },
            spacing: {
                '18': '4.5rem',
                '88': '22rem',
                '128': '32rem',
            },
            minHeight: {
                'screen-75': '75vh',
                'screen-50': '50vh',
            },
            maxWidth: {
                '8xl': '88rem',
                '9xl': '96rem',
                '10xl': '104rem',
                'mobile': '100vw',
                'tablet': '768px',
                'desktop': '1200px',
                'wide': '1600px',
                'ultra-wide': '1920px',
            },
        },
    },
    future: {
        hoverOnlyWhenSupported: true,
    },
    plugins: [require('@tailwindcss/container-queries'), require('@tailwindcss/typography')],
}
