import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { PopularBooks, UserBookSubmissions, BookDiscussionVideos, LiveDiscussionSessions } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Image } from '@/components/ui/image';
import { AdBanner } from '@/components/ui/ad-banner';
import { SubscriptionPrompt } from '@/components/ui/subscription-prompt';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ExitFeedbackPrompt } from '@/components/ui/exit-feedback-prompt';
import { ContentRatingWidget } from '@/components/ui/content-rating-widget';
import { ArrowLeft, BookOpen, Star, Upload, Video, Calendar, Users, Search, Play, Clock, Eye, Mic, Image as ImageIcon, Crown, Lock, Unlock, FileText, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';
import { useContentTranslator } from '@/lib/content-translator';
import { useExitFeedback } from '@/hooks/use-exit-feedback';
import { useScreenshotProtection } from '@/hooks/use-screenshot-protection';
import { useMember } from '@/integrations';

export default function LibraryPage() {
  const { t, currentLanguage } = useTranslation();
  const { translateArray } = useContentTranslator();
  const { member, isAuthenticated } = useMember();
  const [popularBooks, setPopularBooks] = useState<PopularBooks[]>([]);
  const [userSubmissions, setUserSubmissions] = useState<UserBookSubmissions[]>([]);
  const [discussionVideos, setDiscussionVideos] = useState<BookDiscussionVideos[]>([]);
  const [liveSessions, setLiveSessions] = useState<LiveDiscussionSessions[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPremiumPrompt, setShowPremiumPrompt] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState<UserBookSubmissions | null>(null);
  const [userPurchases, setUserPurchases] = useState<string[]>([]);
  const [expandedSubmissions, setExpandedSubmissions] = useState<Set<string>>(new Set());
  const [uploadedBooks, setUploadedBooks] = useState<Map<string, string>>(new Map()); // Map of bookId -> PDF URL
  const [selectedPdfUrl, setSelectedPdfUrl] = useState<string | null>(null);
  const [showPdfViewer, setShowPdfViewer] = useState(false);

  // Exit feedback hook
  const { showFeedbackPrompt, trackInteraction, closeFeedbackPrompt } = useExitFeedback({
    featureName: 'Library',
    triggerOnRouteChange: true,
    triggerOnBeforeUnload: true,
    cooldownMinutes: 30
  });

  // Screenshot protection for library content
  useScreenshotProtection({
    enableBlur: true,
    enableWatermark: true,
    enableKeyboardBlocking: true,
    enableDevToolsBlocking: true,
    enableRightClickBlocking: true,
    showWarningMessage: true
  });

  useEffect(() => {
    const fetchLibraryData = async () => {
      try {
        const [booksResult, submissionsResult, videosResult, sessionsResult] = await Promise.all([
          BaseCrudService.getAll<PopularBooks>('popularbooks'),
          BaseCrudService.getAll<UserBookSubmissions>('userbooksubmissions'),
          BaseCrudService.getAll<BookDiscussionVideos>('bookdiscussionvideos'),
          BaseCrudService.getAll<LiveDiscussionSessions>('livediscussionsessions')
        ]);

        // Filter only approved submissions
        const approvedSubmissions = submissionsResult.items.filter(
          submission => submission.moderationStatus === 'Approved'
        );

        // Translate content based on current language
        const [translatedBooks, translatedSubmissions, translatedVideos, translatedSessions] = await Promise.all([
          translateArray(booksResult.items, ['title', 'author', 'synopsis', 'genre'], currentLanguage),
          translateArray(approvedSubmissions, ['submissionTitle', 'content', 'bookTitle', 'bookAuthor', 'submissionType'], currentLanguage),
          translateArray(videosResult.items, ['videoTitle', 'description', 'associatedTopic'], currentLanguage),
          translateArray(sessionsResult.items, ['sessionTopic', 'sessionDescription', 'discussedBook'], currentLanguage)
        ]);

        setPopularBooks(translatedBooks);
        setUserSubmissions(translatedSubmissions);
        setDiscussionVideos(translatedVideos);
        setLiveSessions(translatedSessions);

        // Load user purchases if authenticated
        if (isAuthenticated && member?.loginEmail) {
          const { items: purchases } = await BaseCrudService.getAll('contentpurchases');
          const userPurchaseIds = purchases
            .filter(p => p.userId === member.loginEmail && p.accessStatus === 'active')
            .map(p => p.contentId);
          setUserPurchases(userPurchaseIds);
        }
      } catch (error) {
        console.error('Error fetching library data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchLibraryData();
  }, [currentLanguage, translateArray, isAuthenticated, member]);

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const handlePremiumContentAccess = async (submission: UserBookSubmissions) => {
    if (!isAuthenticated) {
      alert('Please sign in to access premium content');
      return;
    }

    if (userPurchases.includes(submission._id)) {
      // User has already purchased this content
      setSelectedSubmission(submission);
      return;
    }

    // Show purchase modal or redirect to payment
    const confirmPurchase = confirm(`This is premium content. Purchase access for ₹${submission.price}/month?`);
    if (confirmPurchase) {
      try {
        // Create purchase record
        const purchase = {
          _id: crypto.randomUUID(),
          userId: member?.loginEmail || '',
          contentId: submission._id,
          purchaseDate: new Date().toISOString(),
          pricePaid: submission.price || 0,
          accessStatus: 'active'
        };
        
        await BaseCrudService.create('contentpurchases', purchase);
        setUserPurchases(prev => [...prev, submission._id]);
        setSelectedSubmission(submission);
        alert('Content unlocked successfully!');
      } catch (error) {
        console.error('Error purchasing content:', error);
        alert('Failed to purchase content. Please try again.');
      }
    }
  };

  const canAccessContent = (submission: UserBookSubmissions) => {
    if (!submission.isPremium) return true;
    if (!isAuthenticated) return false;
    return userPurchases.includes(submission._id) || submission.submittedBy === member?.profile?.nickname;
  };

  const toggleContentExpansion = (submissionId: string) => {
    setExpandedSubmissions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(submissionId)) {
        newSet.delete(submissionId);
      } else {
        newSet.add(submissionId);
      }
      return newSet;
    });
  };

  const isContentExpanded = (submissionId: string) => {
    return expandedSubmissions.has(submissionId);
  };

  const renderStars = (rating: number | undefined) => {
    if (!rating) return null;
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="w-3 h-3 sm:w-4 sm:h-4 fill-yellow-400 text-yellow-400" />);
    }
    
    if (hasHalfStar) {
      stars.push(<Star key="half" className="w-3 h-3 sm:w-4 sm:h-4 fill-yellow-400/50 text-yellow-400" />);
    }
    
    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="w-3 h-3 sm:w-4 sm:h-4 text-gray-300" />);
    }
    
    return <div className="flex items-center gap-0.5 sm:gap-1">{stars}</div>;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="text-center">
          <BookOpen className="w-10 h-10 sm:w-12 sm:h-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="font-paragraph text-secondary italic text-sm sm:text-base">Loading library...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar Ad - Hidden on mobile and tablet */}
      <div className="fixed left-2 sm:left-4 top-1/2 transform -translate-y-1/2 z-10 hidden 2xl:block">
        <AdBanner size="sidebar" />
      </div>

      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background relative overflow-hidden">
        {/* Background Library Image */}
        <div className="absolute inset-0 opacity-10">
          <Image
            src="https://static.wixstatic.com/media/179bf7_94d54855e1984d34991d3bf0200fb178~mv2.png?id=library-background"
            alt="Modern university library interior with students studying, bookshelves filled with books, natural lighting through large windows"
            width={1200}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative max-w-[100rem] mx-auto px-3 sm:px-4 md:px-6 lg:px-8 py-3 sm:py-4 md:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3 md:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start px-2 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm" onClick={trackInteraction}>
              <Link to="/">
                <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Back to Home</span>
                <span className="sm:hidden">Back</span>
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-5 sm:h-6 bg-subtleborder"></div>
            <div className="flex items-center gap-2 sm:gap-3 flex-1">
              <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 text-primary flex-shrink-0" />
              <h1 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase tracking-wide truncate">
                Digital Library
              </h1>
            </div>
            
            {/* Decorative Book Stack Image - Hidden on mobile */}
            <div className="hidden lg:block flex-shrink-0">
              <Image
                src="https://static.wixstatic.com/media/179bf7_3ac7c77e338b424fa83cbc92069b85d3~mv2.png?id=books-stack"
                alt="Stack of classic and modern books on a wooden table, open book with pages turning, warm lighting, academic setting"
                width={60}
                className="opacity-80 h-12 w-auto"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-3 sm:px-4 md:px-6 lg:px-8 py-6 sm:py-8 md:py-12 lg:py-16">
        <div className="space-y-6 sm:space-y-8 md:space-y-12">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-3 sm:space-y-4 md:space-y-6"
          >
            {/* Hero Image Section */}
            <div className="relative mb-4 sm:mb-6 md:mb-8">
              <div className="aspect-[5/2] w-full max-w-4xl mx-auto rounded-lg sm:rounded-xl md:rounded-2xl overflow-hidden">
                <Image
                  src="https://static.wixstatic.com/media/179bf7_94d54855e1984d34991d3bf0200fb178~mv2.png?id=library-hero-main"
                  alt="Modern university library interior with students studying, bookshelves filled with books, natural lighting through large windows, academic atmosphere"
                  width={1000}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <div className="text-center text-white space-y-2 sm:space-y-3 px-4">
                    <h2 className="font-heading text-lg sm:text-2xl md:text-3xl lg:text-4xl uppercase tracking-tight">
                      Literary Resources Hub
                    </h2>
                    <p className="font-paragraph text-xs sm:text-sm md:text-base italic max-w-2xl mx-auto opacity-90">
                      Discover popular books, share your readings and summaries, watch discussion videos, 
                      and join live literary conversations with fellow hostel scholars.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Search Bar */}
            <div className="relative max-w-md mx-auto px-2 sm:px-4">
              <Search className="absolute left-4 sm:left-6 top-1/2 transform -translate-y-1/2 w-3.5 h-3.5 sm:w-4 sm:h-4 text-mutedgray" />
              <Input
                placeholder="Search books, videos, sessions..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  trackInteraction();
                }}
                className="pl-9 sm:pl-12 border-subtleborder focus:border-primary font-paragraph text-xs sm:text-sm py-2 sm:py-2.5"
              />
            </div>
          </motion.div>

          {/* Library Tabs */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Tabs defaultValue="popular-books" className="space-y-4 sm:space-y-6 md:space-y-8">
              <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 bg-mutedgray/10 p-1 rounded-lg gap-0.5 sm:gap-0">
                <TabsTrigger 
                  value="popular-books" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-1.5 sm:px-2 py-1.5 sm:py-2"
                  onClick={trackInteraction}
                >
                  <span className="hidden sm:inline">Popular Books</span>
                  <span className="sm:hidden">Books</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="user-submissions" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-1.5 sm:px-2 py-1.5 sm:py-2"
                  onClick={trackInteraction}
                >
                  <span className="hidden sm:inline">User Content</span>
                  <span className="sm:hidden">Content</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="discussion-videos" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-1.5 sm:px-2 py-1.5 sm:py-2"
                  onClick={trackInteraction}
                >
                  <span className="hidden sm:inline">Videos</span>
                  <span className="sm:hidden">Video</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="live-sessions" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-1.5 sm:px-2 py-1.5 sm:py-2"
                  onClick={trackInteraction}
                >
                  <span className="hidden sm:inline">Live Sessions</span>
                  <span className="sm:hidden">Live</span>
                </TabsTrigger>
              </TabsList>

              {/* Popular Books Tab */}
              <TabsContent value="popular-books" className="space-y-4 sm:space-y-6 md:space-y-8">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4">
                  <h3 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase tracking-wide text-center sm:text-left">
                    World's Most Popular Books
                  </h3>
                </div>

                {/* Premium Content Prompt */}
                {showPremiumPrompt && (
                  <SubscriptionPrompt 
                    trigger="premium-feature"
                    onDismiss={() => setShowPremiumPrompt(false)}
                  />
                )}

                {/* Inline Ad */}
                <div className="flex justify-center">
                  <AdBanner size="rectangle" />
                </div>

                {popularBooks.length > 0 ? (
                  <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
                    {popularBooks.map((book, index) => (
                      <motion.div
                        key={book._id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                      >
                        <Card className="h-full border-subtleborder hover:border-primary transition-colors duration-300 bg-background">
                          <CardHeader className="space-y-2 sm:space-y-3 p-3 sm:p-4 md:p-6">
                            {book.coverImage && (
                              <div className="aspect-[3/4] w-full rounded-lg overflow-hidden">
                                <Image
                                  src={book.coverImage}
                                  alt={`Cover of ${book.title}`}
                                  width={200}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            )}
                            <div className="space-y-1 sm:space-y-2">
                              <CardTitle className="font-heading text-xs sm:text-sm md:text-lg text-primary uppercase tracking-wide line-clamp-2">
                                {book.title}
                              </CardTitle>
                              <CardDescription className="font-paragraph text-xs sm:text-sm text-secondary italic line-clamp-1">
                                by {book.author}
                              </CardDescription>
                            </div>
                          </CardHeader>
                          
                          <CardContent className="space-y-2 sm:space-y-3 p-3 sm:p-4 md:p-6 pt-0">
                            <div className="flex items-center justify-between gap-2 text-xs sm:text-sm">
                              <Badge variant="outline" className="font-paragraph text-xs truncate">
                                {book.genre}
                              </Badge>
                              <span className="font-paragraph text-xs text-secondary italic flex-shrink-0">
                                {book.publicationYear}
                              </span>
                            </div>
                            
                            {book.averageRating && (
                              <div className="flex items-center gap-1 sm:gap-2">
                                {renderStars(book.averageRating)}
                                <span className="font-paragraph text-xs sm:text-sm text-secondary italic">
                                  {book.averageRating.toFixed(1)}
                                </span>
                              </div>
                            )}
                            
                            {book.synopsis && (
                              <p className="font-paragraph text-xs sm:text-sm text-secondary italic line-clamp-2 sm:line-clamp-3">
                                {book.synopsis}
                              </p>
                            )}
                            
                            {/* Book action buttons */}
                            <div className="flex gap-1.5 sm:gap-2 mt-2">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="flex-1 text-xs sm:text-sm px-2 py-1.5 sm:py-2"
                                onClick={() => {
                                  const input = document.createElement('input');
                                  input.type = 'file';
                                  input.accept = '.pdf';
                                  input.onchange = (e) => {
                                    const file = (e.target as HTMLInputElement).files?.[0];
                                    if (file) {
                                      const pdfUrl = URL.createObjectURL(file);
                                      setUploadedBooks(prev => new Map(prev).set(book._id, pdfUrl));
                                      alert(`PDF "${file.name}" uploaded successfully!`);
                                    }
                                  };
                                  input.click();
                                }}
                              >
                                <Upload className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                                <span className="hidden sm:inline">Upload</span>
                              </Button>
                              {uploadedBooks.has(book._id) ? (
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="flex-1 text-xs sm:text-sm px-2 py-1.5 sm:py-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                                  onClick={() => {
                                    const pdfUrl = uploadedBooks.get(book._id);
                                    if (pdfUrl) {
                                      setSelectedPdfUrl(pdfUrl);
                                      setShowPdfViewer(true);
                                    }
                                  }}
                                >
                                  <Eye className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                                  <span className="hidden sm:inline">Read</span>
                                  <span className="sm:hidden">Read</span>
                                </Button>
                              ) : (
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="flex-1 text-xs sm:text-sm px-2 py-1.5 sm:py-2"
                                  disabled
                                >
                                  <span className="hidden sm:inline">Coming soon</span>
                                  <span className="sm:hidden">Soon</span>
                                </Button>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <Card className="border-subtleborder bg-background relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5">
                      <Image
                        src="https://static.wixstatic.com/media/179bf7_3ac7c77e338b424fa83cbc92069b85d3~mv2.png?id=books-background"
                        alt="Stack of classic and modern books on a wooden table, open book with pages turning, warm lighting, academic setting"
                        width={600}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardContent className="relative p-6 sm:p-8 md:p-12 text-center space-y-3 sm:space-y-4 md:space-y-6">
                      <BookOpen className="w-10 h-10 sm:w-12 sm:h-12 md:w-16 md:h-16 text-mutedgray mx-auto" />
                      <div className="space-y-1 sm:space-y-2">
                        <h3 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase">No Books Yet</h3>
                        <p className="font-paragraph text-xs sm:text-sm md:text-base text-secondary italic">Be the first to suggest popular books for the library.</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* User Submissions Tab */}
              <TabsContent value="user-submissions" className="space-y-4 sm:space-y-6 md:space-y-8">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4">
                  <h3 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase tracking-wide">
                    Community Contributions
                  </h3>
                  <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide text-xs sm:text-sm px-2.5 sm:px-4 py-1.5 sm:py-2.5 whitespace-nowrap">
                    <Link to="/upload-video">
                      <Upload className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                      <span className="hidden sm:inline">Upload Content</span>
                      <span className="sm:hidden">Upload</span>
                    </Link>
                  </Button>
                </div>

                {userSubmissions.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 md:gap-6">
                    {userSubmissions.map((submission, index) => (
                      <motion.div
                        key={submission._id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                      >
                        <Card className="border-subtleborder hover:border-primary transition-colors duration-300 bg-background h-full">
                          <CardHeader className="p-3 sm:p-4 md:p-6">
                            <div className="flex items-start justify-between gap-2 sm:gap-4">
                              <div className="space-y-1 sm:space-y-2 flex-1 min-w-0">
                                <CardTitle className="font-heading text-xs sm:text-sm md:text-lg text-primary uppercase tracking-wide line-clamp-2">
                                  {submission.submissionTitle}
                                </CardTitle>
                                <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                                  <Badge variant="outline" className="font-paragraph text-xs">
                                    {submission.submissionType}
                                  </Badge>
                                  <span className="font-paragraph text-xs text-secondary italic truncate">
                                    by {submission.submittedBy}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </CardHeader>
                          
                          <CardContent className="space-y-2 sm:space-y-3 md:space-y-4 p-3 sm:p-4 md:p-6 pt-0">
                            {submission.bookTitle && (
                              <div className="space-y-0.5 sm:space-y-1">
                                <h4 className="font-heading text-xs sm:text-sm text-primary uppercase tracking-wide">
                                  Related Book
                                </h4>
                                <p className="font-paragraph text-xs sm:text-sm text-secondary italic line-clamp-1">
                                  {submission.bookTitle} {submission.bookAuthor && `by ${submission.bookAuthor}`}
                                </p>
                              </div>
                            )}

                            {/* Premium/Free Badge */}
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <div className="flex items-center space-x-1 sm:space-x-2">
                                {submission.isPremium ? (
                                  <>
                                    <Badge className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-white text-xs">
                                      <Crown className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                                      Premium
                                    </Badge>
                                    <span className="text-xs sm:text-sm font-medium text-yellow-600">₹{submission.price}/mo</span>
                                  </>
                                ) : (
                                  <Badge variant="outline" className="border-green-500 text-green-600 text-xs">
                                    <Unlock className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                                    Free
                                  </Badge>
                                )}
                              </div>

                              {/* Rating Display */}
                              <div className="flex items-center space-x-0.5 sm:space-x-1">
                                <Star className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-500 fill-yellow-500" />
                                <span className="text-xs sm:text-sm font-medium">
                                  {submission.averageRating?.toFixed(1) || '0.0'}
                                </span>
                                <span className="text-xs text-secondary">
                                  ({submission.ratingCount || 0})
                                </span>
                              </div>
                            </div>
                            
                            <div className="space-y-2 sm:space-y-3">
                              <p className={`font-paragraph text-xs sm:text-sm text-secondary italic ${
                                !submission.isPremium && !isContentExpanded(submission._id) ? 'line-clamp-3 sm:line-clamp-4' : 
                                submission.isPremium && !canAccessContent(submission) ? '' : ''
                              }`}>
                                {submission.isPremium && !canAccessContent(submission)
                                  ? `${submission.content?.substring(0, 100)}... [Premium content - Purchase to view full content]`
                                  : submission.isPremium && canAccessContent(submission)
                                  ? submission.content
                                  : submission.content
                                }
                              </p>

                              {/* Show/Hide toggle ONLY for free content */}
                              {!submission.isPremium && submission.content && submission.content.length > 300 && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => toggleContentExpansion(submission._id)}
                                  className="text-primary hover:text-primary/80 p-0 h-auto font-paragraph text-xs sm:text-sm italic"
                                >
                                  {isContentExpanded(submission._id) ? 'Show Less' : 'Show More'}
                                </Button>
                              )}
                            </div>

                            {/* Media Attachments */}
                            {(submission.audioSubmission || submission.imageSubmission || submission.pdfNotesUrl || submission.discussionVideoUrl) && (
                              <div className="space-y-2 sm:space-y-3 pt-2 sm:pt-3 border-t border-subtleborder">
                                <h5 className="font-heading text-xs text-primary uppercase tracking-wide">
                                  Attachments
                                </h5>
                                <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
                                  {submission.audioSubmission && (
                                    <div className="flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-2 bg-mutedgray/10 rounded-lg">
                                      <Mic className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                                      <span className="font-paragraph text-xs text-secondary italic">Audio</span>
                                    </div>
                                  )}
                                  {submission.imageSubmission && (
                                    <div className="flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-2 bg-mutedgray/10 rounded-lg">
                                      <ImageIcon className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                                      <span className="font-paragraph text-xs text-secondary italic">Image</span>
                                    </div>
                                  )}
                                  {submission.pdfNotesUrl && (
                                    <div className="flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-2 bg-mutedgray/10 rounded-lg">
                                      <FileText className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                                      <span className="font-paragraph text-xs text-secondary italic">PDF</span>
                                    </div>
                                  )}
                                  {submission.discussionVideoUrl && (
                                    <div className="flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-2 bg-mutedgray/10 rounded-lg">
                                      <Video className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                                      <span className="font-paragraph text-xs text-secondary italic">Video</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}
                            
                            <div className="flex items-center justify-between gap-2 pt-2 sm:pt-3 border-t border-subtleborder flex-wrap">
                              <span className="font-paragraph text-xs text-secondary italic">
                                {formatDate(submission.submissionDate)}
                              </span>
                              
                              {submission.isPremium && !canAccessContent(submission) ? (
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="border-yellow-500 text-yellow-600 hover:bg-yellow-500 hover:text-white text-xs px-2 py-1.5 sm:py-2"
                                  onClick={() => handlePremiumContentAccess(submission)}
                                >
                                  <Lock className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                                  <span className="hidden sm:inline">Unlock ₹{submission.price}</span>
                                  <span className="sm:hidden">Unlock</span>
                                </Button>
                              ) : submission.isPremium && canAccessContent(submission) ? (
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-xs px-2 py-1.5 sm:py-2"
                                  onClick={() => setSelectedSubmission(submission)}
                                >
                                  View Details
                                </Button>
                              ) : (
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-xs px-2 py-1.5 sm:py-2"
                                  onClick={() => toggleContentExpansion(submission._id)}
                                >
                                  {isContentExpanded(submission._id) ? 'Show Less' : 'Read More'}
                                </Button>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <Card className="border-subtleborder bg-background">
                    <CardContent className="p-6 sm:p-8 md:p-12 text-center space-y-3 sm:space-y-4 md:space-y-6">
                      <Upload className="w-10 h-10 sm:w-12 sm:h-12 md:w-16 md:h-16 text-mutedgray mx-auto" />
                      <div className="space-y-1 sm:space-y-2">
                        <h3 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase">No Submissions Yet</h3>
                        <p className="font-paragraph text-xs sm:text-sm md:text-base text-secondary italic">Share your book readings, summaries, and multimedia content with the community.</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* Discussion Videos Tab */}
              <TabsContent value="discussion-videos" className="space-y-4 sm:space-y-6 md:space-y-8">
                <div className="flex items-center justify-between">
                  <h3 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase tracking-wide">
                    Video Discussions
                  </h3>
                </div>

                {discussionVideos.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-6">
                    {discussionVideos.map((video, index) => (
                      <motion.div
                        key={video._id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                      >
                        <Card className="border-subtleborder hover:border-primary transition-colors duration-300 bg-background h-full">
                          <CardHeader className="space-y-2 sm:space-y-3 md:space-y-4 p-3 sm:p-4 md:p-6">
                            <div className="aspect-video w-full rounded-lg overflow-hidden bg-mutedgray/20 relative group">
                              {video.thumbnail ? (
                                <Image
                                  src={video.thumbnail}
                                  alt={`Thumbnail for ${video.videoTitle}`}
                                  width={300}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <Video className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-mutedgray" />
                                </div>
                              )}
                              <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <Play className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-white" />
                              </div>
                            </div>
                            
                            <div className="space-y-1 sm:space-y-2">
                              <CardTitle className="font-heading text-xs sm:text-sm md:text-lg text-primary uppercase tracking-wide line-clamp-2">
                                {video.videoTitle}
                              </CardTitle>
                              <CardDescription className="font-paragraph text-xs sm:text-sm text-secondary italic line-clamp-2">
                                {video.description}
                              </CardDescription>
                            </div>
                          </CardHeader>
                          
                          <CardContent className="space-y-2 sm:space-y-3 md:space-y-4 p-3 sm:p-4 md:p-6 pt-0">
                            {video.associatedTopic && (
                              <Badge variant="outline" className="font-paragraph text-xs">
                                {video.associatedTopic}
                              </Badge>
                            )}
                            
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <span className="font-paragraph text-xs text-secondary italic">
                                {formatDate(video.uploadDate)}
                              </span>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-xs px-2 py-1.5 sm:py-2"
                                onClick={() => alert('Content viewing only - downloads disabled for security')}
                              >
                                <Play className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                                Watch
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <Card className="border-subtleborder bg-background">
                    <CardContent className="p-6 sm:p-8 md:p-12 text-center space-y-3 sm:space-y-4 md:space-y-6">
                      <Video className="w-10 h-10 sm:w-12 sm:h-12 md:w-16 md:h-16 text-mutedgray mx-auto" />
                      <div className="space-y-1 sm:space-y-2">
                        <h3 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase">No Videos Yet</h3>
                        <p className="font-paragraph text-xs sm:text-sm md:text-base text-secondary italic">Upload discussion videos to share with the community.</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* Live Sessions Tab */}
              <TabsContent value="live-sessions" className="space-y-4 sm:space-y-6 md:space-y-8">
                <div className="flex items-center justify-between">
                  <h3 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase tracking-wide">
                    Live Discussion Sessions
                  </h3>
                </div>

                {liveSessions.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 md:gap-6">
                    {liveSessions.map((session, index) => (
                      <motion.div
                        key={session._id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                      >
                        <Card className="border-subtleborder hover:border-primary transition-colors duration-300 bg-background h-full">
                          <CardHeader className="p-3 sm:p-4 md:p-6">
                            <div className="flex items-start justify-between gap-2 sm:gap-4">
                              <div className="space-y-1 sm:space-y-2 flex-1 min-w-0">
                                <CardTitle className="font-heading text-xs sm:text-sm md:text-lg text-primary uppercase tracking-wide line-clamp-2">
                                  {session.sessionTopic}
                                </CardTitle>
                                <CardDescription className="font-paragraph text-xs sm:text-sm text-secondary italic line-clamp-2">
                                  {session.sessionDescription}
                                </CardDescription>
                              </div>
                              <Badge variant="outline" className="font-paragraph text-xs whitespace-nowrap flex-shrink-0">
                                <Users className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                                {session.maxParticipants}
                              </Badge>
                            </div>
                          </CardHeader>
                          
                          <CardContent className="space-y-2 sm:space-y-3 md:space-y-4 p-3 sm:p-4 md:p-6 pt-0">
                            {session.discussedBook && (
                              <div className="space-y-0.5 sm:space-y-1">
                                <h4 className="font-heading text-xs sm:text-sm text-primary uppercase tracking-wide">
                                  Featured Book
                                </h4>
                                <p className="font-paragraph text-xs sm:text-sm text-secondary italic line-clamp-1">
                                  {session.discussedBook}
                                </p>
                              </div>
                            )}
                            
                            <div className="flex items-center gap-2 sm:gap-3 text-xs sm:text-sm flex-wrap">
                              <div className="flex items-center gap-0.5 sm:gap-1 text-secondary">
                                <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                                <span className="font-paragraph italic">
                                  {formatDate(session.sessionDate)}
                                </span>
                              </div>
                              
                              {session.sessionTime && (
                                <div className="flex items-center gap-0.5 sm:gap-1 text-secondary">
                                  <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                                  <span className="font-paragraph italic">
                                    {session.sessionTime}
                                  </span>
                                </div>
                              )}
                            </div>
                            
                            <div className="pt-2 sm:pt-3 border-t border-subtleborder">
                              <Button 
                                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide text-xs sm:text-sm py-1.5 sm:py-2"
                                onClick={() => alert('Live sessions are for viewing only - downloads disabled for security')}
                              >
                                <Video className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                                Join Session
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <Card className="border-subtleborder bg-background">
                    <CardContent className="p-6 sm:p-8 md:p-12 text-center space-y-3 sm:space-y-4 md:space-y-6">
                      <Calendar className="w-10 h-10 sm:w-12 sm:h-12 md:w-16 md:h-16 text-mutedgray mx-auto" />
                      <div className="space-y-1 sm:space-y-2">
                        <h3 className="font-heading text-base sm:text-lg md:text-2xl text-primary uppercase">No Sessions Scheduled</h3>
                        <p className="font-paragraph text-xs sm:text-sm md:text-base text-secondary italic">Schedule live video discussions for small groups.</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </main>

      {/* Content Evaluation Widget */}
      <FeedbackWidget featureName="Library Content Collection" variant="floating" />

      {/* Exit Feedback Prompt */}
      <ExitFeedbackPrompt 
        isOpen={showFeedbackPrompt}
        onClose={closeFeedbackPrompt}
        featureName="Library"
      />

      {/* PDF Viewer Modal */}
      {showPdfViewer && selectedPdfUrl && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-subtleborder">
              <h2 className="font-heading text-lg text-primary uppercase">PDF Viewer</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setShowPdfViewer(false);
                  setSelectedPdfUrl(null);
                }}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <div className="flex-1 overflow-auto">
              <iframe
                src={selectedPdfUrl}
                className="w-full h-full"
                title="PDF Viewer"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
