import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { UserSubscriptions, PaymentTransactions, CreatorProfiles } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { UPIPaymentModal } from '@/components/ui/upi-payment-modal';
import { MemberProtectedRoute } from '@/components/ui/member-protected-route';
import { ArrowLeft, Crown, Star, TrendingUp, Shield, Award, CheckCircle, IndianRupee } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useMember } from '@/integrations';

export default function BecomePaidCreatorPage() {
  const navigate = useNavigate();
  const { member } = useMember();
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [creatorProfile, setCreatorProfile] = useState<any>(null);
  const [userStats, setUserStats] = useState({
    totalSubmissions: 0,
    averageRating: 0,
    totalRatings: 0,
    eligibleForUpgrade: false
  });

  useEffect(() => {
    if (member?.loginEmail) {
      loadUserStats();
      loadCreatorProfile();
    }
  }, [member]);

  const loadUserStats = async () => {
    try {
      const { items: submissions } = await BaseCrudService.getAll('userbooksubmissions');
      const userSubmissions = submissions.filter(s => s.submittedBy === member?.profile?.nickname || s.submittedBy === member?.contact?.firstName);
      
      let totalRating = 0;
      let totalRatings = 0;
      
      userSubmissions.forEach(submission => {
        if (submission.averageRating && submission.ratingCount) {
          totalRating += submission.averageRating * submission.ratingCount;
          totalRatings += submission.ratingCount;
        }
      });

      const averageRating = totalRatings > 0 ? totalRating / totalRatings : 0;
      const eligibleForUpgrade = averageRating >= 4.0 && totalRatings >= 50;

      setUserStats({
        totalSubmissions: userSubmissions.length,
        averageRating,
        totalRatings,
        eligibleForUpgrade
      });
    } catch (error) {
      console.error('Error loading user stats:', error);
    }
  };

  const loadCreatorProfile = async () => {
    try {
      const { items: profiles } = await BaseCrudService.getAll('creatorprofiles');
      const profile = profiles.find(p => p.userId === member?.loginEmail);
      setCreatorProfile(profile);
    } catch (error) {
      console.error('Error loading creator profile:', error);
    }
  };

  const handlePaymentSuccess = async () => {
    setIsProcessing(true);
    try {
      // Create payment transaction record
      const transaction: PaymentTransactions = {
        _id: crypto.randomUUID(),
        userId: member?.loginEmail || '',
        amount: 49,
        currency: 'INR',
        purpose: 'Creator Upgrade',
        status: 'successful',
        transactionDateTime: new Date().toISOString()
      };
      await BaseCrudService.create('paymenttransactions', transaction);

      // Create or update creator subscription
      const subscription: UserSubscriptions = {
        _id: crypto.randomUUID(),
        userEmail: member?.loginEmail || '',
        subscriptionType: 'Creator Upgrade',
        startDate: new Date().toISOString(),
        expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
        paymentStatus: 'Paid',
        amountPaid: 49,
        isCreatorUpgrade: true
      };
      await BaseCrudService.create('usersubscriptions', subscription);

      // Create or update creator profile
      const profile: CreatorProfiles = {
        _id: crypto.randomUUID(),
        userId: member?.loginEmail || '',
        isPaidCreator: true,
        totalEarnings: 0,
        badges: 'Paid Creator',
        leaderboardRank: 0
      };
      await BaseCrudService.create('creatorprofiles', profile);

      alert('Congratulations! You are now a Paid Creator. You can now set premium prices for your content.');
      navigate('/profile');
    } catch (error) {
      console.error('Error processing creator upgrade:', error);
      alert('Payment successful but there was an error upgrading your account. Please contact support.');
    } finally {
      setIsProcessing(false);
      setIsPaymentModalOpen(false);
    }
  };

  const isPaidCreator = creatorProfile?.isPaidCreator;

  return (
    <MemberProtectedRoute messageToSignIn="Sign in to become a Paid Creator">
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="w-full border-b border-subtleborder bg-background">
          <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
              <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
                <Link to="/profile">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Profile
                </Link>
              </Button>
              <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
              <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
                Become Paid Creator
              </h1>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
          {isPaidCreator ? (
            /* Already a Paid Creator */
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center space-y-8"
            >
              <div className="space-y-4">
                <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto">
                  <Crown className="w-10 h-10 text-white" />
                </div>
                <h2 className="font-heading text-3xl text-primary uppercase tracking-wide">
                  You're Already a Paid Creator!
                </h2>
                <p className="text-lg text-secondary max-w-2xl mx-auto">
                  Congratulations! You have access to all premium creator features. 
                  You can now set prices for your content and earn from your knowledge.
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
                <Card>
                  <CardContent className="p-6 text-center">
                    <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-3" />
                    <h3 className="font-heading text-lg mb-2">Total Earnings</h3>
                    <p className="text-2xl font-bold text-green-600">₹{creatorProfile?.totalEarnings || 0}</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6 text-center">
                    <Award className="w-8 h-8 text-purple-600 mx-auto mb-3" />
                    <h3 className="font-heading text-lg mb-2">Badges</h3>
                    <Badge variant="secondary">{creatorProfile?.badges || 'Paid Creator'}</Badge>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6 text-center">
                    <Star className="w-8 h-8 text-yellow-500 mx-auto mb-3" />
                    <h3 className="font-heading text-lg mb-2">Leaderboard Rank</h3>
                    <p className="text-2xl font-bold text-primary">#{creatorProfile?.leaderboardRank || 'N/A'}</p>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  <Link to="/upload-video">Upload Premium Content</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link to="/profile">Manage Your Profile</Link>
                </Button>
              </div>
            </motion.div>
          ) : (
            /* Upgrade to Paid Creator */
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              {/* Left Column - Upgrade Info */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-8"
              >
                <div className="text-center lg:text-left">
                  <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mb-6 mx-auto lg:mx-0">
                    <Crown className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="font-heading text-3xl text-primary uppercase tracking-wide mb-4">
                    Upgrade to Paid Creator
                  </h2>
                  <p className="text-lg text-secondary">
                    Unlock premium features and start earning from your knowledge. 
                    Set prices for your content and build a sustainable income stream.
                  </p>
                </div>

                {/* User Stats */}
                <Card>
                  <CardHeader>
                    <CardTitle className="font-heading">Your Creator Stats</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Total Submissions</span>
                      <Badge variant="outline">{userStats.totalSubmissions}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Average Rating</span>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span>{userStats.averageRating.toFixed(1)}</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Total Ratings Received</span>
                      <Badge variant="outline">{userStats.totalRatings}</Badge>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex items-center space-x-2">
                      {userStats.eligibleForUpgrade ? (
                        <>
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="text-green-600 font-medium">Eligible for Paid Creator upgrade!</span>
                        </>
                      ) : (
                        <>
                          <Shield className="w-5 h-5 text-yellow-500" />
                          <span className="text-yellow-600">Need 4⭐+ rating with 50+ feedback to qualify</span>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* AI Suggestion */}
                {userStats.eligibleForUpgrade && (
                  <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                          <Star className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <h3 className="font-heading text-lg text-blue-900 mb-2">AI Recommendation</h3>
                          <p className="text-blue-800 text-sm">
                            Congratulations! Based on your excellent content quality and community feedback, 
                            our AI recommends you for the Paid Creator upgrade. Your content consistently 
                            receives high ratings and positive engagement from 50+ users.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </motion.div>

              {/* Right Column - Pricing & Features */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="space-y-8"
              >
                {/* Pricing Card */}
                <Card className="border-2 border-primary">
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                      <Crown className="w-6 h-6 text-primary-foreground" />
                    </div>
                    <CardTitle className="font-heading text-2xl text-primary">Paid Creator Plan</CardTitle>
                    <CardDescription>Unlock premium features and start earning</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center">
                      <div className="flex items-center justify-center space-x-1 mb-2">
                        <IndianRupee className="w-8 h-8 text-primary" />
                        <span className="text-4xl font-bold text-primary">49</span>
                        <span className="text-lg text-secondary">/month</span>
                      </div>
                      <p className="text-sm text-secondary">UPI payment only • Manual verification</p>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      <h4 className="font-heading text-lg">What you get:</h4>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Set premium prices (₹10-₹70/month)</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Earn from your content</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Golden creator badge</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Priority content review</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Analytics dashboard</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Leaderboard ranking</span>
                        </li>
                      </ul>
                    </div>

                    <Button 
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6"
                      onClick={() => setIsPaymentModalOpen(true)}
                      disabled={!userStats.eligibleForUpgrade || isProcessing}
                    >
                      {isProcessing ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                          Processing...
                        </>
                      ) : (
                        <>
                          <Crown className="w-4 h-4 mr-2" />
                          Upgrade Now - ₹49/month
                        </>
                      )}
                    </Button>

                    {!userStats.eligibleForUpgrade && (
                      <p className="text-xs text-center text-secondary">
                        You need at least 4⭐ average rating with 50+ feedback to upgrade
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Security Features */}
                <Card>
                  <CardHeader>
                    <CardTitle className="font-heading flex items-center space-x-2">
                      <Shield className="w-5 h-5 text-green-600" />
                      <span>Security & Verification</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>2-step manual verification process</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Secure UPI payment gateway</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>AI content moderation</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Duplicate content detection</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          )}
        </main>

        {/* UPI Payment Modal */}
        <UPIPaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          amount={49}
          planType="month1"
          onPaymentComplete={handlePaymentSuccess}
        />
      </div>
    </MemberProtectedRoute>
  );
}