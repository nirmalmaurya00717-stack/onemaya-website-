import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { BookReadingGroups } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Image } from '@/components/ui/image';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, BookOpen, Users, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function CreateGroupPage() {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    groupName: '',
    description: '',
    currentBook: '',
    bookAuthor: '',
    bookCover: '',
    isPublic: true
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.groupName.trim() || !formData.description.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const newGroup: BookReadingGroups = {
        _id: crypto.randomUUID(),
        groupName: formData.groupName.trim(),
        description: formData.description.trim(),
        currentBook: formData.currentBook.trim() || undefined,
        bookAuthor: formData.bookAuthor.trim() || undefined,
        bookCover: formData.bookCover.trim() || undefined,
        isPublic: formData.isPublic,
        creationDate: new Date().toISOString()
      };

      await BaseCrudService.create('bookreadinggroups', newGroup);
      navigate(`/group/${newGroup._id}`);
    } catch (error) {
      console.error('Error creating group:', error);
      alert('Failed to create group. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background relative overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 opacity-10">
          <Image
            src="https://static.wixstatic.com/media/179bf7_f5253d30b7d64841ac553dcdeda4b1c7~mv2.png?id=hostel-group"
            alt="University students sitting in a circle in a hostel common room, having a book discussion, diverse group, casual friendly atmosphere"
            width={1200}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Groups
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
              <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
                Create Reading Group
              </h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-start">
          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-subtleborder bg-background">
              <CardHeader className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <Plus className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-2xl text-primary uppercase tracking-wide">
                      New Reading Circle
                    </CardTitle>
                    <CardDescription className="font-paragraph text-secondary italic">
                      Establish a literary community for hostel scholars
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Group Details */}
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="groupName" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Group Name *
                      </Label>
                      <Input
                        id="groupName"
                        value={formData.groupName}
                        onChange={(e) => handleInputChange('groupName', e.target.value)}
                        placeholder="e.g., Philosophy & Fiction Circle"
                        className="border-subtleborder focus:border-primary font-paragraph"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Description *
                      </Label>
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        placeholder="Describe your group's focus, meeting style, and what members can expect..."
                        className="border-subtleborder focus:border-primary font-paragraph min-h-24"
                        required
                      />
                    </div>
                  </div>

                  {/* Current Book */}
                  <div className="space-y-6 pt-6 border-t border-subtleborder">
                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                      Current Reading
                    </h3>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="currentBook" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Book Title
                        </Label>
                        <Input
                          id="currentBook"
                          value={formData.currentBook}
                          onChange={(e) => handleInputChange('currentBook', e.target.value)}
                          placeholder="e.g., The Alchemist"
                          className="border-subtleborder focus:border-primary font-paragraph"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bookAuthor" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Author
                        </Label>
                        <Input
                          id="bookAuthor"
                          value={formData.bookAuthor}
                          onChange={(e) => handleInputChange('bookAuthor', e.target.value)}
                          placeholder="e.g., Paulo Coelho"
                          className="border-subtleborder focus:border-primary font-paragraph"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bookCover" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Book Cover URL
                      </Label>
                      <Input
                        id="bookCover"
                        value={formData.bookCover}
                        onChange={(e) => handleInputChange('bookCover', e.target.value)}
                        placeholder="https://example.com/book-cover.jpg"
                        className="border-subtleborder focus:border-primary font-paragraph"
                        type="url"
                      />
                    </div>
                  </div>

                  {/* Privacy Settings */}
                  <div className="space-y-4 pt-6 border-t border-subtleborder">
                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                      Privacy Settings
                    </h3>
                    
                    <div className="flex items-center justify-between p-4 border border-subtleborder rounded-lg">
                      <div className="space-y-1">
                        <Label htmlFor="isPublic" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Public Group
                        </Label>
                        <p className="font-paragraph text-sm text-secondary italic">
                          Allow any hostel resident to discover and join this group
                        </p>
                      </div>
                      <Switch
                        id="isPublic"
                        checked={formData.isPublic}
                        onCheckedChange={(checked) => handleInputChange('isPublic', checked)}
                      />
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-6">
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 font-heading uppercase tracking-wide"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                          Creating Group...
                        </>
                      ) : (
                        <>
                          <BookOpen className="w-4 h-4 mr-2" />
                          Create Reading Group
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Info Section */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Hero Image */}
            <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden">
              <Image
                src="https://static.wixstatic.com/media/179bf7_026617d7d6bb4e228ac5cedf0ea026f3~mv2.png?id=students-studying"
                alt="Diverse group of university students studying together outdoors on campus, books and laptops, collaborative learning, academic environment"
                width={600}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-6">
              <h2 className="font-heading text-3xl text-primary uppercase tracking-tight">
                Building Literary Communities
              </h2>
              <p className="font-paragraph text-lg text-secondary italic leading-relaxed">
                Create a space where hostel residents from diverse academic backgrounds can 
                come together to explore literature, share perspectives, and build meaningful 
                connections through the power of books.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Users className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Cross-Disciplinary Exchange
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Bring together students from BTech, BSc, BA, and other programs to share 
                    unique perspectives on literature and life.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <BookOpen className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Structured Discussions
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Foster meaningful conversations about books, themes, and ideas that 
                    resonate with the hostel community experience.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Plus className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Flexible Format
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Choose between public groups for open participation or private circles 
                    for intimate discussions among close friends.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 bg-mutedgray/10 rounded-lg border border-subtleborder">
              <h4 className="font-heading text-sm text-primary uppercase tracking-wide mb-3">
                Getting Started Tips
              </h4>
              <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                <li>• Choose a descriptive group name that reflects your reading focus</li>
                <li>• Write a clear description to attract like-minded readers</li>
                <li>• Start with a popular or accessible book to encourage participation</li>
                <li>• Consider making your group public to reach more hostel residents</li>
              </ul>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Feedback Widget */}
      <FeedbackWidget featureName="Create Reading Group Feature" variant="floating" />
    </div>
  );
}