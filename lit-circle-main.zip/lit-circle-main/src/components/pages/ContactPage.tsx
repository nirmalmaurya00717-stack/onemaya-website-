import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Mail, MapPin, Clock, Send, MessageCircle, HeadphonesIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { validateEmail, getEmailValidationMessage } from '@/lib/email-validation';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Validate email in real-time
    if (name === 'email') {
      const errorMessage = getEmailValidationMessage(value);
      setEmailError(errorMessage);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate email before submission
    const emailValidation = validateEmail(formData.email);
    if (!emailValidation.isValid) {
      setEmailError(emailValidation.errors[0]);
      toast({
        title: "Invalid Email",
        description: emailValidation.errors[0],
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Message Sent!",
        description: "Thank you for contacting us. We'll get back to you within 24 hours.",
      });
      setFormData({ name: '', email: '', subject: '', message: '' });
      setEmailError(null);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[100rem] mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <MessageCircle className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-heading font-bold text-foreground">
              Contact Us
            </h1>
          </div>
          <p className="text-lg font-paragraph text-secondary max-w-3xl mx-auto">
            We're here to help! Get in touch with us for any questions, support, or feedback about our book reading platform.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2 max-w-6xl mx-auto">
          {/* Contact Information */}
          <div className="space-y-6">
            <Card className="border-2 border-primary bg-blue-50">
              <CardHeader>
                <CardTitle className="font-heading flex items-center gap-2 text-primary">
                  <Mail className="h-5 w-5" />
                  Get in Touch
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Email */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                    <Mail className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-semibold mb-1">Email Support</h3>
                    <p className="font-paragraph text-sm text-secondary mb-2">
                      Send us an email anytime
                    </p>
                    <a 
                      href="mailto:onemaya96@gmail.com" 
                      className="font-paragraph text-lg font-bold text-green-600 hover:underline"
                    >
                      onemaya96@gmail.com
                    </a>
                    <p className="font-paragraph text-xs text-mutedgray mt-1">
                      We respond within 24 hours
                    </p>
                  </div>
                </div>

                {/* Address */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
                    <MapPin className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-semibold mb-1">Office Address</h3>
                    <p className="font-paragraph text-sm text-secondary mb-2">
                      Visit us at our office
                    </p>
                    <address className="font-paragraph text-sm text-secondary not-italic">
                      Book Reading Platform<br />
                      123 Knowledge Street<br />
                      Education District<br />
                      Lucknow, Uttar Pradesh 226001<br />
                      India
                    </address>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Support Hours */}
            <Card>
              <CardHeader>
                <CardTitle className="font-heading flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Support Hours
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Monday - Friday</span>
                    <span className="font-paragraph text-sm font-semibold">9:00 AM - 6:00 PM IST</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Saturday</span>
                    <span className="font-paragraph text-sm font-semibold">10:00 AM - 4:00 PM IST</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Sunday</span>
                    <span className="font-paragraph text-sm text-mutedgray">Closed</span>
                  </div>
                  <div className="pt-3 border-t">
                    <p className="font-paragraph text-xs text-secondary">
                      <strong>Emergency Support:</strong> For urgent issues, email us anytime. We monitor emails 24/7 for critical problems.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Help */}
            <Card>
              <CardHeader>
                <CardTitle className="font-heading flex items-center gap-2">
                  <HeadphonesIcon className="h-5 w-5 text-primary" />
                  Quick Help
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-heading text-sm font-semibold mb-1">Account Issues</h4>
                    <p className="font-paragraph text-xs text-secondary">Login problems, password reset, account settings</p>
                  </div>
                  <div>
                    <h4 className="font-heading text-sm font-semibold mb-1">Payment Support</h4>
                    <p className="font-paragraph text-xs text-secondary">Subscription issues, payment verification, refunds</p>
                  </div>
                  <div>
                    <h4 className="font-heading text-sm font-semibold mb-1">Technical Help</h4>
                    <p className="font-paragraph text-xs text-secondary">App issues, feature questions, bug reports</p>
                  </div>
                  <div>
                    <h4 className="font-heading text-sm font-semibold mb-1">Content Support</h4>
                    <p className="font-paragraph text-xs text-secondary">Book access, reading groups, content submissions</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="font-heading flex items-center gap-2">
                  <Send className="h-5 w-5 text-primary" />
                  Send us a Message
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label htmlFor="name" className="font-paragraph text-sm font-medium">
                        Full Name *
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Enter your full name"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email" className="font-paragraph text-sm font-medium">
                        Email Address *
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="Enter your email"
                        className={`mt-1 ${emailError ? 'border-red-500 focus:border-red-500' : ''}`}
                      />
                      {emailError && (
                        <p className="mt-1 text-sm text-red-600 font-paragraph">
                          {emailError}
                        </p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="subject" className="font-paragraph text-sm font-medium">
                      Subject *
                    </Label>
                    <Input
                      id="subject"
                      name="subject"
                      type="text"
                      required
                      value={formData.subject}
                      onChange={handleInputChange}
                      placeholder="What is this regarding?"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message" className="font-paragraph text-sm font-medium">
                      Message *
                    </Label>
                    <Textarea
                      id="message"
                      name="message"
                      required
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Please describe your question or issue in detail..."
                      className="mt-1 min-h-[120px]"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Send Message
                      </>
                    )}
                  </Button>

                  <p className="font-paragraph text-xs text-mutedgray text-center">
                    We'll respond to your message within 24 hours during business days.
                  </p>
                </form>
              </CardContent>
            </Card>

            {/* Alternative Contact Methods */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="font-heading text-lg">Prefer Other Ways to Connect?</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4 text-green-600" />
                    <span className="font-paragraph text-sm">Email for detailed questions or documentation</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MessageCircle className="h-4 w-4 text-blue-600" />
                    <span className="font-paragraph text-sm">Use this form for general inquiries</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16 max-w-4xl mx-auto">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="font-heading text-2xl">Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <h3 className="font-heading text-sm font-semibold mb-2">How quickly do you respond?</h3>
                  <p className="font-paragraph text-xs text-secondary">
                    We respond to emails within 24 hours during business days. Email support is our primary contact method.
                  </p>
                </div>
                <div>
                  <h3 className="font-heading text-sm font-semibold mb-2">What information should I include?</h3>
                  <p className="font-paragraph text-xs text-secondary">
                    Please include your account email, a clear description of the issue, and any error messages you're seeing. Screenshots are helpful too!
                  </p>
                </div>
                <div>
                  <h3 className="font-heading text-sm font-semibold mb-2">Do you offer phone support?</h3>
                  <p className="font-paragraph text-xs text-secondary">
                    We provide email support only. Send us an email and we'll respond within 24 hours during business days.
                  </p>
                </div>
                <div>
                  <h3 className="font-heading text-sm font-semibold mb-2">Can I visit your office?</h3>
                  <p className="font-paragraph text-xs text-secondary">
                    While we primarily provide online support, you can visit our Lucknow office during business hours. Please email ahead to schedule an appointment.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}