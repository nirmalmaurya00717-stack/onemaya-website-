import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { UserBookSubmissions } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, Upload, BookOpen, FileText, Mic, Image as ImageIcon, X, Paperclip, Star, Shield, Award, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Image } from '@/components/ui/image';
import { useMember } from '@/integrations';

export default function SubmitContentPage() {
  const navigate = useNavigate();
  const { member } = useMember();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [videoUrlError, setVideoUrlError] = useState('');
  const [formData, setFormData] = useState({
    submissionTitle: '',
    submissionType: '',
    content: '',
    bookTitle: '',
    bookAuthor: '',
    submittedBy: member?.profile?.nickname || member?.contact?.firstName || '',
    audioSubmission: '',
    imageSubmission: '',
    pdfNotesUrl: '',
    discussionVideoUrl: ''
  });
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [audioPreview, setAudioPreview] = useState<string>('');
  const [imagePreview, setImagePreview] = useState<string>('');

  // Function to validate video URL
  const validateVideoUrl = (url: string): boolean => {
    if (!url.trim()) {
      setVideoUrlError('');
      return true; // Empty URL is valid (optional field)
    }

    // List of blocked social media platforms
    const blockedDomains = [
      'youtube.com',
      'youtu.be',
      'facebook.com',
      'fb.com',
      'instagram.com',
      'twitter.com',
      'x.com',
      'telegram.org',
      'telegram.me',
      't.me',
      'tiktok.com',
      'snapchat.com',
      'linkedin.com',
      'pinterest.com',
      'reddit.com',
      'whatsapp.com',
      'discord.com',
      'twitch.tv'
    ];

    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname.toLowerCase();
      
      // Remove 'www.' prefix if present
      const cleanHostname = hostname.replace(/^www\./, '');
      
      // Check if the domain is in the blocked list
      const isBlocked = blockedDomains.some(domain => 
        cleanHostname === domain || cleanHostname.endsWith('.' + domain)
      );

      if (isBlocked) {
        setVideoUrlError('Social media platform links are not allowed. Please use direct video hosting services or upload your content directly to OneMaya.');
        return false;
      }

      setVideoUrlError('');
      return true;
    } catch (error) {
      setVideoUrlError('Please enter a valid URL');
      return false;
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Validate video URL when it changes
    if (field === 'discussionVideoUrl') {
      validateVideoUrl(value);
    }
  };

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const validAudioTypes = ['audio/mp3', 'audio/wav', 'audio/ogg', 'audio/m4a', 'audio/mpeg'];
      if (!validAudioTypes.includes(file.type)) {
        alert('Please upload a valid audio file (MP3, WAV, OGG, M4A)');
        return;
      }
      
      // Validate file size (max 50MB)
      if (file.size > 50 * 1024 * 1024) {
        alert('Audio file size must be less than 50MB');
        return;
      }
      
      setAudioFile(file);
      const audioUrl = URL.createObjectURL(file);
      setAudioPreview(audioUrl);
      
      // For demo purposes, we'll use a placeholder URL
      // In a real app, you'd upload to a file storage service
      const demoAudioUrl = 'https://static.wixstatic.com/media/179bf7_0bfd1686d7084446b97e39703a158905~mv2.png?originWidth=256&originHeight=256';
      handleInputChange('audioSubmission', demoAudioUrl);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const validImageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      if (!validImageTypes.includes(file.type)) {
        alert('Please upload a valid image file (JPEG, PNG, GIF, WebP)');
        return;
      }
      
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        alert('Image file size must be less than 10MB');
        return;
      }
      
      setImageFile(file);
      const imageUrl = URL.createObjectURL(file);
      setImagePreview(imageUrl);
      
      // For demo purposes, we'll use a placeholder URL
      // In a real app, you'd upload to a file storage service
      const demoImageUrl = 'https://static.wixstatic.com/media/179bf7_813f88786d8e400bb0fac08264cc13f4~mv2.png?originWidth=256&originHeight=256';
      handleInputChange('imageSubmission', demoImageUrl);
    }
  };

  const removeAudio = () => {
    setAudioFile(null);
    setAudioPreview('');
    handleInputChange('audioSubmission', '');
    // Reset the file input
    const audioInput = document.getElementById('audioUpload') as HTMLInputElement;
    if (audioInput) audioInput.value = '';
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview('');
    handleInputChange('imageSubmission', '');
    // Reset the file input
    const imageInput = document.getElementById('imageUpload') as HTMLInputElement;
    if (imageInput) imageInput.value = '';
  };

  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const validDocumentTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain',
        'application/epub+zip',
        'application/x-mobipocket-ebook'
      ];
      if (!validDocumentTypes.includes(file.type)) {
        alert('Please upload a valid document file (PDF, DOC, DOCX, TXT, EPUB, MOBI)');
        return;
      }
      
      // Validate file size (max 25MB)
      if (file.size > 25 * 1024 * 1024) {
        alert('Document file size must be less than 25MB');
        return;
      }
      
      setDocumentFile(file);
    }
  };

  const removeDocument = () => {
    setDocumentFile(null);
    // Reset the file input
    const documentInput = document.getElementById('documentUpload') as HTMLInputElement;
    if (documentInput) documentInput.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.submissionTitle.trim() || !formData.submissionType || !formData.content.trim() || !formData.submittedBy.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    // Validate video URL if provided
    if (formData.discussionVideoUrl && !validateVideoUrl(formData.discussionVideoUrl)) {
      alert('Please provide a valid video URL from an allowed platform or leave the field empty');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const newSubmission: UserBookSubmissions = {
        _id: crypto.randomUUID(),
        submissionTitle: formData.submissionTitle.trim(),
        submissionType: formData.submissionType,
        content: formData.content.trim(),
        bookTitle: formData.bookTitle.trim() || undefined,
        bookAuthor: formData.bookAuthor.trim() || undefined,
        submittedBy: formData.submittedBy.trim(),
        submissionDate: new Date().toISOString(),
        audioSubmission: formData.audioSubmission || undefined,
        imageSubmission: formData.imageSubmission || undefined,
        pdfNotesUrl: formData.pdfNotesUrl || undefined,
        discussionVideoUrl: formData.discussionVideoUrl || undefined,
        averageRating: 0,
        ratingCount: 0,
        isPremium: false,
        price: 0,
        moderationStatus: 'Approved'
      };

      await BaseCrudService.create('userbooksubmissions', newSubmission);
      alert('Content published successfully! Your submission is now visible to all users.');
      navigate('/library');
    } catch (error) {
      console.error('Error creating submission:', error);
      alert('Failed to submit content. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/library">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Library
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
              Upload Your Content
            </h1>
          </div>
          
          {/* Creator Benefits Banner */}
          <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-subtleborder">
            <p className="text-center text-sm font-paragraph text-secondary mb-3">
              <strong>Onemaya gives every hostel boys, researcher, and knowledge lover the power to publish and earn.</strong><br />
              Upload your Video, book summaries, notes or research — get 4⭐, 50 feedback and become a Paid Creator just at ₹49/month!
            </p>
            <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto">
              <div className="flex items-center justify-center space-x-2 bg-white p-3 rounded-lg">
                <Star className="w-4 h-4 text-yellow-500" />
                <span className="text-xs font-medium">Get rated by community</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-white p-3 rounded-lg">
                <Award className="w-4 h-4 text-green-600" />
                <span className="text-xs font-medium">Earn creator badges</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-white p-3 rounded-lg">
                <Shield className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-medium">AI content protection</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-start">
          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-subtleborder bg-background">
              <CardHeader className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <Upload className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-2xl text-primary uppercase tracking-wide">
                      Share Your Content
                    </CardTitle>
                    <CardDescription className="font-paragraph text-secondary italic">
                      Contribute book readings, summaries, and multimedia content to the community
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Basic Information */}
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="submittedBy" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Your Name *
                      </Label>
                      <Input
                        id="submittedBy"
                        value={formData.submittedBy}
                        onChange={(e) => handleInputChange('submittedBy', e.target.value)}
                        placeholder="Enter your name"
                        className="border-subtleborder focus:border-primary font-paragraph"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="submissionTitle" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Submission Title *
                      </Label>
                      <Input
                        id="submissionTitle"
                        value={formData.submissionTitle}
                        onChange={(e) => handleInputChange('submissionTitle', e.target.value)}
                        placeholder="e.g., My Analysis of Pride and Prejudice"
                        className="border-subtleborder focus:border-primary font-paragraph"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="submissionType" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Content Type *
                      </Label>
                      <Select value={formData.submissionType} onValueChange={(value) => handleInputChange('submissionType', value)}>
                        <SelectTrigger className="border-subtleborder focus:border-primary font-paragraph">
                          <SelectValue placeholder="Select content type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pdf">PDF/Notes</SelectItem>
                          <SelectItem value="audio">Audio Discussion</SelectItem>
                          <SelectItem value="image">Image/Infographic</SelectItem>
                          <SelectItem value="video">Discussion Video</SelectItem>
                          <SelectItem value="text">Text Content</SelectItem>
                          <SelectItem value="Book Reading">Book Reading</SelectItem>
                          <SelectItem value="Book Summary">Book Summary</SelectItem>
                          <SelectItem value="Book Review">Book Review</SelectItem>
                          <SelectItem value="Literary Analysis">Literary Analysis</SelectItem>
                          <SelectItem value="Reading Notes">Reading Notes</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Book Information */}
                  <div className="space-y-6 pt-6 border-t border-subtleborder">
                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                      Related Book Information
                    </h3>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="bookTitle" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Book Title
                        </Label>
                        <Input
                          id="bookTitle"
                          value={formData.bookTitle}
                          onChange={(e) => handleInputChange('bookTitle', e.target.value)}
                          placeholder="e.g., Pride and Prejudice"
                          className="border-subtleborder focus:border-primary font-paragraph"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bookAuthor" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Author
                        </Label>
                        <Input
                          id="bookAuthor"
                          value={formData.bookAuthor}
                          onChange={(e) => handleInputChange('bookAuthor', e.target.value)}
                          placeholder="e.g., Jane Austen"
                          className="border-subtleborder focus:border-primary font-paragraph"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="space-y-6 pt-6 border-t border-subtleborder">
                    <div className="space-y-2">
                      <Label htmlFor="content" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Your Content *
                      </Label>
                      <Textarea
                        id="content"
                        value={formData.content}
                        onChange={(e) => handleInputChange('content', e.target.value)}
                        placeholder="Share your book reading, summary, analysis, or thoughts here..."
                        className="border-subtleborder focus:border-primary font-paragraph min-h-48"
                        required
                      />
                    </div>
                  </div>

                  {/* Media Uploads */}
                  <div className="space-y-6 pt-6 border-t border-subtleborder">
                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                      Media Attachments & URLs (Optional)
                    </h3>
                    
                    {/* URL Fields */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="pdfNotesUrl" className="font-heading text-sm text-primary uppercase tracking-wide">
                          PDF/Notes URL
                        </Label>
                        <Input
                          id="pdfNotesUrl"
                          value={formData.pdfNotesUrl}
                          onChange={(e) => handleInputChange('pdfNotesUrl', e.target.value)}
                          placeholder="https://example.com/your-pdf-file.pdf"
                          className="border-subtleborder focus:border-primary font-paragraph"
                          type="url"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="discussionVideoUrl" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Discussion Video URL
                        </Label>
                        <Input
                          id="discussionVideoUrl"
                          value={formData.discussionVideoUrl}
                          onChange={(e) => handleInputChange('discussionVideoUrl', e.target.value)}
                          placeholder="https://vimeo.com/... or https://drive.google.com/..."
                          className={`border-subtleborder focus:border-primary font-paragraph ${
                            videoUrlError ? 'border-red-500 focus:border-red-500' : ''
                          }`}
                          type="url"
                        />
                        {videoUrlError && (
                          <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                            <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                            <p className="font-paragraph text-sm text-red-700">{videoUrlError}</p>
                          </div>
                        )}
                        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                          <div className="flex items-start gap-2">
                            <X className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                            <div className="space-y-1">
                              <p className="font-paragraph text-xs text-red-700 font-medium">
                                <strong>Blocked Platforms:</strong> YouTube, Facebook, Instagram, Twitter, Telegram, TikTok, and other social media platforms are not allowed.
                              </p>
                              <p className="font-paragraph text-xs text-red-600">
                                Use direct video hosting services like Vimeo, Google Drive, Dropbox, or OneDrive instead.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* ... keep existing code (audio upload section) ... */}
                    
                    {/* Audio Upload */}
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="audioUpload" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Audio Recording
                        </Label>
                        <p className="font-paragraph text-xs text-secondary italic">
                          Upload an audio file of your book reading or commentary (MP3, WAV, OGG, M4A - Max 50MB)
                        </p>
                        <div className="flex items-center gap-4">
                          <Button
                            type="button"
                            variant="outline"
                            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm"
                            onClick={() => document.getElementById('audioUpload')?.click()}
                          >
                            <Mic className="w-4 h-4 mr-2" />
                            Choose Audio File
                          </Button>
                          <input
                            id="audioUpload"
                            type="file"
                            accept="audio/*"
                            onChange={handleAudioUpload}
                            className="hidden"
                          />
                        </div>
                        
                        {audioPreview && (
                          <div className="p-4 bg-mutedgray/10 rounded-lg border border-subtleborder">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <Mic className="w-4 h-4 text-primary" />
                                <span className="font-heading text-sm text-primary uppercase tracking-wide">
                                  {audioFile?.name}
                                </span>
                              </div>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={removeAudio}
                                className="text-secondary hover:text-primary"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                            <audio controls className="w-full">
                              <source src={audioPreview} type={audioFile?.type} />
                              Your browser does not support the audio element.
                            </audio>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Image Upload */}
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="imageUpload" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Related Image
                        </Label>
                        <p className="font-paragraph text-xs text-secondary italic">
                          Upload an image related to your submission (book cover, notes, etc.) - JPEG, PNG, GIF, WebP - Max 10MB
                        </p>
                        <div className="flex items-center gap-4">
                          <Button
                            type="button"
                            variant="outline"
                            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm"
                            onClick={() => document.getElementById('imageUpload')?.click()}
                          >
                            <ImageIcon className="w-4 h-4 mr-2" />
                            Choose Image File
                          </Button>
                          <input
                            id="imageUpload"
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="hidden"
                          />
                        </div>
                        
                        {imagePreview && (
                          <div className="p-4 bg-mutedgray/10 rounded-lg border border-subtleborder">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <ImageIcon className="w-4 h-4 text-primary" />
                                <span className="font-heading text-sm text-primary uppercase tracking-wide">
                                  {imageFile?.name}
                                </span>
                              </div>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={removeImage}
                                className="text-secondary hover:text-primary"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                            <div className="max-w-xs">
                              <Image src={imagePreview} alt="Preview" className="w-full h-auto rounded-lg border border-subtleborder" />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Document Upload */}
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="documentUpload" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Document File
                        </Label>
                        <p className="font-paragraph text-xs text-secondary italic">
                          Upload a document file related to your submission (PDF, DOC, DOCX, TXT, EPUB, MOBI - Max 25MB)
                        </p>
                        <div className="flex items-center gap-4">
                          <Button
                            type="button"
                            variant="outline"
                            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm"
                            onClick={() => document.getElementById('documentUpload')?.click()}
                          >
                            <Paperclip className="w-4 h-4 mr-2" />
                            Choose Document File
                          </Button>
                          <input
                            id="documentUpload"
                            type="file"
                            accept=".pdf,.doc,.docx,.txt,.epub,.mobi"
                            onChange={handleDocumentUpload}
                            className="hidden"
                          />
                        </div>
                        
                        {documentFile && (
                          <div className="p-4 bg-mutedgray/10 rounded-lg border border-subtleborder">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <FileText className="w-4 h-4 text-primary" />
                                <div>
                                  <span className="font-heading text-sm text-primary uppercase tracking-wide block">
                                    {documentFile.name}
                                  </span>
                                  <span className="font-paragraph text-xs text-secondary italic">
                                    {(documentFile.size / 1024 / 1024).toFixed(2)} MB
                                  </span>
                                </div>
                              </div>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={removeDocument}
                                className="text-secondary hover:text-primary"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-6">
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 font-heading uppercase tracking-wide"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Upload className="w-4 h-4 mr-2" />
                          Submit Content
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Info Section */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Hero Image */}
            <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden">
              <Image
                src="https://static.wixstatic.com/media/179bf7_a25c4ffacc464317b8fd754a4f5f9e46~mv2.png?id=researchers"
                alt="Group of diverse researchers and scientists in a modern laboratory, working together on research, wearing lab coats, collaborative academic environment"
                width={600}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-6">
              <h2 className="font-heading text-3xl text-primary uppercase tracking-tight">
                Share Your Literary Journey
              </h2>
              <p className="font-paragraph text-lg text-secondary italic leading-relaxed">
                Contribute to the hostel's literary community by sharing your book readings, 
                summaries, insights, audio recordings, and visual content. Help fellow residents 
                discover new perspectives and deepen their understanding of literature through 
                multimedia submissions.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Mic className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Audio Recordings
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Upload audio files of your book readings, commentary, or discussions. 
                    Perfect for sharing spoken interpretations and bringing literature to life.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <ImageIcon className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Visual Content
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Share images related to your submissions - book covers, handwritten notes, 
                    visual analyses, or any imagery that enhances your literary content.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <FileText className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Document Files
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Upload document files such as PDFs, Word documents, text files, or e-books 
                    that complement your submission and provide additional resources.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <BookOpen className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Text Content
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Share your personal reading experiences, favorite quotes, and 
                    emotional responses to books that have impacted you.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Upload className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Summaries & Analysis
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Create comprehensive summaries and thoughtful analyses that help 
                    other students understand complex literary works.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Upload className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Multimedia Sharing
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Enhanced submission process supporting text, audio, image, and document uploads 
                    to create rich, engaging content for the hostel community.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 bg-mutedgray/10 rounded-lg border border-subtleborder">
              <h4 className="font-heading text-sm text-primary uppercase tracking-wide mb-3">
                Content Guidelines
              </h4>
              <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                <li>• Choose a clear, descriptive title for your submission</li>
                <li>• Select the appropriate content type (reading, summary, review, etc.)</li>
                <li>• Include book details to help others find related content</li>
                <li>• Add audio recordings for spoken content (max 50MB)</li>
                <li>• Upload relevant images to enhance your submission (max 10MB)</li>
                <li>• Attach document files for additional resources (max 25MB)</li>
                <li>• Write thoughtfully and respectfully for the community</li>
                <li>• Share personal insights and genuine reflections</li>
              </ul>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Content Evaluation Widget */}
      <FeedbackWidget featureName="User Content Submissions" variant="floating" />
    </div>
  );
}