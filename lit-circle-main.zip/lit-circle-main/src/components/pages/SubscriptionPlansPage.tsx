import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Clock, Crown, Star, Zap, Smartphone, Shield } from 'lucide-react';
import { useSubscription } from '@/hooks/use-subscription';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { SubscriptionModal } from '@/components/ui/subscription-prompt';
import { SecureUPIPaymentModal } from '@/components/ui/secure-upi-payment-modal';
import { useToast } from '@/hooks/use-toast';

export default function SubscriptionPlansPage() {
  const { subscription, status, loading, upgradeSubscription } = useSubscription();
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'month1' | 'month2' | null>(null);
  const [upgrading, setUpgrading] = useState(false);
  const { toast } = useToast();

  const handleUpgrade = async (planType: 'month1' | 'month2') => {
    setSelectedPlan(planType);
    setShowUpgradeModal(false);
    setShowPaymentModal(true);
  };

  const handlePaymentSubmitted = async () => {
    if (!selectedPlan) return;
    
    setUpgrading(true);
    try {
      // Note: In a real implementation, this would not immediately activate the subscription
      // Instead, it would mark the payment as "pending verification"
      toast({
        title: "Payment Submitted",
        description: `Your ${selectedPlan === 'month1' ? 'Month 1' : 'Month 2'} plan payment is under review. You'll be notified once verified.`,
      });
      setShowPaymentModal(false);
      setSelectedPlan(null);
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUpgrading(false);
    }
  };

  const handleDirectUpgrade = (planType: 'month1' | 'month2') => {
    setSelectedPlan(planType);
    setShowPaymentModal(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[100rem] mx-auto px-4 py-12">
        {/* Combined Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-heading font-bold text-foreground mb-4">
            Choose Your Reading Journey
          </h1>
          <p className="text-lg font-paragraph text-secondary max-w-2xl mx-auto mb-6">
            Start with 60 days free, then continue with our affordable monthly plans. Secure UPI payment with manual verification for your protection.
          </p>
        </div>

        {/* Current Subscription Status */}
        {status && (
          <Card className="mb-8 border-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl font-heading">Your Current Plan</CardTitle>
                <Badge variant={status.isActive ? "default" : "destructive"}>
                  {status.isActive ? 'Active' : 'Expired'}
                </Badge>
              </div>
              <CardDescription className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                {status.currentPlan} • {status.isActive ? `${status.daysRemaining} days remaining` : 'Expired'}
              </CardDescription>
            </CardHeader>
            {status.canUpgrade && (
              <CardContent>
                <Button onClick={() => setShowUpgradeModal(true)} className="w-full">
                  {status.isActive ? 'Upgrade Plan' : 'Renew Subscription'}
                </Button>
              </CardContent>
            )}
          </Card>
        )}

        {/* Combined Plans & Payment Section */}
        <Card className="mb-12">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-heading">Subscription Plans & Secure Payment</CardTitle>
            <CardDescription>
              Choose your plan and pay securely with UPI - verified manually for your protection
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Subscription Plans Grid */}
            <div className="grid gap-6 grid-cols-1 md:grid-cols-3 mb-8">
              {/* Free Trial */}
              <Card className="border-2">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="h-5 w-5 text-blue-500" />
                    <CardTitle className="font-heading">Free Trial</CardTitle>
                  </div>
                  <CardDescription>Perfect for getting started</CardDescription>
                  <div className="text-3xl font-bold font-heading">Free</div>
                  <p className="text-sm text-muted-foreground">60 days trial</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Access to public reading groups</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Basic discussion participation</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Limited video content</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Community support</span>
                    </li>
                  </ul>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    disabled={status?.subscriptionType === 'free' && status?.isActive}
                  >
                    {status?.subscriptionType === 'free' && status?.isActive ? 'Current Plan' : 'Already Included'}
                  </Button>
                </CardContent>
              </Card>

              {/* Month 1 Plan */}
              <Card className="border-2 border-primary relative">
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                </div>
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="h-5 w-5 text-yellow-500" />
                    <CardTitle className="font-heading">Month 1 Plan</CardTitle>
                  </div>
                  <CardDescription>Enhanced reading experience</CardDescription>
                  <div className="text-3xl font-bold font-heading">₹49</div>
                  <p className="text-sm text-muted-foreground">30 days access</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Access to all reading groups</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Unlimited discussion participation</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Full video content library</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Live session scheduling</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Ad-free experience</span>
                    </li>
                  </ul>
                  <Button 
                    className="w-full"
                    onClick={() => handleDirectUpgrade('month1')}
                    disabled={status?.subscriptionType === 'month1' && status?.isActive}
                  >
                    {status?.subscriptionType === 'month1' && status?.isActive ? 'Current Plan' : 'Pay with UPI'}
                  </Button>
                </CardContent>
              </Card>

              {/* Month 2 Plan */}
              <Card className="border-2">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Crown className="h-5 w-5 text-purple-500" />
                    <CardTitle className="font-heading">Month 2 Plan</CardTitle>
                  </div>
                  <CardDescription>Premium features included</CardDescription>
                  <div className="text-3xl font-bold font-heading">₹49</div>
                  <p className="text-sm text-muted-foreground">30 days access</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">All Month 1 features</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Priority support</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Advanced AI features</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Exclusive content access</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Early feature previews</span>
                    </li>
                  </ul>
                  <Button 
                    variant={status?.nextPlan === 'month1' ? 'outline' : 'default'}
                    className="w-full"
                    onClick={() => handleDirectUpgrade('month2')}
                    disabled={status?.nextPlan === 'month1' || (status?.subscriptionType === 'month2' && status?.isActive)}
                  >
                    {status?.subscriptionType === 'month2' && status?.isActive ? 'Current Plan' :
                     status?.nextPlan === 'month1' ? 'Available after Month 1' : 'Pay with UPI'}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Payment Methods Section */}
            <div className="border-t pt-8">
              <div className="text-center mb-6">
                <h3 className="text-xl font-heading font-semibold mb-2 flex items-center justify-center gap-2">
                  <Shield className="h-5 w-5 text-blue-600" />
                  Secure UPI Payment Only
                </h3>
                <p className="text-sm text-muted-foreground">
                  Enhanced security with manual verification for your protection
                </p>
              </div>

              <div className="max-w-md mx-auto">
                {/* UPI Payment Only */}
                <Card className="border-2 border-green-200 bg-green-50">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                        <Smartphone className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-lg font-heading text-green-800">UPI Payment</CardTitle>
                        <CardDescription className="text-green-600">Secure & Verified</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-green-700 mb-4">
                      <li className="flex items-center gap-2">
                        <Shield className="h-4 w-4" />
                        <span>Double-layer security verification</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4" />
                        <span>Manual approval by website owner</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Smartphone className="h-4 w-4" />
                        <span>Works with all UPI apps</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        <span>Activation within 24 hours</span>
                      </li>
                    </ul>
                    <div className="bg-white p-3 rounded border border-green-300">
                      <p className="text-xs text-green-600 mb-1">UPI ID:</p>
                      <code className="text-sm font-mono text-green-800">nirmalmaurya00717-1@okicici</code>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Security Process Info */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h4 className="font-heading text-sm font-semibold mb-2 text-blue-800 flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Enhanced Security Process:
                </h4>
                <div className="grid gap-4 md:grid-cols-3 text-sm text-blue-700">
                  <div className="flex items-start gap-2">
                    <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">1</div>
                    <div>
                      <p className="font-semibold">Make UPI Payment</p>
                      <p className="text-xs">Pay ₹49 to the provided UPI ID</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">2</div>
                    <div>
                      <p className="font-semibold">Verify Details</p>
                      <p className="text-xs">Enter UPI ID and transaction details</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">3</div>
                    <div>
                      <p className="font-semibold">Manual Approval</p>
                      <p className="text-xs">Owner verifies and activates plan</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Features Comparison */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-2xl font-heading text-center">What's Included</CardTitle>
            <CardDescription className="text-center">
              Compare features across all our plans
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0 sm:p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-xs sm:text-sm md:text-base">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 font-heading">Features</th>
                    <th className="text-center py-3 font-heading">Free Trial</th>
                    <th className="text-center py-3 font-heading">Month 1</th>
                    <th className="text-center py-3 font-heading">Month 2</th>
                  </tr>
                </thead>
                <tbody className="space-y-2">
                  <tr className="border-b">
                    <td className="py-3 font-paragraph">Reading Groups Access</td>
                    <td className="text-center py-3">Public Only</td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 font-paragraph">Discussion Participation</td>
                    <td className="text-center py-3">Limited</td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 font-paragraph">Video Content</td>
                    <td className="text-center py-3">Basic</td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 font-paragraph">Live Sessions</td>
                    <td className="text-center py-3">-</td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 font-paragraph">AI Features</td>
                    <td className="text-center py-3">-</td>
                    <td className="text-center py-3">Basic</td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                  </tr>
                  <tr>
                    <td className="py-3 font-paragraph">Priority Support</td>
                    <td className="text-center py-3">-</td>
                    <td className="text-center py-3">-</td>
                    <td className="text-center py-3"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <div className="text-center">
          <h2 className="text-2xl font-heading font-bold mb-6">Frequently Asked Questions</h2>
          <div className="grid gap-6 md:grid-cols-2 max-w-4xl mx-auto">
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-heading font-semibold mb-2">Why manual verification?</h3>
                <p className="font-paragraph text-sm text-muted-foreground">
                  Manual verification ensures that only legitimate payments are processed and prevents 
                  unauthorized access to premium features, providing enhanced security for all users.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-heading font-semibold mb-2">How long does verification take?</h3>
                <p className="font-paragraph text-sm text-muted-foreground">
                  Our team typically verifies payments within 24 hours. You'll receive a notification 
                  once your subscription is activated and can start enjoying premium features.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Upgrade Modal */}
      <SubscriptionModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        onSubscribe={handleUpgrade}
        currentPlan={status?.currentPlan}
        canUpgrade={status?.canUpgrade}
        nextPlan={status?.nextPlan}
        daysRemaining={status?.daysRemaining}
      />

      {/* Secure UPI Payment Modal */}
      <SecureUPIPaymentModal
        isOpen={showPaymentModal}
        onClose={() => {
          setShowPaymentModal(false);
          setSelectedPlan(null);
        }}
        onPaymentSubmitted={handlePaymentSubmitted}
        planType={selectedPlan || 'month1'}
        amount={49}
      />
    </div>
  );
}