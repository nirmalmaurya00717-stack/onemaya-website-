import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Users, CreditCard, Shield, AlertTriangle, Scale } from 'lucide-react';

export default function TermsConditionsPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[100rem] mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <FileText className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-heading font-bold text-foreground">
              Terms and Conditions
            </h1>
          </div>
          <p className="text-lg font-paragraph text-secondary max-w-3xl mx-auto">
            Please read these terms and conditions carefully before using our book reading platform.
          </p>
          <p className="text-sm font-paragraph text-mutedgray mt-2">
            Last updated: November 3, 2025
          </p>
        </div>

        <div className="grid gap-8 max-w-4xl mx-auto">
          {/* Acceptance of Terms */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <Scale className="h-5 w-5 text-primary" />
                Acceptance of Terms
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                By accessing and using our book reading platform, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
              </p>
            </CardContent>
          </Card>

          {/* Service Description */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Service Description
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="font-paragraph text-sm text-secondary">
                Our platform provides:
              </p>
              <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                <li>• Access to a digital library of books and reading materials</li>
                <li>• Book reading groups and discussion forums</li>
                <li>• Live discussion sessions and educational content</li>
                <li>• AI-powered reading assistance and recommendations</li>
                <li>• Content submission and sharing features</li>
                <li>• Subscription-based premium features</li>
              </ul>
            </CardContent>
          </Card>

          {/* User Accounts */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">User Accounts and Registration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Account Creation</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• You must provide accurate and complete information during registration</li>
                  <li>• You are responsible for maintaining the confidentiality of your account</li>
                  <li>• You must be at least 13 years old to create an account</li>
                  <li>• One account per person is allowed</li>
                </ul>
              </div>
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Account Security</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• You are responsible for all activities under your account</li>
                  <li>• Notify us immediately of any unauthorized use</li>
                  <li>• We reserve the right to suspend accounts for security reasons</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Subscription Terms */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" />
                Subscription and Payment Terms
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Free Trial Period</h3>
                <p className="font-paragraph text-sm text-secondary">
                  New users receive 60 days of free access to basic features. No payment information is required during the trial period.
                </p>
              </div>
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Paid Subscriptions</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• Month 1 Plan: ₹49 for 30 days of premium features</li>
                  <li>• Month 2 Plan: ₹49 for 30 days of advanced features</li>
                  <li>• Payments are processed securely through UPI</li>
                  <li>• All payments require manual verification for security</li>
                  <li>• Subscriptions are non-transferable</li>
                </ul>
              </div>
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Payment Processing</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• Payments are verified manually within 24 hours</li>
                  <li>• You must provide accurate payment information</li>
                  <li>• Failed payments may result in service suspension</li>
                  <li>• All prices are in Indian Rupees (INR)</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* User Conduct */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                User Conduct and Prohibited Activities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="font-paragraph text-sm text-secondary">
                You agree not to engage in any of the following prohibited activities:
              </p>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <h4 className="font-heading text-sm font-semibold mb-2">Content Violations</h4>
                  <ul className="font-paragraph text-xs text-secondary space-y-1 ml-4">
                    <li>• Posting inappropriate or offensive content</li>
                    <li>• Sharing copyrighted material without permission</li>
                    <li>• Uploading malicious files or viruses</li>
                    <li>• Spamming or excessive promotional content</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-heading text-sm font-semibold mb-2">Platform Misuse</h4>
                  <ul className="font-paragraph text-xs text-secondary space-y-1 ml-4">
                    <li>• Attempting to hack or compromise security</li>
                    <li>• Creating multiple accounts to circumvent limits</li>
                    <li>• Interfering with other users' experience</li>
                    <li>• Using automated tools or bots</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Intellectual Property */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Intellectual Property Rights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Our Content</h3>
                <p className="font-paragraph text-sm text-secondary">
                  All content on our platform, including text, graphics, logos, and software, is owned by us or our licensors and is protected by copyright and other intellectual property laws.
                </p>
              </div>
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">User Content</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• You retain ownership of content you submit</li>
                  <li>• You grant us a license to use, display, and distribute your content</li>
                  <li>• You are responsible for ensuring you have rights to submitted content</li>
                  <li>• We may remove content that violates these terms</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Privacy and Data */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Privacy and Data Protection</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                Your privacy is important to us. Our collection and use of personal information is governed by our Privacy Policy, which is incorporated into these terms by reference. By using our service, you consent to the collection and use of your information as described in our Privacy Policy.
              </p>
            </CardContent>
          </Card>

          {/* Service Availability */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Service Availability and Modifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Service Availability</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• We strive to provide continuous service but cannot guarantee 100% uptime</li>
                  <li>• Scheduled maintenance will be announced in advance when possible</li>
                  <li>• We are not liable for service interruptions beyond our control</li>
                </ul>
              </div>
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Service Modifications</h3>
                <p className="font-paragraph text-sm text-secondary">
                  We reserve the right to modify, suspend, or discontinue any part of our service at any time. We will provide reasonable notice of significant changes when possible.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Limitation of Liability */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-600" />
                Limitation of Liability
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                To the maximum extent permitted by law, we shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses resulting from your use of our service.
              </p>
            </CardContent>
          </Card>

          {/* Termination */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Termination</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">By You</h3>
                <p className="font-paragraph text-sm text-secondary">
                  You may terminate your account at any time by contacting us or using the account deletion feature in your profile settings.
                </p>
              </div>
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">By Us</h3>
                <p className="font-paragraph text-sm text-secondary">
                  We may terminate or suspend your account immediately if you violate these terms or engage in prohibited activities. Upon termination, your right to use the service ceases immediately.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Governing Law */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Governing Law and Jurisdiction</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                These terms shall be governed by and construed in accordance with the laws of India. Any disputes arising from these terms or your use of our service shall be subject to the exclusive jurisdiction of the courts of India.
              </p>
            </CardContent>
          </Card>

          {/* Changes to Terms */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Changes to Terms</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                We reserve the right to modify these terms at any time. We will notify users of significant changes via email or platform notifications. Your continued use of the service after changes constitutes acceptance of the new terms.
              </p>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card className="border-2 border-primary bg-blue-50">
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2 text-primary">
                <FileText className="h-5 w-5" />
                Questions About Terms
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary mb-3">
                If you have any questions about these Terms and Conditions, please contact us:
              </p>
              <div className="space-y-2 font-paragraph text-sm">
                <p><strong>Email:</strong> onemaya96@gmail.com</p>
                <p><strong>Address:</strong> Book Reading Platform, Lucknow, Uttar Pradesh, India</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}