import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { BookDiscussionVideos } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, Video, Upload, Play, Link as LinkIcon, AlertTriangle, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function UploadVideoPage() {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [urlError, setUrlError] = useState('');
  const [formData, setFormData] = useState({
    videoTitle: '',
    videoUrl: '',
    description: '',
    thumbnail: '',
    associatedTopic: ''
  });

  // Function to validate video URL
  const validateVideoUrl = (url: string): boolean => {
    if (!url.trim()) {
      setUrlError('');
      return true; // Empty URL is valid (not required yet)
    }

    // List of blocked social media platforms
    const blockedDomains = [
      'youtube.com',
      'youtu.be',
      'facebook.com',
      'fb.com',
      'instagram.com',
      'twitter.com',
      'x.com',
      'telegram.org',
      'telegram.me',
      't.me',
      'tiktok.com',
      'snapchat.com',
      'linkedin.com',
      'pinterest.com',
      'reddit.com',
      'whatsapp.com',
      'discord.com',
      'twitch.tv'
    ];

    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname.toLowerCase();
      
      // Remove 'www.' prefix if present
      const cleanHostname = hostname.replace(/^www\./, '');
      
      // Check if the domain is in the blocked list
      const isBlocked = blockedDomains.some(domain => 
        cleanHostname === domain || cleanHostname.endsWith('.' + domain)
      );

      if (isBlocked) {
        setUrlError('Social media platform links are not allowed. Please use direct video hosting services or upload your content directly to OneMaya.');
        return false;
      }

      setUrlError('');
      return true;
    } catch (error) {
      setUrlError('Please enter a valid URL');
      return false;
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Validate video URL when it changes
    if (field === 'videoUrl') {
      validateVideoUrl(value);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.videoTitle.trim() || !formData.videoUrl.trim() || !formData.description.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    // Validate video URL before submission
    if (!validateVideoUrl(formData.videoUrl)) {
      alert('Please provide a valid video URL from an allowed platform');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const newVideo: BookDiscussionVideos = {
        _id: crypto.randomUUID(),
        videoTitle: formData.videoTitle.trim(),
        videoUrl: formData.videoUrl.trim(),
        description: formData.description.trim(),
        thumbnail: formData.thumbnail.trim() || undefined,
        associatedTopic: formData.associatedTopic.trim() || undefined,
        uploadDate: new Date().toISOString()
      };

      await BaseCrudService.create('bookdiscussionvideos', newVideo);
      alert('Video published successfully! Your submission is now visible to all users.');
      navigate('/library');
    } catch (error) {
      console.error('Error uploading video:', error);
      alert('Failed to upload video. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/library">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Library
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
              Upload Video
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-start">
          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-subtleborder bg-background">
              <CardHeader className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <Video className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-2xl text-primary uppercase tracking-wide">
                      Share Video Discussion
                    </CardTitle>
                    <CardDescription className="font-paragraph text-secondary italic">
                      Upload book discussion videos for the community
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Video Information */}
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="videoTitle" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Video Title *
                      </Label>
                      <Input
                        id="videoTitle"
                        value={formData.videoTitle}
                        onChange={(e) => handleInputChange('videoTitle', e.target.value)}
                        placeholder="e.g., Discussion on The Great Gatsby - Chapter Analysis"
                        className="border-subtleborder focus:border-primary font-paragraph"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="videoUrl" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Video URL *
                      </Label>
                      <Input
                        id="videoUrl"
                        type="url"
                        value={formData.videoUrl}
                        onChange={(e) => handleInputChange('videoUrl', e.target.value)}
                        placeholder="https://vimeo.com/... or https://drive.google.com/..."
                        className={`border-subtleborder focus:border-primary font-paragraph ${
                          urlError ? 'border-red-500 focus:border-red-500' : ''
                        }`}
                        required
                      />
                      {urlError && (
                        <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                          <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                          <p className="font-paragraph text-sm text-red-700">{urlError}</p>
                        </div>
                      )}
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                        <div className="flex items-start gap-2">
                          <X className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                          <div className="space-y-1">
                            <p className="font-paragraph text-xs text-red-700 font-medium">
                              <strong>Blocked Platforms:</strong> YouTube, Facebook, Instagram, Twitter, Telegram, TikTok, and other social media platforms are not allowed.
                            </p>
                            <p className="font-paragraph text-xs text-red-600">
                              Use direct video hosting services like Vimeo, Google Drive, Dropbox, or OneDrive instead.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Video Description *
                      </Label>
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        placeholder="Describe what your video covers, key discussion points, and what viewers can expect to learn..."
                        className="border-subtleborder focus:border-primary font-paragraph min-h-32"
                        required
                      />
                    </div>
                  </div>

                  {/* Optional Information */}
                  <div className="space-y-6 pt-6 border-t border-subtleborder">
                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                      Additional Information
                    </h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="associatedTopic" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Associated Book/Topic
                      </Label>
                      <Input
                        id="associatedTopic"
                        value={formData.associatedTopic}
                        onChange={(e) => handleInputChange('associatedTopic', e.target.value)}
                        placeholder="e.g., The Great Gatsby, Modern Literature, Poetry Analysis"
                        className="border-subtleborder focus:border-primary font-paragraph"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="thumbnail" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Thumbnail Image URL
                      </Label>
                      <Input
                        id="thumbnail"
                        type="url"
                        value={formData.thumbnail}
                        onChange={(e) => handleInputChange('thumbnail', e.target.value)}
                        placeholder="https://example.com/thumbnail.jpg"
                        className="border-subtleborder focus:border-primary font-paragraph"
                      />
                      <p className="font-paragraph text-xs text-secondary italic">
                        Optional: Custom thumbnail image for your video
                      </p>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-6">
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 font-heading uppercase tracking-wide"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                          Uploading...
                        </>
                      ) : (
                        <>
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Video
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Info Section */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <h2 className="font-heading text-3xl text-primary uppercase tracking-tight">
                Share Video Discussions
              </h2>
              <p className="font-paragraph text-lg text-secondary italic leading-relaxed">
                Upload your book discussion videos to help fellow hostel residents engage 
                with literature through visual and audio content. Share your insights, 
                analyses, and reading experiences in video format.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Video className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Discussion Videos
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Record and share your thoughts on books, literary themes, character 
                    analyses, or reading group discussions.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Play className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Educational Content
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Create educational videos that help other students understand 
                    complex literary concepts and improve their reading skills.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <LinkIcon className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Easy Integration
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Simply provide a link to your video on Vimeo, Google Drive, or other 
                    allowed platforms to share with the community.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 bg-mutedgray/10 rounded-lg border border-subtleborder">
              <h4 className="font-heading text-sm text-primary uppercase tracking-wide mb-3">
                Video Guidelines
              </h4>
              <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                <li>• Use a clear, descriptive title that explains your video content</li>
                <li>• Provide a detailed description of what viewers will learn</li>
                <li>• Ensure your video is publicly accessible via the provided URL</li>
                <li>• Tag your video with relevant book titles or literary topics</li>
                <li>• Consider adding a custom thumbnail for better visibility</li>
                <li>• Keep content appropriate for the academic community</li>
              </ul>
            </div>

            <div className="p-6 bg-primary/5 rounded-lg border border-primary/20">
              <h4 className="font-heading text-sm text-primary uppercase tracking-wide mb-3">
                Allowed Platforms
              </h4>
              <div className="grid grid-cols-2 gap-3 font-paragraph text-sm text-secondary italic">
                <div>• Vimeo</div>
                <div>• Google Drive</div>
                <div>• Dropbox</div>
                <div>• OneDrive</div>
                <div>• Direct video links</div>
                <div>• Self-hosted videos</div>
              </div>
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-start gap-2">
                  <X className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-paragraph text-xs text-red-700 font-medium mb-1">
                      <strong>Not Allowed:</strong>
                    </p>
                    <p className="font-paragraph text-xs text-red-600">
                      YouTube, Facebook, Instagram, Twitter, Telegram, TikTok, and other social media platforms
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Content Evaluation Widget */}
      <FeedbackWidget featureName="Video Upload Content" variant="floating" />
    </div>
  );
}