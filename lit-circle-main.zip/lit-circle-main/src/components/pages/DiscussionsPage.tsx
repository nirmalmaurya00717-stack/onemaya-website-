import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { DiscussionTopics } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Image } from '@/components/ui/image';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, MessageCircle, Calendar, Eye, Pin, Search, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';
import { useContentTranslator } from '@/lib/content-translator';

export default function DiscussionsPage() {
  const { t, currentLanguage } = useTranslation();
  const { translateArray } = useContentTranslator();
  const [discussions, setDiscussions] = useState<DiscussionTopics[]>([]);
  const [filteredDiscussions, setFilteredDiscussions] = useState<DiscussionTopics[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchDiscussions = async () => {
      try {
        const { items } = await BaseCrudService.getAll<DiscussionTopics>('discussiontopics');
        
        // Translate discussion topics
        const translatedItems = await translateArray(
          items, 
          ['topicTitle', 'topicContent'], 
          currentLanguage
        );
        
        // Sort by pinned first, then by creation date (newest first)
        const sortedItems = translatedItems.sort((a, b) => {
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;
          
          const dateA = new Date(a.creationDate || 0).getTime();
          const dateB = new Date(b.creationDate || 0).getTime();
          return dateB - dateA;
        });
        
        setDiscussions(sortedItems);
        setFilteredDiscussions(sortedItems);
      } catch (error) {
        console.error('Error fetching discussions:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDiscussions();
  }, [currentLanguage, translateArray]);

  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredDiscussions(discussions);
    } else {
      const filtered = discussions.filter(topic =>
        topic.topicTitle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        topic.topicContent?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredDiscussions(filtered);
    }
  }, [searchTerm, discussions]);

  const formatDateTime = (date: Date | string | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <MessageCircle className="w-12 h-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="font-paragraph text-secondary italic">Loading discussions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background relative overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 opacity-10">
          <Image
            src="https://static.wixstatic.com/media/179bf7_44fb92513b1e4899b8a62d2233c183e0~mv2.png?originWidth=768&originHeight=576"
            alt="Magical floating books representing discussion and imagination"
            width={800}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Groups
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <div className="flex items-center gap-3 flex-1">
              <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
              <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
                All Discussions
              </h1>
            </div>
            
            {/* Decorative Element */}
            <div className="hidden lg:block">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-primary" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="space-y-8 sm:space-y-12">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-4 sm:space-y-6"
          >
            <div className="space-y-3 sm:space-y-4">
              <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-primary uppercase tracking-tight">
                Literary Conversations
              </h2>
              <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto px-4">
                Explore ongoing discussions across all reading groups. Join conversations, 
                share insights, and connect with fellow hostel scholars.
              </p>
            </div>

            {/* Search and Actions */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center max-w-2xl mx-auto px-4">
              <div className="relative flex-1 w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-mutedgray" />
                <Input
                  placeholder="Search discussions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-subtleborder focus:border-primary font-paragraph"
                />
              </div>
              <Button 
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide whitespace-nowrap w-full sm:w-auto"
              >
                <Link to="/new-topic">
                  <Plus className="w-4 h-4 mr-2" />
                  New Topic
                </Link>
              </Button>
            </div>
          </motion.div>

          {/* Discussions List */}
          {filteredDiscussions.length > 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="space-y-4 sm:space-y-6"
            >
              {filteredDiscussions.map((topic, index) => (
                <motion.div
                  key={topic._id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                >
                  <Card className="border-subtleborder hover:border-primary transition-colors duration-300 bg-background">
                    <CardContent className="p-4 sm:p-6 lg:p-8">
                      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 lg:gap-6">
                        <div className="flex-1 space-y-3 sm:space-y-4">
                          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                            {topic.isPinned && (
                              <div className="flex items-center gap-1">
                                <Pin className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                                <Badge variant="default" className="font-paragraph text-xs">
                                  Pinned
                                </Badge>
                              </div>
                            )}
                            <h3 className="font-heading text-lg sm:text-xl text-primary uppercase tracking-wide line-clamp-2">
                              {topic.topicTitle}
                            </h3>
                          </div>
                          
                          <p className="font-paragraph text-sm sm:text-base text-secondary italic leading-relaxed line-clamp-3">
                            {topic.topicContent}
                          </p>
                          
                          <div className="flex flex-wrap items-center gap-3 sm:gap-6 lg:gap-8 text-xs sm:text-sm">
                            <div className="flex items-center gap-2 text-secondary">
                              <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                              <span className="font-paragraph italic">
                                Created {formatDateTime(topic.creationDate)}
                              </span>
                            </div>
                            
                            {topic.viewCount !== undefined && (
                              <div className="flex items-center gap-2 text-secondary">
                                <Eye className="w-3 h-3 sm:w-4 sm:h-4" />
                                <span className="font-paragraph italic">
                                  {topic.viewCount} views
                                </span>
                              </div>
                            )}
                            
                            {topic.lastUpdatedDate && topic.lastUpdatedDate !== topic.creationDate && (
                              <div className="flex items-center gap-2 text-secondary">
                                <MessageCircle className="w-3 h-3 sm:w-4 sm:h-4" />
                                <span className="font-paragraph italic">
                                  Updated {formatDateTime(topic.lastUpdatedDate)}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <Button 
                          asChild 
                          variant="outline"
                          className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide flex-shrink-0 w-full lg:w-auto text-sm"
                        >
                          <Link to={`/topic/${topic._id}`}>
                            View Discussion
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="border-subtleborder bg-background relative overflow-hidden">
                {/* Background Image for Empty State */}
                <div className="absolute inset-0 opacity-5">
                  <Image
                    src="https://static.wixstatic.com/media/179bf7_2472d224b9aa490a97151b28d5215728~mv2.png?originWidth=576&originHeight=384"
                    alt="Stack of books with glowing pages representing potential discussions"
                    width={600}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="relative p-8 sm:p-12 lg:p-16 text-center space-y-6 sm:space-y-8">
                  <MessageCircle className="w-16 h-16 sm:w-20 sm:h-20 text-mutedgray mx-auto" />
                  <div className="space-y-3 sm:space-y-4">
                    <h3 className="font-heading text-2xl sm:text-3xl text-primary uppercase">
                      {searchTerm ? 'No Matching Discussions' : 'No Discussions Yet'}
                    </h3>
                    <p className="font-paragraph text-secondary italic max-w-md mx-auto text-base sm:text-lg px-4">
                      {searchTerm 
                        ? `No discussions found matching "${searchTerm}". Try different keywords or browse all topics.`
                        : 'Be the first to start a literary conversation in the hostel community. Share your thoughts, ask questions, or suggest book recommendations.'
                      }
                    </p>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
                    {searchTerm && (
                      <Button 
                        variant="outline"
                        onClick={() => setSearchTerm('')}
                        className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide w-full sm:w-auto"
                      >
                        Clear Search
                      </Button>
                    )}
                    <Button 
                      asChild
                      className="bg-primary text-primary-foreground hover:bg-primary/90 px-6 sm:px-8 py-3 font-heading uppercase tracking-wide w-full sm:w-auto"
                    >
                      <Link to="/new-topic">
                        <Plus className="w-4 h-4 mr-2" />
                        Start First Discussion
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </main>

      {/* Feedback Widget */}
      <FeedbackWidget featureName="Discussions Feature" variant="floating" />
    </div>
  );
}