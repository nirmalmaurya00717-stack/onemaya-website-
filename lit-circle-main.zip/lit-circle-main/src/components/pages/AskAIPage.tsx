import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Image } from '@/components/ui/image';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, Bot, Send, MessageCircle, BookOpen, Users, Lightbulb, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';

interface AIResponse {
  id: string;
  question: string;
  answer: string;
  timestamp: Date;
  category: string;
}

export default function AskAIPage() {
  const { t } = useTranslation();
  const [question, setQuestion] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [responses, setResponses] = useState<AIResponse[]>([]);

  // Simulated AI responses for demonstration
  const generateAIResponse = (userQuestion: string): string => {
    const lowerQuestion = userQuestion.toLowerCase();
    
    if (lowerQuestion.includes('book') && lowerQuestion.includes('recommend')) {
      return "Based on your interest in literary discussions, I'd recommend starting with classics like '1984' by George Orwell, 'To Kill a Mockingbird' by Harper Lee, or 'The Great Gatsby' by F. Scott Fitzgerald. These books often spark engaging discussions in reading groups. For contemporary options, consider 'The Seven Husbands of Evelyn Hugo' by Taylor Jenkins Reid or 'Educated' by Tara Westover.";
    }
    
    if (lowerQuestion.includes('group') && (lowerQuestion.includes('join') || lowerQuestion.includes('create'))) {
      return "To join a reading group, browse the active groups on the homepage and click 'View' on any group that interests you. To create your own group, click 'Start New Group' and fill in details about your group's focus, current book, and whether it's public or private. Consider what type of books you want to discuss and your meeting preferences.";
    }
    
    if (lowerQuestion.includes('discussion') || lowerQuestion.includes('topic')) {
      return "Great discussions often start with open-ended questions about themes, character development, or personal connections to the story. Try asking: 'What did you think about the main character's choices?' or 'How does this book relate to current events?' You can start new topics in any group or in the general discussions section.";
    }
    
    if (lowerQuestion.includes('hostel') || lowerQuestion.includes('student')) {
      return "This platform is designed specifically for hostel residents across different academic programs (BTech, BSc, BA, etc.). It's a great way to connect with fellow students who share your love of reading, regardless of your field of study. You can find study partners, discuss books related to your coursework, or just enjoy recreational reading together.";
    }
    
    if (lowerQuestion.includes('video') || lowerQuestion.includes('upload')) {
      return "You can upload book discussion videos through the Library section. Click on 'Videos' tab and then 'Upload Video'. These videos can be book reviews, discussion summaries, or literary analysis. Make sure to include a clear title, description, and relevant tags to help others find your content.";
    }
    
    if (lowerQuestion.includes('session') || lowerQuestion.includes('live')) {
      return "Live discussion sessions are scheduled events where group members can meet virtually to discuss books in real-time. You can schedule a session through the Library section under 'Live Sessions'. Include details like the book being discussed, date, time, and meeting link (Zoom, Google Meet, etc.).";
    }
    
    // Default response
    return "Thank you for your question! As an AI assistant for this literary community platform, I'm here to help with book recommendations, group discussions, platform features, and connecting with fellow readers. Could you provide more specific details about what you'd like to know? I can help with finding books, joining discussions, creating groups, or navigating the platform features.";
  };

  const categorizeQuestion = (question: string): string => {
    const lowerQuestion = question.toLowerCase();
    if (lowerQuestion.includes('book') || lowerQuestion.includes('recommend')) return 'Books';
    if (lowerQuestion.includes('group')) return 'Groups';
    if (lowerQuestion.includes('discussion')) return 'Discussions';
    if (lowerQuestion.includes('video') || lowerQuestion.includes('upload')) return 'Videos';
    if (lowerQuestion.includes('session') || lowerQuestion.includes('live')) return 'Live Sessions';
    return 'General';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!question.trim()) {
      alert('Please enter a question');
      return;
    }

    setIsLoading(true);
    
    // Simulate AI processing delay
    setTimeout(() => {
      const newResponse: AIResponse = {
        id: crypto.randomUUID(),
        question: question.trim(),
        answer: generateAIResponse(question.trim()),
        timestamp: new Date(),
        category: categorizeQuestion(question.trim())
      };
      
      setResponses(prev => [newResponse, ...prev]);
      setQuestion('');
      setIsLoading(false);
    }, 1500);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const suggestedQuestions = [
    "What books would you recommend for a literature discussion group?",
    "How do I create a new reading group?",
    "What makes a good discussion topic?",
    "How can I connect with other students in my hostel?",
    "How do I upload a book review video?",
    "When should I schedule live discussion sessions?"
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <div className="flex items-center gap-3">
              <Bot className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
              <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
                Ask AI Assistant
              </h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
          {/* AI Chat Section */}
          <div className="lg:col-span-2 space-y-6 sm:space-y-8">
            {/* Page Header */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center space-y-4 sm:space-y-6"
            >
              <div className="space-y-3 sm:space-y-4">
                <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-primary uppercase tracking-tight">
                  Literary AI Assistant
                </h2>
                <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto">
                  Get instant help with book recommendations, discussion ideas, platform features, 
                  and connecting with fellow hostel readers. Ask me anything!
                </p>
              </div>
            </motion.div>

            {/* Question Form */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="border-subtleborder bg-background">
                <CardHeader className="space-y-3 sm:space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary rounded-full flex items-center justify-center">
                      <Bot className="w-5 h-5 sm:w-6 sm:h-6 text-primary-foreground" />
                    </div>
                    <div>
                      <CardTitle className="font-heading text-lg sm:text-xl text-primary uppercase tracking-wide">
                        Ask Your Question
                      </CardTitle>
                      <CardDescription className="font-paragraph text-secondary italic">
                        I'm here to help with books, discussions, and platform features
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="question" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Your Question
                      </Label>
                      <Textarea
                        id="question"
                        value={question}
                        onChange={(e) => setQuestion(e.target.value)}
                        placeholder="e.g., Can you recommend some books for a philosophy discussion group?"
                        className="border-subtleborder focus:border-primary font-paragraph min-h-24"
                        disabled={isLoading}
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={isLoading || !question.trim()}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-4 sm:py-6 font-heading uppercase tracking-wide"
                    >
                      {isLoading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                          AI is thinking...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Ask AI Assistant
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* AI Responses */}
            {responses.length > 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="space-y-4 sm:space-y-6"
              >
                <h3 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
                  AI Responses
                </h3>
                
                <div className="space-y-4">
                  {responses.map((response, index) => (
                    <motion.div
                      key={response.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                    >
                      <Card className="border-subtleborder bg-background">
                        <CardContent className="p-4 sm:p-6 space-y-4">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-4">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="font-paragraph text-xs">
                                {response.category}
                              </Badge>
                              <div className="flex items-center gap-1 text-xs text-secondary">
                                <Clock className="w-3 h-3" />
                                <span className="font-paragraph italic">
                                  {formatTime(response.timestamp)}
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-3">
                            <div className="p-3 bg-mutedgray/10 rounded-lg">
                              <p className="font-paragraph text-sm sm:text-base text-primary font-medium">
                                Q: {response.question}
                              </p>
                            </div>
                            
                            <div className="flex items-start gap-3">
                              <Bot className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                              <p className="font-paragraph text-sm sm:text-base text-secondary italic leading-relaxed">
                                {response.answer}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="lg:col-span-1 space-y-6 sm:space-y-8"
          >
            {/* AI Assistant Image */}
            <div className="aspect-square w-full rounded-2xl overflow-hidden">
              <Image
                src="https://static.wixstatic.com/media/179bf7_23861adffe7b4dedbb00f17317d56c27~mv2.png?id=scientists"
                alt="Professional scientists in white lab coats working in a research facility, examining data, academic research environment"
                width={400}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Suggested Questions */}
            <Card className="border-subtleborder bg-background">
              <CardHeader>
                <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide flex items-center gap-2">
                  <Lightbulb className="w-5 h-5" />
                  Suggested Questions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {suggestedQuestions.map((suggested, index) => (
                  <button
                    key={index}
                    onClick={() => setQuestion(suggested)}
                    className="w-full text-left p-3 border border-subtleborder rounded-lg hover:border-primary transition-colors duration-200 group"
                  >
                    <p className="font-paragraph text-sm text-secondary italic group-hover:text-primary">
                      {suggested}
                    </p>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* AI Capabilities */}
            <Card className="border-subtleborder bg-background">
              <CardHeader>
                <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide">
                  What I Can Help With
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <BookOpen className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-heading text-sm text-primary uppercase tracking-wide">
                      Book Recommendations
                    </h4>
                    <p className="font-paragraph text-xs text-secondary italic">
                      Personalized suggestions based on genres, themes, and discussion potential
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Users className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-heading text-sm text-primary uppercase tracking-wide">
                      Group Management
                    </h4>
                    <p className="font-paragraph text-xs text-secondary italic">
                      Creating groups, joining discussions, and connecting with readers
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MessageCircle className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-heading text-sm text-primary uppercase tracking-wide">
                      Discussion Ideas
                    </h4>
                    <p className="font-paragraph text-xs text-secondary italic">
                      Conversation starters and engaging topics for book discussions
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Bot className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-heading text-sm text-primary uppercase tracking-wide">
                      Platform Features
                    </h4>
                    <p className="font-paragraph text-xs text-secondary italic">
                      Navigation help, feature explanations, and usage tips
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="border-subtleborder bg-background">
              <CardHeader>
                <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide">
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button asChild variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm">
                  <Link to="/help">
                    How to Use Website
                  </Link>
                </Button>
                <Button asChild variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm">
                  <Link to="/library">
                    Browse Library
                  </Link>
                </Button>
                <Button asChild variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm">
                  <Link to="/discussions">
                    Join Discussions
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>

      {/* Feedback Widget */}
      <FeedbackWidget featureName="AI Assistant Feature" variant="floating" />
    </div>
  );
}