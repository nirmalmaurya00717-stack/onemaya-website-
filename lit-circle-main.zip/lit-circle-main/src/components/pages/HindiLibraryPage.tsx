import { useState, useEffect } from 'react';
import { BaseCrudService } from '@/integrations';
import { PopularBooks } from '@/entities';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Image } from '@/components/ui/image';
import { SEOHelmet } from '@/components/SEOHelmet';
import { BookOpen, Star, Play, FileText, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';
import { PDFViewer } from '@/components/ui/pdf-viewer';
import HindiContentUpload from '../HindiContentUpload';

export default function HindiLibraryPage() {
  const { t, currentLanguage } = useTranslation();
  const [hindiBooks, setHindiBooks] = useState<PopularBooks[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [selectedBook, setSelectedBook] = useState<PopularBooks | null>(null);
  const [showViewer, setShowViewer] = useState(false);

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    return d.toLocaleDateString(currentLanguage === 'en' ? 'en-US' : currentLanguage, { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const fetchBooks = async () => {
    try {
      const booksResponse = await BaseCrudService.getAll<PopularBooks>('popularbooks');
      const allBooks = booksResponse.items;
      
      // Filter Hindi language books - books with Hindi in genre or title
      const filteredHindiBooks = allBooks.filter(book => {
        const title = book.title?.toLowerCase() || '';
        const genre = book.genre?.toLowerCase() || '';
        return title.includes('hindi') || genre.includes('hindi');
      });
      
      setHindiBooks(filteredHindiBooks);
    } catch (error) {
      console.error('Error fetching Hindi books:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getContentType = (title: string | undefined): string => {
    if (!title) return 'Book';
    const lower = title.toLowerCase();
    if (lower.includes('pdf')) return 'PDF';
    if (lower.includes('video')) return 'Video';
    if (lower.includes('summary')) return 'Summary';
    return 'Book';
  };

  const handleViewContent = (book: PopularBooks) => {
    // Check if this is a PDF that can be opened
    const contentType = getContentType(book.title);
    if (contentType === 'PDF' && !book.downloadLink) {
      alert('This PDF is not yet available for viewing. Please try again later.');
      return;
    }
    setSelectedBook(book);
    setShowViewer(true);
  };



  useEffect(() => {
    fetchBooks();
  }, [refreshTrigger]);

  return (
    <>
      <SEOHelmet 
        title="Hindi Language Library"
        description="Explore our collection of Hindi language books and educational materials"
      />
      
      <div className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8 sm:mb-12"
        >
          <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-orange-900 uppercase tracking-wide mb-2">
            Hindi Language Library
          </h1>
          <p className="font-paragraph text-base sm:text-lg text-orange-600 italic">
            हिंदी भाषा की किताबें और शैक्षणिक सामग्री
          </p>
        </motion.div>

        {/* Upload Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mb-12 sm:mb-16"
        >
          <HindiContentUpload onContentUploaded={() => setRefreshTrigger(prev => prev + 1)} />
        </motion.div>

        {/* Books Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <h2 className="font-heading text-xl sm:text-2xl text-orange-900 uppercase tracking-wide mb-6">
            Available Books
          </h2>

          {isLoading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin">
                <BookOpen className="w-8 h-8 text-orange-600" />
              </div>
              <p className="font-paragraph text-orange-600 mt-4">Loading books...</p>
            </div>
          ) : hindiBooks.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
              {hindiBooks.map((book, index) => (
                <motion.div
                  key={`hindi-${book._id}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.05 }}
                >
                  <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-orange-200">
                    <CardContent className="p-4 h-full flex flex-col">
                      {book.coverImage && (
                        <div className="w-full h-48 rounded overflow-hidden bg-gray-100 mb-4">
                          <Image
                            src={book.coverImage}
                            alt={`Cover of ${book.title}`}
                            width={200}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      <div className="flex-1">
                        <h3 className="font-heading text-sm sm:text-base text-orange-900 uppercase tracking-wide line-clamp-2 mb-2">
                          {book.title}
                        </h3>
                        <p className="font-paragraph text-xs sm:text-sm text-orange-600 italic mb-3">
                          by {book.author}
                        </p>
                        {book.averageRating && (
                          <div className="flex items-center gap-2 mb-3">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`w-3 h-3 sm:w-4 sm:h-4 ${i < Math.floor(book.averageRating!) ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                                />
                              ))}
                            </div>
                            <span className="text-xs text-gray-600">{book.averageRating.toFixed(1)}</span>
                          </div>
                        )}
                        {book.genre && (
                          <Badge variant="secondary" className="text-xs bg-orange-100 text-orange-800 mb-4">
                            {getContentType(book.title)}
                          </Badge>
                        )}
                      </div>

                      {/* Status Badge and View Button */}
                      {book.downloadLink ? (
                        <Button
                          onClick={() => handleViewContent(book)}
                          className="w-full bg-orange-600 text-white hover:bg-orange-700 font-heading uppercase tracking-wide text-xs py-2 mt-4 pt-4 border-t border-orange-200"
                        >
                          {getContentType(book.title) === 'Video' ? (
                            <>
                              <Play className="w-3 h-3 mr-1" />
                              View
                            </>
                          ) : getContentType(book.title) === 'PDF' ? (
                            <>
                              <FileText className="w-3 h-3 mr-1" />
                              Open
                            </>
                          ) : (
                            <>
                              <BookOpen className="w-3 h-3 mr-1" />
                              Read
                            </>
                          )}
                        </Button>
                      ) : (
                        <Badge className="w-full text-center justify-center bg-gray-400 text-white font-heading uppercase tracking-wide text-xs py-2 mt-4 pt-4 border-t border-orange-200 rounded-none">
                          Coming Soon
                        </Badge>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 space-y-4 border border-orange-200 rounded-lg bg-orange-50">
              <BookOpen className="w-12 h-12 sm:w-16 sm:h-16 text-orange-300 mx-auto" />
              <div className="space-y-2">
                <h3 className="font-heading text-lg sm:text-xl text-orange-900 uppercase">No Books Available</h3>
                <p className="font-paragraph text-sm sm:text-base text-orange-600 italic max-w-md mx-auto">
                  हिंदी भाषा की किताबें जल्द ही उपलब्ध होंगी। कृपया बाद में देखें।
                </p>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Content Viewer Modal */}
      {showViewer && selectedBook && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-2 sm:p-4"
          onClick={() => setShowViewer(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-lg max-w-5xl w-full h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-white border-b border-orange-200 p-3 sm:p-4 flex items-center justify-between flex-shrink-0 z-10">
              <h2 className="font-heading text-base sm:text-lg text-orange-900 uppercase tracking-wide truncate">
                {selectedBook.title}
              </h2>
              <button
                onClick={() => setShowViewer(false)}
                className="text-orange-600 hover:text-orange-900 text-2xl flex-shrink-0 ml-4"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              {getContentType(selectedBook.title) === 'PDF' ? (
                // PDF Viewer
                <div className="space-y-4">
                  {selectedBook.downloadLink ? (
                    <>
                      <div className="flex items-start gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="font-heading text-sm text-blue-900 uppercase tracking-wide">View Only</p>
                          <p className="font-paragraph text-xs text-blue-700 mt-1">
                            This PDF is protected for viewing only. Download is not available.
                          </p>
                        </div>
                      </div>
                      <PDFViewer 
                        pdfUrl={selectedBook.downloadLink} 
                        title={selectedBook.title}
                        className="w-full"
                      />
                    </>
                  ) : (
                    <div className="flex items-center justify-center p-12 bg-gray-50 border border-gray-200 rounded-lg">
                      <div className="text-center space-y-3">
                        <AlertCircle className="w-8 h-8 text-gray-400 mx-auto" />
                        <div>
                          <p className="font-heading text-sm text-gray-900 uppercase tracking-wide">PDF Not Available</p>
                          <p className="font-paragraph text-xs text-gray-600 mt-1">This PDF is not yet available for viewing.</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : getContentType(selectedBook.title) === 'Video' ? (
                // Video Viewer
                <div className="space-y-4">
                  {selectedBook.downloadLink ? (
                    <div className="bg-black rounded-lg overflow-hidden">
                      <video
                        controls
                        className="w-full h-auto"
                        style={{ maxHeight: '500px' }}
                      >
                        <source src={selectedBook.downloadLink} type="video/mp4" />
                        Your browser does not support the video tag.
                      </video>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center p-12 bg-gray-50 border border-gray-200 rounded-lg">
                      <div className="text-center space-y-3">
                        <AlertCircle className="w-8 h-8 text-gray-400 mx-auto" />
                        <div>
                          <p className="font-heading text-sm text-gray-900 uppercase tracking-wide">Video Not Available</p>
                          <p className="font-paragraph text-xs text-gray-600 mt-1">This video is not yet available for viewing.</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                // Book Details
                <div className="space-y-6">
                  {selectedBook.coverImage && (
                    <div className="flex justify-center">
                      <Image
                        src={selectedBook.coverImage}
                        alt={`Cover of ${selectedBook.title}`}
                        width={300}
                        className="rounded-lg shadow-lg max-h-96"
                      />
                    </div>
                  )}

                  <div className="space-y-4">
                    <div>
                      <h3 className="font-heading text-orange-900 uppercase tracking-wide mb-2">Author</h3>
                      <p className="font-paragraph text-orange-600 italic">{selectedBook.author}</p>
                    </div>

                    {selectedBook.synopsis && (
                      <div>
                        <h3 className="font-heading text-orange-900 uppercase tracking-wide mb-2">Description</h3>
                        <p className="font-paragraph text-orange-700 leading-relaxed">{selectedBook.synopsis}</p>
                      </div>
                    )}

                    {selectedBook.genre && (
                      <div>
                        <h3 className="font-heading text-orange-900 uppercase tracking-wide mb-2">Genre</h3>
                        <Badge className="bg-orange-100 text-orange-800">{selectedBook.genre}</Badge>
                      </div>
                    )}

                    {selectedBook.publicationYear && (
                      <div>
                        <h3 className="font-heading text-orange-900 uppercase tracking-wide mb-2">Publication Year</h3>
                        <p className="font-paragraph text-orange-700">{selectedBook.publicationYear}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </>
  );
}
