import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { ArrowLeft, HelpCircle, BookOpen, Users, MessageCircle, Video, Calendar, Upload, Bot, Search, Plus, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';

export default function HelpPage() {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');

  const gettingStartedSteps = [
    {
      step: 1,
      title: "Explore the Homepage",
      description: "Browse active reading groups and get familiar with the platform layout",
      icon: <Eye className="w-5 h-5" />,
      details: "Start by exploring the homepage to see all active reading groups. Each group shows the current book being read, group description, and whether it's public or private."
    },
    {
      step: 2,
      title: "Join or Create a Group",
      description: "Find a group that interests you or start your own literary community",
      icon: <Users className="w-5 h-5" />,
      details: "Click 'View' on any group to see details and join, or click 'Start New Group' to create your own reading circle with fellow hostel residents."
    },
    {
      step: 3,
      title: "Start Discussions",
      description: "Engage with other readers through meaningful conversations",
      icon: <MessageCircle className="w-5 h-5" />,
      details: "Join existing discussions or start new topics. Share your thoughts about books, ask questions, and connect with fellow students across different academic programs."
    },
    {
      step: 4,
      title: "Explore the Library",
      description: "Discover books, videos, and live sessions",
      icon: <BookOpen className="w-5 h-5" />,
      details: "Visit the Library section to find popular books, watch discussion videos, submit your own content, and join live reading sessions."
    }
  ];

  const features = [
    {
      category: "Reading Groups",
      icon: <Users className="w-6 h-6" />,
      items: [
        {
          title: "Creating a Group",
          content: "Click 'Start New Group' from the homepage. Fill in your group name, description, current book details, and choose if it's public or private. Public groups are open to all hostel residents, while private groups require invitation."
        },
        {
          title: "Joining a Group",
          content: "Browse groups on the homepage and click 'View' on any that interest you. You can see group details, current book, and ongoing discussions before deciding to join."
        },
        {
          title: "Group Management",
          content: "Group creators can manage member access, update current reading selections, and moderate discussions. Members can participate in discussions and suggest new books."
        }
      ]
    },
    {
      category: "Discussions",
      icon: <MessageCircle className="w-6 h-6" />,
      items: [
        {
          title: "Starting a Discussion",
          content: "Click 'New Topic' in any group or from the main discussions page. Write a clear title and detailed content to encourage participation. You can pin important discussions if you're a group moderator."
        },
        {
          title: "Participating in Discussions",
          content: "Browse discussions by clicking 'Browse Discussions' or visiting specific groups. Read topics, share your thoughts, and engage respectfully with different viewpoints from students across various academic backgrounds."
        },
        {
          title: "Discussion Etiquette",
          content: "Maintain respectful dialogue, stay on topic, provide constructive feedback, and be open to different perspectives. Remember that participants come from diverse academic programs (BTech, BSc, BA, etc.)."
        }
      ]
    },
    {
      category: "Library Features",
      icon: <BookOpen className="w-6 h-6" />,
      items: [
        {
          title: "Popular Books",
          content: "Discover highly-rated books with reviews and ratings. Filter by genre, publication year, and average rating. These books are great starting points for new reading groups."
        },
        {
          title: "User Submissions",
          content: "Submit your own book reviews, summaries, or literary analysis. Click 'Upload Content' to share your insights with the community. Include book details and your personal perspective."
        },
        {
          title: "Discussion Videos",
          content: "Watch and upload book discussion videos. These can be reviews, analysis, or group discussion recordings. Click 'Upload Video' to share your content with proper titles and descriptions."
        },
        {
          title: "Live Sessions",
          content: "Schedule and join real-time discussion sessions. Perfect for book clubs wanting to meet virtually. Include session details like date, time, book being discussed, and meeting link."
        }
      ]
    },
    {
      category: "AI Assistant",
      icon: <Bot className="w-6 h-6" />,
      items: [
        {
          title: "Getting Book Recommendations",
          content: "Ask the AI for personalized book suggestions based on your interests, academic background, or discussion group needs. The AI considers factors like genre preferences and group dynamics."
        },
        {
          title: "Platform Help",
          content: "Get instant help with platform features, navigation, and best practices. The AI can guide you through creating groups, starting discussions, or using library features."
        },
        {
          title: "Discussion Ideas",
          content: "Ask for conversation starters, discussion questions, or ways to engage your reading group. The AI can suggest topics based on specific books or general literary themes."
        }
      ]
    }
  ];

  const faqs = [
    {
      question: "Who can use this platform?",
      answer: "This platform is designed for hostel residents across all academic programs including BTech, BSc, BA, and other courses. It's a space for students to connect over shared literary interests regardless of their field of study."
    },
    {
      question: "How do I find books suitable for group discussions?",
      answer: "Check the 'Popular Books' section in the Library for highly-rated options, ask the AI assistant for recommendations based on your group's interests, or browse what other active groups are currently reading."
    },
    {
      question: "Can I be in multiple reading groups?",
      answer: "Yes! You can join multiple groups based on different interests - perhaps one for classic literature, another for contemporary fiction, and one focused on books related to your academic field."
    },
    {
      question: "What if I want to discuss a book that's not in the library?",
      answer: "You can suggest new books through the 'Upload Content' feature, start a discussion about it in any relevant group, or ask the AI assistant for similar book recommendations that might be available."
    },
    {
      question: "How do live discussion sessions work?",
      answer: "Live sessions are scheduled virtual meetings where group members discuss books in real-time. The session organizer provides a meeting link (Zoom, Google Meet, etc.) and manages the discussion agenda."
    },
    {
      question: "Can I upload my own book reviews or analysis?",
      answer: "Absolutely! Use the 'Upload Content' feature in the Library section to share written reviews, or 'Upload Video' to share video content. This helps build a rich resource for the entire community."
    },
    {
      question: "How do I get help if I'm stuck?",
      answer: "Use the AI Assistant feature for instant help with platform features, book recommendations, or discussion ideas. You can also browse this help section or ask questions in the general discussions area."
    },
    {
      question: "What makes a good discussion topic?",
      answer: "Good topics are open-ended, relate to themes or characters in the book, connect to real-world issues, or ask for personal interpretations. Avoid yes/no questions and instead ask 'how' and 'why' questions that encourage detailed responses."
    }
  ];

  const filteredFAQs = faqs.filter(faq => 
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <div className="flex items-center gap-3">
              <HelpCircle className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
              <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
                How to Use Website
              </h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="space-y-8 sm:space-y-12">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-4 sm:space-y-6"
          >
            <div className="space-y-3 sm:space-y-4">
              <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-primary uppercase tracking-tight">
                Platform Guide
              </h2>
              <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto">
                Everything you need to know about connecting with fellow hostel readers, 
                joining discussions, and building your literary community.
              </p>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center max-w-2xl mx-auto">
              <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide text-sm">
                <Link to="/ask-ai">
                  <Bot className="w-4 h-4 mr-2" />
                  Ask AI Assistant
                </Link>
              </Button>
              <Button asChild variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm">
                <Link to="/discussions">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Browse Discussions
                </Link>
              </Button>
            </div>
          </motion.div>

          {/* Help Content Tabs */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Tabs defaultValue="getting-started" className="space-y-6 sm:space-y-8">
              <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 bg-mutedgray/10 p-1 rounded-lg gap-1 sm:gap-0">
                <TabsTrigger 
                  value="getting-started" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-2 py-2"
                >
                  <span className="hidden sm:inline">Getting Started</span>
                  <span className="sm:hidden">Start</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="features" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-2 py-2"
                >
                  Features
                </TabsTrigger>
                <TabsTrigger 
                  value="faqs" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-2 py-2"
                >
                  FAQs
                </TabsTrigger>
                <TabsTrigger 
                  value="tips" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-2 py-2"
                >
                  Tips
                </TabsTrigger>
              </TabsList>

              {/* Getting Started Tab */}
              <TabsContent value="getting-started" className="space-y-6 sm:space-y-8">
                <div className="text-center space-y-4">
                  <h3 className="font-heading text-2xl sm:text-3xl text-primary uppercase tracking-wide">
                    Welcome to Your Literary Community
                  </h3>
                  <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto">
                    Follow these steps to start connecting with fellow hostel residents through books and discussions.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
                  {gettingStartedSteps.map((step, index) => (
                    <motion.div
                      key={step.step}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                    >
                      <Card className="border-subtleborder bg-background h-full">
                        <CardHeader className="space-y-3 sm:space-y-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-heading text-lg">
                              {step.step}
                            </div>
                            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                              {step.icon}
                            </div>
                          </div>
                          <div>
                            <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide">
                              {step.title}
                            </CardTitle>
                            <CardDescription className="font-paragraph text-secondary italic">
                              {step.description}
                            </CardDescription>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="font-paragraph text-sm text-secondary italic leading-relaxed">
                            {step.details}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>

              {/* Features Tab */}
              <TabsContent value="features" className="space-y-6 sm:space-y-8">
                <div className="text-center space-y-4">
                  <h3 className="font-heading text-2xl sm:text-3xl text-primary uppercase tracking-wide">
                    Platform Features Guide
                  </h3>
                  <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto">
                    Detailed explanations of all platform features and how to use them effectively.
                  </p>
                </div>

                <div className="space-y-6 sm:space-y-8">
                  {features.map((feature, index) => (
                    <motion.div
                      key={feature.category}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                    >
                      <Card className="border-subtleborder bg-background">
                        <CardHeader>
                          <CardTitle className="font-heading text-xl text-primary uppercase tracking-wide flex items-center gap-3">
                            {feature.icon}
                            {feature.category}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <Accordion type="single" collapsible className="space-y-2">
                            {feature.items.map((item, itemIndex) => (
                              <AccordionItem key={itemIndex} value={`${feature.category}-${itemIndex}`} className="border-subtleborder">
                                <AccordionTrigger className="font-heading text-sm text-primary uppercase tracking-wide hover:no-underline">
                                  {item.title}
                                </AccordionTrigger>
                                <AccordionContent>
                                  <p className="font-paragraph text-sm text-secondary italic leading-relaxed">
                                    {item.content}
                                  </p>
                                </AccordionContent>
                              </AccordionItem>
                            ))}
                          </Accordion>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>

              {/* FAQs Tab */}
              <TabsContent value="faqs" className="space-y-6 sm:space-y-8">
                <div className="text-center space-y-4">
                  <h3 className="font-heading text-2xl sm:text-3xl text-primary uppercase tracking-wide">
                    Frequently Asked Questions
                  </h3>
                  <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto">
                    Common questions and answers about using the platform and connecting with other readers.
                  </p>
                </div>

                {/* FAQ Search */}
                <div className="max-w-md mx-auto">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-mutedgray" />
                    <input
                      type="text"
                      placeholder="Search FAQs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-subtleborder rounded-lg focus:border-primary focus:outline-none font-paragraph"
                    />
                  </div>
                </div>

                <Card className="border-subtleborder bg-background">
                  <CardContent className="p-4 sm:p-6">
                    <Accordion type="single" collapsible className="space-y-2">
                      {filteredFAQs.map((faq, index) => (
                        <AccordionItem key={index} value={`faq-${index}`} className="border-subtleborder">
                          <AccordionTrigger className="font-heading text-sm sm:text-base text-primary uppercase tracking-wide hover:no-underline text-left">
                            {faq.question}
                          </AccordionTrigger>
                          <AccordionContent>
                            <p className="font-paragraph text-sm sm:text-base text-secondary italic leading-relaxed">
                              {faq.answer}
                            </p>
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>

                    {filteredFAQs.length === 0 && searchTerm && (
                      <div className="text-center py-8 space-y-4">
                        <HelpCircle className="w-12 h-12 text-mutedgray mx-auto" />
                        <div className="space-y-2">
                          <h4 className="font-heading text-lg text-primary uppercase">No Results Found</h4>
                          <p className="font-paragraph text-secondary italic">
                            Try different keywords or ask the AI assistant for help.
                          </p>
                        </div>
                        <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide">
                          <Link to="/ask-ai">
                            <Bot className="w-4 h-4 mr-2" />
                            Ask AI Assistant
                          </Link>
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tips Tab */}
              <TabsContent value="tips" className="space-y-6 sm:space-y-8">
                <div className="text-center space-y-4">
                  <h3 className="font-heading text-2xl sm:text-3xl text-primary uppercase tracking-wide">
                    Tips for Success
                  </h3>
                  <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto">
                    Best practices for making the most of your literary community experience.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
                  <Card className="border-subtleborder bg-background">
                    <CardHeader>
                      <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide flex items-center gap-2">
                        <Users className="w-5 h-5" />
                        Building Community
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                        <li>• Be welcoming to new members from all academic backgrounds</li>
                        <li>• Share your unique perspective based on your field of study</li>
                        <li>• Participate regularly in discussions to build relationships</li>
                        <li>• Suggest books that appeal to diverse interests</li>
                        <li>• Organize virtual meetups for deeper connections</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="border-subtleborder bg-background">
                    <CardHeader>
                      <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide flex items-center gap-2">
                        <MessageCircle className="w-5 h-5" />
                        Great Discussions
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                        <li>• Ask open-ended questions that encourage detailed responses</li>
                        <li>• Connect book themes to real-world experiences</li>
                        <li>• Share personal interpretations and invite others to do the same</li>
                        <li>• Be respectful of different viewpoints and academic perspectives</li>
                        <li>• Use specific examples from the text to support your points</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="border-subtleborder bg-background">
                    <CardHeader>
                      <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide flex items-center gap-2">
                        <BookOpen className="w-5 h-5" />
                        Book Selection
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                        <li>• Choose books with rich themes for discussion</li>
                        <li>• Consider length and reading difficulty for your group</li>
                        <li>• Mix genres to keep things interesting</li>
                        <li>• Include books relevant to different academic fields</li>
                        <li>• Ask for suggestions from group members</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="border-subtleborder bg-background">
                    <CardHeader>
                      <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide flex items-center gap-2">
                        <Bot className="w-5 h-5" />
                        Using AI Help
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                        <li>• Be specific in your questions for better recommendations</li>
                        <li>• Ask for discussion prompts when conversations slow down</li>
                        <li>• Get help with platform features when you're stuck</li>
                        <li>• Request book suggestions based on your academic interests</li>
                        <li>• Use AI for creative ideas to engage your reading group</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </motion.div>

          {/* Bottom CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-center space-y-6 pt-8 border-t border-subtleborder"
          >
            <div className="space-y-4">
              <h3 className="font-heading text-2xl sm:text-3xl text-primary uppercase tracking-wide">
                Still Need Help?
              </h3>
              <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto">
                Our AI assistant is available 24/7 to answer your questions and help you make the most of your literary community experience.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
              <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide">
                <Link to="/ask-ai">
                  <Bot className="w-4 h-4 mr-2" />
                  Ask AI Assistant
                </Link>
              </Button>
              <Button asChild variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide">
                <Link to="/">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Start Reading
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}