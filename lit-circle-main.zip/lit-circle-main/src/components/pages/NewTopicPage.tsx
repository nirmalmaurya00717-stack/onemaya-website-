import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { DiscussionTopics } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, MessageCircle, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function NewTopicPage() {
  const navigate = useNavigate();
  const { groupId } = useParams<{ groupId?: string }>();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    topicTitle: '',
    topicContent: '',
    isPinned: false
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.topicTitle.trim() || !formData.topicContent.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const newTopic: DiscussionTopics = {
        _id: crypto.randomUUID(),
        topicTitle: formData.topicTitle.trim(),
        topicContent: formData.topicContent.trim(),
        isPinned: formData.isPinned,
        viewCount: 0,
        creationDate: new Date().toISOString(),
        lastUpdatedDate: new Date().toISOString()
      };

      await BaseCrudService.create('discussiontopics', newTopic);
      
      // Navigate back to appropriate page
      if (groupId) {
        navigate(`/group/${groupId}`);
      } else {
        navigate('/discussions');
      }
    } catch (error) {
      console.error('Error creating topic:', error);
      alert('Failed to create discussion topic. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const backLink = groupId ? `/group/${groupId}` : '/discussions';
  const backText = groupId ? 'Back to Group' : 'Back to Discussions';

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to={backLink}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                {backText}
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
              New Discussion Topic
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-start">
          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-subtleborder bg-background">
              <CardHeader className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <Plus className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-2xl text-primary uppercase tracking-wide">
                      Start Discussion
                    </CardTitle>
                    <CardDescription className="font-paragraph text-secondary italic">
                      Share your thoughts and engage the hostel community
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Topic Details */}
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="topicTitle" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Discussion Title *
                      </Label>
                      <Input
                        id="topicTitle"
                        value={formData.topicTitle}
                        onChange={(e) => handleInputChange('topicTitle', e.target.value)}
                        placeholder="e.g., Thoughts on Modern Literature vs Classic Works"
                        className="border-subtleborder focus:border-primary font-paragraph"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="topicContent" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Discussion Content *
                      </Label>
                      <Textarea
                        id="topicContent"
                        value={formData.topicContent}
                        onChange={(e) => handleInputChange('topicContent', e.target.value)}
                        placeholder="Share your thoughts, ask questions, or start a conversation about books, reading experiences, or literary themes..."
                        className="border-subtleborder focus:border-primary font-paragraph min-h-32"
                        required
                      />
                    </div>
                  </div>

                  {/* Topic Settings */}
                  <div className="space-y-4 pt-6 border-t border-subtleborder">
                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                      Topic Settings
                    </h3>
                    
                    <div className="flex items-center justify-between p-4 border border-subtleborder rounded-lg">
                      <div className="space-y-1">
                        <Label htmlFor="isPinned" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Pin Topic
                        </Label>
                        <p className="font-paragraph text-sm text-secondary italic">
                          Keep this discussion at the top of the list for important announcements
                        </p>
                      </div>
                      <Switch
                        id="isPinned"
                        checked={formData.isPinned}
                        onCheckedChange={(checked) => handleInputChange('isPinned', checked)}
                      />
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-6">
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 font-heading uppercase tracking-wide"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                          Creating Topic...
                        </>
                      ) : (
                        <>
                          <MessageCircle className="w-4 h-4 mr-2" />
                          Start Discussion
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Info Section */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <h2 className="font-heading text-3xl text-primary uppercase tracking-tight">
                Fostering Literary Dialogue
              </h2>
              <p className="font-paragraph text-lg text-secondary italic leading-relaxed">
                Create meaningful discussions that bring together diverse perspectives from 
                hostel residents across different academic programs. Share insights, ask 
                questions, and build connections through the power of literature.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <MessageCircle className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Engaging Topics
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Start conversations about book recommendations, literary analysis, 
                    reading experiences, or philosophical discussions inspired by literature.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Plus className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Community Building
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Connect with fellow hostel residents who share your passion for reading 
                    and intellectual discourse across academic disciplines.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <ArrowLeft className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Respectful Discourse
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Maintain a welcoming environment where all perspectives are valued 
                    and constructive dialogue flourishes among the hostel community.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 bg-mutedgray/10 rounded-lg border border-subtleborder">
              <h4 className="font-heading text-sm text-primary uppercase tracking-wide mb-3">
                Discussion Guidelines
              </h4>
              <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                <li>• Choose a clear, descriptive title that captures your topic</li>
                <li>• Provide context and background to help others understand</li>
                <li>• Ask open-ended questions to encourage participation</li>
                <li>• Be respectful of different viewpoints and academic backgrounds</li>
                <li>• Use the pin option sparingly for truly important announcements</li>
              </ul>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Content Evaluation Widget */}
      <FeedbackWidget featureName="New Discussion Topic Content" variant="floating" />
    </div>
  );
}