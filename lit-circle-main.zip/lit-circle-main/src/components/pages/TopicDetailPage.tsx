import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { DiscussionTopics } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, MessageCircle, Calendar, Eye, Pin, Heart, Share2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';
import { useContentTranslator } from '@/lib/content-translator';

export default function TopicDetailPage() {
  const { topicId } = useParams<{ topicId: string }>();
  const { t, currentLanguage } = useTranslation();
  const { translateObject } = useContentTranslator();
  const [topic, setTopic] = useState<DiscussionTopics | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchTopic = async () => {
      if (!topicId) return;
      
      try {
        const topicData = await BaseCrudService.getById<DiscussionTopics>('discussiontopics', topicId);
        
        // Translate topic data
        const translatedTopic = await translateObject(
          topicData, 
          ['topicTitle', 'topicContent'], 
          currentLanguage
        );
        setTopic(translatedTopic);

        // Increment view count
        if (topicData) {
          const updatedTopic = {
            ...topicData,
            viewCount: (topicData.viewCount || 0) + 1,
            lastUpdatedDate: new Date().toISOString()
          };
          await BaseCrudService.update('discussiontopics', updatedTopic);
          
          // Update with translated content but keep the incremented view count
          const finalTopic = await translateObject(
            updatedTopic, 
            ['topicTitle', 'topicContent'], 
            currentLanguage
          );
          setTopic(finalTopic);
        }
      } catch (error) {
        console.error('Error fetching topic:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTopic();
  }, [topicId, currentLanguage, translateObject]);

  const formatDateTime = (date: Date | string | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { 
      weekday: 'long',
      month: 'long', 
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: topic?.topicTitle || 'Discussion Topic',
          text: topic?.topicContent || 'Check out this discussion',
          url: window.location.href,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <MessageCircle className="w-12 h-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="font-paragraph text-secondary italic">Loading discussion...</p>
        </div>
      </div>
    );
  }

  if (!topic) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <MessageCircle className="w-16 h-16 text-mutedgray mx-auto" />
          <h2 className="font-heading text-2xl text-primary uppercase">Discussion Not Found</h2>
          <p className="font-paragraph text-secondary italic">This discussion topic doesn't exist or has been removed.</p>
          <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Link to="/discussions">Return to Discussions</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/discussions">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Discussions
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <div className="flex items-center gap-3 min-w-0">
              <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 text-primary flex-shrink-0" />
              <h1 className="font-heading text-lg sm:text-xl text-primary uppercase tracking-wide line-clamp-1 min-w-0">
                {topic.topicTitle}
              </h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="max-w-4xl mx-auto space-y-8 sm:space-y-12">
          {/* Topic Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-4 sm:space-y-6"
          >
            <div className="flex items-start gap-4">
              {topic.isPinned && (
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Pin className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                  <Badge variant="default" className="font-paragraph text-xs sm:text-sm">
                    Pinned Discussion
                  </Badge>
                </div>
              )}
            </div>

            <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-primary uppercase tracking-tight leading-tight">
              {topic.topicTitle}
            </h1>

            <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-xs sm:text-sm text-secondary">
              <div className="flex items-center gap-2">
                <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="font-paragraph italic">
                  Started {formatDateTime(topic.creationDate)}
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <Eye className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="font-paragraph italic">
                  {topic.viewCount || 0} views
                </span>
              </div>
              
              {topic.lastUpdatedDate && topic.lastUpdatedDate !== topic.creationDate && (
                <div className="flex items-center gap-2">
                  <MessageCircle className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="font-paragraph italic">
                    Updated {formatDateTime(topic.lastUpdatedDate)}
                  </span>
                </div>
              )}
            </div>
          </motion.div>

          {/* Topic Content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="border-subtleborder bg-background">
              <CardContent className="p-6 sm:p-8 lg:p-12">
                <div className="prose prose-lg max-w-none">
                  <p className="font-paragraph text-base sm:text-lg text-secondary italic leading-relaxed whitespace-pre-wrap">
                    {topic.topicContent}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-wrap gap-3 sm:gap-4 justify-center"
          >
            <Button 
              variant="outline"
              onClick={handleShare}
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm flex-1 sm:flex-none"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share Discussion
            </Button>
            
            <Button 
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide text-sm flex-1 sm:flex-none"
            >
              <Heart className="w-4 h-4 mr-2" />
              Like Topic
            </Button>
            
            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide text-sm flex-1 sm:flex-none"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Join Discussion
            </Button>
          </motion.div>

          {/* Comments Section Placeholder */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="space-y-8"
          >
            <div className="text-center space-y-4 border-t border-subtleborder pt-12">
              <h2 className="font-heading text-2xl text-primary uppercase tracking-wide">
                Discussion Comments
              </h2>
              <p className="font-paragraph text-secondary italic">
                Join the conversation and share your thoughts with fellow hostel residents
              </p>
            </div>

            <Card className="border-subtleborder bg-background">
              <CardContent className="p-12 text-center space-y-6">
                <MessageCircle className="w-16 h-16 text-mutedgray mx-auto" />
                <div className="space-y-2">
                  <h3 className="font-heading text-xl text-primary uppercase">
                    No Comments Yet
                  </h3>
                  <p className="font-paragraph text-secondary italic max-w-md mx-auto">
                    Be the first to share your thoughts on this discussion. 
                    Your perspective could spark an engaging conversation.
                  </p>
                </div>
                <Button 
                  className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-3 font-heading uppercase tracking-wide"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Add Comment
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Related Discussions */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="space-y-6 border-t border-subtleborder pt-12"
          >
            <div className="text-center space-y-4">
              <h2 className="font-heading text-2xl text-primary uppercase tracking-wide">
                Continue Exploring
              </h2>
              <p className="font-paragraph text-secondary italic">
                Discover more literary conversations in the hostel community
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                asChild
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide"
              >
                <Link to="/discussions">
                  Browse All Discussions
                </Link>
              </Button>
              
              <Button 
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide"
              >
                <Link to="/new-topic">
                  Start New Topic
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Content Evaluation Widget */}
      <FeedbackWidget featureName="Discussion Topic Content" variant="floating" />
    </div>
  );
}