import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Eye, Lock, Database, UserCheck, Mail } from 'lucide-react';

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[100rem] mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Shield className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-heading font-bold text-foreground">
              Privacy Policy
            </h1>
          </div>
          <p className="text-lg font-paragraph text-secondary max-w-3xl mx-auto">
            Your privacy is important to us. This policy explains how we collect, use, and protect your personal information.
          </p>
          <p className="text-sm font-paragraph text-mutedgray mt-2">
            Last updated: November 3, 2025
          </p>
        </div>

        <div className="grid gap-8 max-w-4xl mx-auto">
          {/* Information We Collect */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <Database className="h-5 w-5 text-primary" />
                Information We Collect
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Personal Information</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• Name and email address when you create an account</li>
                  <li>• Profile information you choose to provide</li>
                  <li>• Payment information for subscription services</li>
                  <li>• Communication preferences and feedback</li>
                </ul>
              </div>
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Usage Information</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• Pages visited and features used</li>
                  <li>• Reading groups and discussions participated in</li>
                  <li>• Content submissions and interactions</li>
                  <li>• Device and browser information</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* How We Use Information */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <Eye className="h-5 w-5 text-primary" />
                How We Use Your Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="font-paragraph text-sm text-secondary space-y-2">
                <li>• <strong>Service Provision:</strong> To provide and maintain our book reading platform</li>
                <li>• <strong>Account Management:</strong> To manage your account and subscription</li>
                <li>• <strong>Communication:</strong> To send important updates and respond to inquiries</li>
                <li>• <strong>Personalization:</strong> To recommend books and content based on your interests</li>
                <li>• <strong>Security:</strong> To protect against fraud and unauthorized access</li>
                <li>• <strong>Improvement:</strong> To analyze usage and improve our services</li>
              </ul>
            </CardContent>
          </Card>

          {/* Data Protection */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Data Protection & Security
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="font-paragraph text-sm text-secondary">
                We implement appropriate technical and organizational measures to protect your personal information:
              </p>
              <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                <li>• Encryption of sensitive data in transit and at rest</li>
                <li>• Regular security assessments and updates</li>
                <li>• Limited access to personal information on a need-to-know basis</li>
                <li>• Secure payment processing through trusted providers</li>
                <li>• Regular backups and disaster recovery procedures</li>
              </ul>
            </CardContent>
          </Card>

          {/* Information Sharing */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <UserCheck className="h-5 w-5 text-primary" />
                Information Sharing
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="font-paragraph text-sm text-secondary">
                We do not sell, trade, or rent your personal information to third parties. We may share information only in these limited circumstances:
              </p>
              <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                <li>• <strong>Service Providers:</strong> With trusted partners who help us operate our platform</li>
                <li>• <strong>Legal Requirements:</strong> When required by law or to protect our rights</li>
                <li>• <strong>Business Transfers:</strong> In case of merger, acquisition, or sale of assets</li>
                <li>• <strong>Consent:</strong> When you explicitly consent to sharing</li>
              </ul>
            </CardContent>
          </Card>

          {/* Your Rights */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Your Rights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary mb-3">
                You have the following rights regarding your personal information:
              </p>
              <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                <li>• <strong>Access:</strong> Request a copy of your personal information</li>
                <li>• <strong>Correction:</strong> Update or correct inaccurate information</li>
                <li>• <strong>Deletion:</strong> Request deletion of your personal information</li>
                <li>• <strong>Portability:</strong> Request transfer of your data to another service</li>
                <li>• <strong>Objection:</strong> Object to certain processing of your information</li>
                <li>• <strong>Withdrawal:</strong> Withdraw consent for data processing</li>
              </ul>
            </CardContent>
          </Card>

          {/* Cookies and Tracking */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Cookies and Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary mb-3">
                We use cookies and similar technologies to enhance your experience:
              </p>
              <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                <li>• <strong>Essential Cookies:</strong> Required for basic site functionality</li>
                <li>• <strong>Preference Cookies:</strong> Remember your settings and preferences</li>
                <li>• <strong>Analytics Cookies:</strong> Help us understand how you use our site</li>
                <li>• <strong>Marketing Cookies:</strong> Used to show relevant content and ads</li>
              </ul>
            </CardContent>
          </Card>

          {/* Data Retention */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Data Retention</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                We retain your personal information only as long as necessary to provide our services and comply with legal obligations. Account information is typically retained until you delete your account, while usage data may be retained for analytical purposes in anonymized form.
              </p>
            </CardContent>
          </Card>

          {/* Children's Privacy */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Children's Privacy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                Our service is not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us to have it removed.
              </p>
            </CardContent>
          </Card>

          {/* Changes to Policy */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Changes to This Policy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date. We encourage you to review this Privacy Policy periodically for any changes.
              </p>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card className="border-2 border-primary bg-blue-50">
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2 text-primary">
                <Mail className="h-5 w-5" />
                Contact Us About Privacy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary mb-3">
                If you have any questions about this Privacy Policy or our data practices, please contact us:
              </p>
              <div className="space-y-2 font-paragraph text-sm">
                <p><strong>Email:</strong> onemaya96@gmail.com</p>
                <p><strong>Address:</strong> Book Reading Platform, Lucknow, Uttar Pradesh, India</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}