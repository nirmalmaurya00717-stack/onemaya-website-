import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { UserFeedback } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, MessageSquare, Star, TrendingUp, Users, Calendar, Filter, Target, BookOpen } from 'lucide-react';
import { motion } from 'framer-motion';

export default function FeedbackPage() {
  const [feedbacks, setFeedbacks] = useState<UserFeedback[]>([]);
  const [filteredFeedbacks, setFilteredFeedbacks] = useState<UserFeedback[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');

  useEffect(() => {
    const fetchFeedbacks = async () => {
      try {
        const { items } = await BaseCrudService.getAll<UserFeedback>('userfeedback');
        // Sort by most recent first
        const sortedItems = items.sort((a, b) => 
          new Date(b.submissionDateTime || b._createdDate || 0).getTime() - 
          new Date(a.submissionDateTime || a._createdDate || 0).getTime()
        );
        setFeedbacks(sortedItems);
        setFilteredFeedbacks(sortedItems);
      } catch (error) {
        console.error('Error fetching feedbacks:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchFeedbacks();
  }, []);

  useEffect(() => {
    let filtered = feedbacks;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(feedback =>
        feedback.featureName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        feedback.comment?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        feedback.userName?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter by feedback type
    if (selectedType !== 'all') {
      filtered = filtered.filter(feedback => feedback.feedbackType === selectedType);
    }

    setFilteredFeedbacks(filtered);
  }, [feedbacks, searchTerm, selectedType]);

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const renderStars = (rating: number | undefined) => {
    if (!rating) return null;
    const stars = [];
    const maxStars = 10;
    for (let i = 0; i < maxStars; i++) {
      stars.push(
        <Star 
          key={i} 
          className={`w-4 h-4 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} 
        />
      );
    }
    return (
      <div className="flex items-center gap-1">
        {stars}
        <span className="ml-2 font-heading text-sm text-primary">{rating}/10</span>
      </div>
    );
  };

  const getAverageRating = () => {
    const ratingsWithValues = feedbacks.filter(f => f.rating && f.rating > 0);
    if (ratingsWithValues.length === 0) return 0;
    const sum = ratingsWithValues.reduce((acc, f) => acc + (f.rating || 0), 0);
    return sum / ratingsWithValues.length;
  };

  const getFeedbackTypeCount = (type: string) => {
    return feedbacks.filter(f => f.feedbackType === type).length;
  };

  const getFeatureStats = () => {
    const featureMap = new Map<string, { count: number; avgRating: number; totalRating: number; ratingCount: number }>();
    
    feedbacks.forEach(feedback => {
      const feature = feedback.featureName || 'Unknown';
      const current = featureMap.get(feature) || { count: 0, avgRating: 0, totalRating: 0, ratingCount: 0 };
      
      current.count += 1;
      if (feedback.rating && feedback.rating > 0) {
        current.totalRating += feedback.rating;
        current.ratingCount += 1;
        current.avgRating = current.totalRating / current.ratingCount;
      }
      
      featureMap.set(feature, current);
    });

    return Array.from(featureMap.entries())
      .map(([feature, stats]) => ({ feature, ...stats }))
      .sort((a, b) => b.count - a.count);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <MessageSquare className="w-12 h-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="font-paragraph text-secondary italic">Loading feedback...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <div className="flex items-center gap-3">
              <Target className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
              <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
                Content Evaluation Dashboard
              </h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="space-y-8 sm:space-y-12">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-4 sm:space-y-6"
          >
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-primary uppercase tracking-tight">
              Content Evaluation System
            </h2>
            <p className="font-paragraph text-base sm:text-lg text-secondary italic max-w-2xl mx-auto">
              Evaluate content quality with real-life examples and practical knowledge assessments to help identify top creators
            </p>
          </motion.div>

          {/* Stats Overview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            <Card className="border-subtleborder bg-background">
              <CardContent className="p-6 text-center">
                <div className="space-y-2">
                  <div className="font-heading text-2xl text-primary">{feedbacks.length}</div>
                  <div className="font-paragraph text-sm text-secondary italic">Total Evaluations</div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-subtleborder bg-background">
              <CardContent className="p-6 text-center">
                <div className="space-y-2">
                  <div className="font-heading text-2xl text-primary">{getAverageRating().toFixed(1)}</div>
                  <div className="font-paragraph text-sm text-secondary italic">Average Rating (/10)</div>
                  <div className="flex justify-center">
                    {renderStars(Math.round(getAverageRating()))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-subtleborder bg-background">
              <CardContent className="p-6 text-center">
                <div className="space-y-2">
                  <div className="font-heading text-2xl text-primary">{getFeedbackTypeCount('content-evaluation')}</div>
                  <div className="font-paragraph text-sm text-secondary italic">Content Evaluations</div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-subtleborder bg-background">
              <CardContent className="p-6 text-center">
                <div className="space-y-2">
                  <div className="font-heading text-2xl text-primary">{getFeedbackTypeCount('creator-assessment')}</div>
                  <div className="font-paragraph text-sm text-secondary italic">Creator Assessments</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Tabs */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Tabs defaultValue="all-feedback" className="space-y-6 sm:space-y-8">
              <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 md:grid-cols-3 bg-mutedgray/10 p-1 rounded-lg">
                <TabsTrigger 
                  value="all-feedback" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  All Evaluations
                </TabsTrigger>
                <TabsTrigger 
                  value="feature-stats" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  Content Stats
                </TabsTrigger>
                <TabsTrigger 
                  value="submit-feedback" 
                  className="font-heading uppercase tracking-wide text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  Submit Evaluation
                </TabsTrigger>
              </TabsList>

              {/* All Evaluations Tab */}
              <TabsContent value="all-feedback" className="space-y-6">
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search evaluations..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="border-subtleborder focus:border-primary font-paragraph"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant={selectedType === 'all' ? 'default' : 'outline'}
                      onClick={() => setSelectedType('all')}
                      size="sm"
                      className="font-heading uppercase tracking-wide text-xs"
                    >
                      All
                    </Button>
                    <Button
                      variant={selectedType === 'content-evaluation' ? 'default' : 'outline'}
                      onClick={() => setSelectedType('content-evaluation')}
                      size="sm"
                      className="font-heading uppercase tracking-wide text-xs"
                    >
                      Content Quality
                    </Button>
                    <Button
                      variant={selectedType === 'creator-assessment' ? 'default' : 'outline'}
                      onClick={() => setSelectedType('creator-assessment')}
                      size="sm"
                      className="font-heading uppercase tracking-wide text-xs"
                    >
                      Creator Assessment
                    </Button>
                    <Button
                      variant={selectedType === 'educational-value' ? 'default' : 'outline'}
                      onClick={() => setSelectedType('educational-value')}
                      size="sm"
                      className="font-heading uppercase tracking-wide text-xs"
                    >
                      Educational Value
                    </Button>
                  </div>
                </div>

                {/* Evaluation List */}
                {filteredFeedbacks.length > 0 ? (
                  <div className="space-y-4">
                    {filteredFeedbacks.map((feedback, index) => (
                      <motion.div
                        key={feedback._id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.05 }}
                      >
                        <Card className="border-subtleborder bg-background hover:border-primary transition-colors duration-300">
                          <CardContent className="p-6">
                            <div className="space-y-4">
                              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                                <div className="space-y-2">
                                  <div className="flex items-center gap-3">
                                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                                      {feedback.featureName}
                                    </h3>
                                    {feedback.rating && renderStars(feedback.rating)}
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Badge 
                                      variant="outline" 
                                      className={`font-paragraph text-xs ${
                                        feedback.feedbackType === 'content-evaluation' ? 'border-blue-500 text-blue-700' :
                                        feedback.feedbackType === 'creator-assessment' ? 'border-green-500 text-green-700' :
                                        feedback.feedbackType === 'educational-value' ? 'border-purple-500 text-purple-700' :
                                        feedback.feedbackType === 'practical-application' ? 'border-orange-500 text-orange-700' :
                                        'border-gray-500 text-gray-700'
                                      }`}
                                    >
                                      {feedback.feedbackType?.replace('-', ' ') || 'General'}
                                    </Badge>
                                    <span className="font-paragraph text-xs text-secondary italic">
                                      by {feedback.userName || 'Anonymous'}
                                    </span>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2 text-xs text-secondary">
                                  <Calendar className="w-3 h-3" />
                                  <span className="font-paragraph italic">
                                    {formatDate(feedback.submissionDateTime)}
                                  </span>
                                </div>
                              </div>
                              
                              <div className="space-y-3">
                                {feedback.comment && (
                                  <div className="space-y-2">
                                    {feedback.comment.includes('Real-life examples:') ? (
                                      <div className="space-y-3">
                                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                                          <div className="flex items-center gap-2 mb-2">
                                            <BookOpen className="w-4 h-4 text-blue-600" />
                                            <h4 className="font-heading text-sm text-blue-800 uppercase tracking-wide">Real-life Examples</h4>
                                          </div>
                                          <p className="font-paragraph text-sm text-blue-700 italic leading-relaxed">
                                            {feedback.comment.split('\n\nPractical knowledge:')[0].replace('Real-life examples: ', '')}
                                          </p>
                                        </div>
                                        {feedback.comment.includes('Practical knowledge:') && (
                                          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                                            <div className="flex items-center gap-2 mb-2">
                                              <Target className="w-4 h-4 text-green-600" />
                                              <h4 className="font-heading text-sm text-green-800 uppercase tracking-wide">Practical Knowledge</h4>
                                            </div>
                                            <p className="font-paragraph text-sm text-green-700 italic leading-relaxed">
                                              {feedback.comment.split('\n\nPractical knowledge:')[1]}
                                            </p>
                                          </div>
                                        )}
                                      </div>
                                    ) : (
                                      <p className="font-paragraph text-secondary italic leading-relaxed">
                                        {feedback.comment}
                                      </p>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <Card className="border-subtleborder bg-background">
                    <CardContent className="p-12 text-center space-y-6">
                      <Target className="w-16 h-16 text-mutedgray mx-auto" />
                      <div className="space-y-2">
                        <h3 className="font-heading text-2xl text-primary uppercase">No Evaluations Found</h3>
                        <p className="font-paragraph text-secondary italic">
                          {searchTerm || selectedType !== 'all' 
                            ? 'Try adjusting your filters or search terms.'
                            : 'Be the first to evaluate content quality for creator selection.'
                          }
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* Content Stats Tab */}
              <TabsContent value="feature-stats" className="space-y-6">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {getFeatureStats().map((stat, index) => (
                    <motion.div
                      key={stat.feature}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                    >
                      <Card className="border-subtleborder bg-background">
                        <CardHeader>
                          <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide">
                            {stat.feature}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex items-center justify-between">
                            <span className="font-paragraph text-sm text-secondary italic">Total Evaluations</span>
                            <Badge className="bg-blue-100 text-blue-800">{stat.count}</Badge>
                          </div>
                          {stat.ratingCount > 0 && (
                            <div className="flex items-center justify-between">
                              <span className="font-paragraph text-sm text-secondary italic">Average Rating</span>
                              <div className="flex items-center gap-2">
                                <span className="font-heading text-sm text-primary">{stat.avgRating.toFixed(1)}/10</span>
                                {renderStars(Math.round(stat.avgRating))}
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>

              {/* Submit Evaluation Tab */}
              <TabsContent value="submit-feedback" className="space-y-6">
                <div className="max-w-2xl mx-auto">
                  <FeedbackWidget featureName="Content Evaluation" variant="inline" />
                </div>
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </main>

      {/* Evaluation Widget */}
      <FeedbackWidget featureName="Content Evaluation" variant="floating" />
    </div>
  );
}