import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { LiveDiscussionSessions } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Calendar, Video, Users, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function ScheduleSessionPage() {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    sessionTopic: '',
    sessionDate: '',
    sessionTime: '',
    discussedBook: '',
    maxParticipants: '6',
    sessionLink: '',
    sessionDescription: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.sessionTopic.trim() || !formData.sessionDate || !formData.sessionTime || !formData.sessionDescription.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const newSession: LiveDiscussionSessions = {
        _id: crypto.randomUUID(),
        sessionTopic: formData.sessionTopic.trim(),
        sessionDate: formData.sessionDate,
        sessionTime: formData.sessionTime,
        discussedBook: formData.discussedBook.trim() || undefined,
        maxParticipants: parseInt(formData.maxParticipants) || 6,
        sessionLink: formData.sessionLink.trim() || undefined,
        sessionDescription: formData.sessionDescription.trim()
      };

      await BaseCrudService.create('livediscussionsessions', newSession);
      navigate('/library');
    } catch (error) {
      console.error('Error scheduling session:', error);
      alert('Failed to schedule session. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/library">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Library
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <h1 className="font-heading text-xl sm:text-2xl text-primary uppercase tracking-wide">
              Schedule Live Session
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-start">
          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-subtleborder bg-background">
              <CardHeader className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-2xl text-primary uppercase tracking-wide">
                      Schedule Discussion
                    </CardTitle>
                    <CardDescription className="font-paragraph text-secondary italic">
                      Organize live video discussions for small groups
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Session Information */}
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="sessionTopic" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Session Topic *
                      </Label>
                      <Input
                        id="sessionTopic"
                        value={formData.sessionTopic}
                        onChange={(e) => handleInputChange('sessionTopic', e.target.value)}
                        placeholder="e.g., Exploring Themes in Modern Literature"
                        className="border-subtleborder focus:border-primary font-paragraph"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="sessionDescription" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Session Description *
                      </Label>
                      <Textarea
                        id="sessionDescription"
                        value={formData.sessionDescription}
                        onChange={(e) => handleInputChange('sessionDescription', e.target.value)}
                        placeholder="Describe what will be discussed, the agenda, and what participants can expect..."
                        className="border-subtleborder focus:border-primary font-paragraph min-h-24"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="discussedBook" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Featured Book/Topic
                      </Label>
                      <Input
                        id="discussedBook"
                        value={formData.discussedBook}
                        onChange={(e) => handleInputChange('discussedBook', e.target.value)}
                        placeholder="e.g., To Kill a Mockingbird, Poetry Analysis"
                        className="border-subtleborder focus:border-primary font-paragraph"
                      />
                    </div>
                  </div>

                  {/* Schedule Details */}
                  <div className="space-y-6 pt-6 border-t border-subtleborder">
                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                      Schedule Details
                    </h3>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="sessionDate" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Date *
                        </Label>
                        <Input
                          id="sessionDate"
                          type="date"
                          value={formData.sessionDate}
                          onChange={(e) => handleInputChange('sessionDate', e.target.value)}
                          className="border-subtleborder focus:border-primary font-paragraph"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="sessionTime" className="font-heading text-sm text-primary uppercase tracking-wide">
                          Time *
                        </Label>
                        <Input
                          id="sessionTime"
                          type="time"
                          value={formData.sessionTime}
                          onChange={(e) => handleInputChange('sessionTime', e.target.value)}
                          className="border-subtleborder focus:border-primary font-paragraph"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="maxParticipants" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Maximum Participants
                      </Label>
                      <Input
                        id="maxParticipants"
                        type="number"
                        min="2"
                        max="10"
                        value={formData.maxParticipants}
                        onChange={(e) => handleInputChange('maxParticipants', e.target.value)}
                        className="border-subtleborder focus:border-primary font-paragraph"
                      />
                      <p className="font-paragraph text-xs text-secondary italic">
                        Recommended: 5-6 participants for optimal discussion
                      </p>
                    </div>
                  </div>

                  {/* Video Link */}
                  <div className="space-y-6 pt-6 border-t border-subtleborder">
                    <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                      Video Conference Link
                    </h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="sessionLink" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Meeting Link
                      </Label>
                      <Input
                        id="sessionLink"
                        type="url"
                        value={formData.sessionLink}
                        onChange={(e) => handleInputChange('sessionLink', e.target.value)}
                        placeholder="https://zoom.us/j/... or https://meet.google.com/..."
                        className="border-subtleborder focus:border-primary font-paragraph"
                      />
                      <p className="font-paragraph text-xs text-secondary italic">
                        Zoom, Google Meet, Microsoft Teams, or any video conferencing platform
                      </p>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-6">
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 font-heading uppercase tracking-wide"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                          Scheduling...
                        </>
                      ) : (
                        <>
                          <Calendar className="w-4 h-4 mr-2" />
                          Schedule Session
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Info Section */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <h2 className="font-heading text-3xl text-primary uppercase tracking-tight">
                Live Literary Discussions
              </h2>
              <p className="font-paragraph text-lg text-secondary italic leading-relaxed">
                Create intimate live video discussions where 5-6 hostel residents can 
                engage in real-time conversations about books, literary themes, and 
                reading experiences. Foster deeper connections through face-to-face dialogue.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Users className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Small Group Format
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Intimate discussions with 5-6 participants ensure everyone has 
                    a voice and can contribute meaningfully to the conversation.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Video className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Live Interaction
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Real-time video discussions allow for spontaneous insights, 
                    immediate feedback, and dynamic literary conversations.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <Clock className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                    Flexible Scheduling
                  </h3>
                  <p className="font-paragraph text-secondary italic">
                    Schedule sessions at convenient times for hostel residents, 
                    accommodating different academic schedules and time zones.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 bg-mutedgray/10 rounded-lg border border-subtleborder">
              <h4 className="font-heading text-sm text-primary uppercase tracking-wide mb-3">
                Session Guidelines
              </h4>
              <ul className="space-y-2 font-paragraph text-sm text-secondary italic">
                <li>• Choose engaging topics that encourage discussion</li>
                <li>• Provide clear session descriptions and expectations</li>
                <li>• Schedule sessions at times convenient for participants</li>
                <li>• Limit group size to 5-6 people for optimal interaction</li>
                <li>• Include video conference link for easy access</li>
                <li>• Consider featuring specific books or literary themes</li>
              </ul>
            </div>

            <div className="p-6 bg-primary/5 rounded-lg border border-primary/20">
              <h4 className="font-heading text-sm text-primary uppercase tracking-wide mb-3">
                Supported Platforms
              </h4>
              <div className="grid grid-cols-2 gap-3 font-paragraph text-sm text-secondary italic">
                <div>• Zoom</div>
                <div>• Google Meet</div>
                <div>• Microsoft Teams</div>
                <div>• Discord</div>
                <div>• Skype</div>
                <div>• Any video platform</div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}