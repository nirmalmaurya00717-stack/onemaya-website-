import { useMember } from '@/integrations';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Image } from '@/components/ui/image';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { User, Mail, Calendar, Settings, BookOpen, Users, Upload, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function ProfilePage() {
  const { member } = useMember();

  const formatDate = (date: Date | undefined) => {
    if (!date) return 'Not available';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 lg:py-24">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-8"
        >
          {/* Profile Header */}
          <div className="text-center space-y-6">
            <div className="flex flex-col items-center gap-6">
              <div className="relative">
                {member?.profile?.photo?.url ? (
                  <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-blue-200">
                    <Image
                      src={member.profile.photo.url}
                      alt="Profile picture"
                      width={128}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="w-32 h-32 bg-blue-600 rounded-full flex items-center justify-center border-4 border-blue-200">
                    <User className="w-16 h-16 text-white" />
                  </div>
                )}
                <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                  <div className="w-3 h-3 bg-white rounded-full"></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h1 className="font-heading text-3xl sm:text-4xl text-blue-900 uppercase tracking-tight">
                  {member?.profile?.nickname || member?.contact?.firstName || 'Welcome'}
                </h1>
                <p className="font-paragraph text-lg text-blue-600 italic">
                  {member?.profile?.title || 'OneMaya Member'}
                </p>
                <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                  Active Learner
                </Badge>
              </div>
            </div>
          </div>

          {/* Profile Information */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Personal Information */}
            <Card className="lg:col-span-2 border-blue-200 bg-white">
              <CardHeader>
                <CardTitle className="font-heading text-xl text-blue-900 uppercase tracking-wide flex items-center gap-3">
                  <User className="w-6 h-6" />
                  Personal Information
                </CardTitle>
                <CardDescription className="font-paragraph text-blue-600 italic">
                  Your account details and preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="font-heading text-sm text-blue-900 uppercase tracking-wide">
                      Display Name
                    </label>
                    <p className="font-paragraph text-blue-700">
                      {member?.profile?.nickname || 'Not set'}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="font-heading text-sm text-blue-900 uppercase tracking-wide">
                      Email Address
                    </label>
                    <p className="font-paragraph text-blue-700 flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      {member?.loginEmail || 'Not available'}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="font-heading text-sm text-blue-900 uppercase tracking-wide">
                      Full Name
                    </label>
                    <p className="font-paragraph text-blue-700">
                      {member?.contact?.firstName && member?.contact?.lastName 
                        ? `${member.contact.firstName} ${member.contact.lastName}`
                        : 'Not set'
                      }
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="font-heading text-sm text-blue-900 uppercase tracking-wide">
                      Member Since
                    </label>
                    <p className="font-paragraph text-blue-700 flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {formatDate(member?._createdDate)}
                    </p>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-blue-200">
                  <div className="space-y-2">
                    <label className="font-heading text-sm text-blue-900 uppercase tracking-wide">
                      Account Status
                    </label>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant={member?.loginEmailVerified ? "default" : "secondary"}
                        className={member?.loginEmailVerified ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}
                      >
                        {member?.loginEmailVerified ? 'Verified' : 'Pending Verification'}
                      </Badge>
                      <Badge className="bg-blue-100 text-blue-800">
                        {member?.status || 'Active'}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="space-y-6">
              <Card className="border-blue-200 bg-white">
                <CardHeader>
                  <CardTitle className="font-heading text-lg text-blue-900 uppercase tracking-wide">
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button asChild variant="outline" className="w-full border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white">
                    <Link to="/create-group">
                      <Users className="w-4 h-4 mr-2" />
                      Create Study Group
                    </Link>
                  </Button>
                  <Button asChild variant="outline" className="w-full border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white">
                    <Link to="/upload-video">
                      <Upload className="w-4 h-4 mr-2" />
                      Share Content
                    </Link>
                  </Button>
                  <Button asChild variant="outline" className="w-full border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white">
                    <Link to="/library">
                      <BookOpen className="w-4 h-4 mr-2" />
                      Browse Library
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Activity Summary */}
              <Card className="border-blue-200 bg-white">
                <CardHeader>
                  <CardTitle className="font-heading text-lg text-blue-900 uppercase tracking-wide">
                    Your Activity
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-paragraph text-blue-700">Groups Joined</span>
                    <Badge className="bg-blue-100 text-blue-800">0</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-paragraph text-blue-700">Content Shared</span>
                    <Badge className="bg-blue-100 text-blue-800">0</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-paragraph text-blue-700">Discussions</span>
                    <Badge className="bg-blue-100 text-blue-800">0</Badge>
                  </div>
                  <div className="pt-3 border-t border-blue-200">
                    <div className="flex items-center gap-2">
                      <Award className="w-4 h-4 text-blue-600" />
                      <span className="font-paragraph text-sm text-blue-600 italic">
                        New Member
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Recent Activity */}
          <Card className="border-blue-200 bg-white">
            <CardHeader>
              <CardTitle className="font-heading text-xl text-blue-900 uppercase tracking-wide">
                Recent Activity
              </CardTitle>
              <CardDescription className="font-paragraph text-blue-600 italic">
                Your latest interactions on OneMaya
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12 space-y-4">
                <BookOpen className="w-12 h-12 text-blue-300 mx-auto" />
                <div className="space-y-2">
                  <h3 className="font-heading text-lg text-blue-900 uppercase">Start Your Journey</h3>
                  <p className="font-paragraph text-blue-600 italic max-w-md mx-auto">
                    Join study groups, share content, or explore our library to see your activity here
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button asChild className="bg-blue-600 text-white hover:bg-blue-700">
                    <Link to="/create-group">Join a Group</Link>
                  </Button>
                  <Button asChild variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white">
                    <Link to="/library">Explore Library</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Feedback Widget */}
      <FeedbackWidget featureName="Profile Page Content" variant="floating" />
    </div>
  );
}