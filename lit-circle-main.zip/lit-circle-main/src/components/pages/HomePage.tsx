import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BaseCrudService, useMember } from '@/integrations';
import { BookReadingGroups, PopularBooks } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Image } from '@/components/ui/image';
import { LoginWelcomeBanner } from '@/components/ui/login-welcome-banner';
import { LanguageSwitcher } from '@/components/ui/language-switcher';
import { SEOHelmet } from '@/components/SEOHelmet';
import HindiContentUpload from '@/components/HindiContentUpload';
import { BookOpen, Users, Upload, FileText, Search, Brain, Video, Star, Crown, ArrowRight, Play, Download, TrendingUp, GraduationCap, Plus, AlertTriangle, X, ImageIcon, CheckCircle, Award, Zap, Smartphone, Mail, Bot, User, ChevronDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';

export default function HomePage() {
  const { t, currentLanguage } = useTranslation();
  const { member, isAuthenticated, actions } = useMember(); // MIXED ROUTE: Check authentication for conditional content
  const [bookGroups, setBookGroups] = useState<BookReadingGroups[]>([]);
  const [popularBooks, setPopularBooks] = useState<PopularBooks[]>([]);
  const [hindiBooks, setHindiBooks] = useState<PopularBooks[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isNoticeExpanded, setIsNoticeExpanded] = useState(false);

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    return d.toLocaleDateString(currentLanguage === 'en' ? 'en-US' : currentLanguage, { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [groupsResponse, booksResponse] = await Promise.all([
          BaseCrudService.getAll<BookReadingGroups>('bookreadinggroups'),
          BaseCrudService.getAll<PopularBooks>('popularbooks')
        ]);
        
        const groups = groupsResponse?.items || [];
        const books = booksResponse?.items || [];
        
        setBookGroups(groups.slice(0, 6)); // Show only 6 groups
        const allBooks = books.slice(0, 8); // Show only 8 books
        setPopularBooks(allBooks);
        
        // Filter Hindi language books - books with Hindi in genre or title
        if (allBooks && allBooks.length > 0) {
          const filteredHindiBooks = allBooks.filter(book => {
            const genre = book.genre?.toLowerCase() || '';
            const title = book.title?.toLowerCase() || '';
            const author = book.author?.toLowerCase() || '';
            
            // Check if book is marked as Hindi language
            return genre.includes('hindi') || 
                   title.includes('hindi') ||
                   author.includes('hindi');
          });
          
          setHindiBooks(filteredHindiBooks);
        } else {
          setHindiBooks([]);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        // Set empty arrays on error to prevent display issues
        setBookGroups([]);
        setPopularBooks([]);
        setHindiBooks([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSearch = () => {
    if (searchQuery.trim()) {
      // Navigate to library with search query
      window.location.href = `/library?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="w-12 h-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="font-paragraph text-secondary italic">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <SEOHelmet 
        title="OneMaya - AI-Powered Learning Platform"
        description="Join OneMaya, an AI-powered learning platform for students and researchers. Create study groups, access digital libraries, upload academic content, and engage in discussions."
        keywords="learning platform, study groups, digital library, AI assistant, academic discussions, students, education, researchers"
      />
      {/* Hero Section */}
      <section className="w-full max-w-[120rem] mx-auto px-3 sm:px-4 md:px-6 lg:px-8 xl:px-12 py-6 sm:py-8 md:py-12 lg:py-16 xl:py-20">
        {/* Language Switcher */}
        <div className="flex justify-end mb-4 sm:mb-6 md:mb-8">
          <LanguageSwitcher />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 md:gap-10 lg:gap-12 xl:gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-3 sm:space-y-4 md:space-y-6 text-center lg:text-left order-2 lg:order-1"
          >
            <div className="flex items-center justify-center lg:justify-start gap-2 sm:gap-3 md:gap-4 mb-3 sm:mb-4 md:mb-6 lg:mb-8">
              <div className="w-12 h-12 sm:w-16 sm:h-16 md:w-20 md:h-20 lg:w-24 lg:h-24 xl:w-28 xl:h-28 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
                <Brain className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 lg:w-12 lg:h-12 xl:w-14 xl:h-14 text-white" />
              </div>
              <h1 className="font-heading text-base xs:text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl 2xl:text-5xl text-blue-900 uppercase tracking-tight break-words">
                OneMaya
              </h1>
            </div>
            
            <h2 className="font-paragraph text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl text-blue-700 italic leading-relaxed">
              OneMaya-Powered Learning Platform for Students & Researchers
            </h2>
            
            <p className="font-paragraph text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl text-blue-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
              Connect with fellow learners, access digital libraries, and engage in meaningful academic discussions. Your gateway to collaborative learning.
            </p>

            {/* Quick Navigation */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-2 sm:gap-3 md:gap-4 pt-4 sm:pt-6 md:pt-8 lg:pt-10">
              <Button asChild variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-2 sm:px-3 md:px-4 lg:px-5 py-1.5 sm:py-2 md:py-2.5 lg:py-3 text-xs sm:text-sm md:text-base">
                <Link to="/library">
                  <BookOpen className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  <span className="hidden xs:inline">Browse </span>Library
                </Link>
              </Button>
              <Button asChild variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-2 sm:px-3 md:px-4 lg:px-5 py-1.5 sm:py-2 md:py-2.5 lg:py-3 text-xs sm:text-sm md:text-base">
                <Link to="/discussions">
                  <Users className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  <span className="hidden xs:inline">Join </span>Discussions
                </Link>
              </Button>
              <Button asChild variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-2 sm:px-3 md:px-4 lg:px-5 py-1.5 sm:py-2 md:py-2.5 lg:py-3 text-xs sm:text-sm md:text-base">
                <Link to="/help">
                  <Brain className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  Get Help
                </Link>
              </Button>
            </div>
          </motion.div>

          {/* Hero Image */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative order-1 lg:order-2"
          >
            <div className="aspect-[4/3] w-full rounded-lg sm:rounded-xl md:rounded-2xl overflow-hidden shadow-lg sm:shadow-xl md:shadow-2xl relative">
              <Image
                src="https://static.wixstatic.com/media/179bf7_94d54855e1984d34991d3bf0200fb178~mv2.png?id=hero-students"
                alt="OneMaya - Students and researchers collaborating on academic projects, sharing knowledge and learning together"
                width={600}
                className="w-full h-full object-cover"
              />
              
              {/* Transparent Text Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent flex items-end">
                <div className="p-3 sm:p-4 md:p-6 lg:p-8 xl:p-10 w-full">
                  <div className="bg-black/40 backdrop-blur-sm rounded-lg sm:rounded-xl p-3 sm:p-4 md:p-6 lg:p-8 border border-white/30">
                    <h3 className="font-heading text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl text-white uppercase tracking-tight mb-2 sm:mb-3 md:mb-4 drop-shadow-lg">
                      OneMaya Professional Academic Content Platform
                    </h3>
                    <p className="font-paragraph text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl text-white/90 leading-relaxed drop-shadow-md">
                      Upload, share, and discover academic content with ease. Join thousands of students, researchers, and scholars in building the world's largest educational knowledge base.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Primary Upload CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="max-w-5xl mx-auto mt-6 sm:mt-8 md:mt-12 lg:mt-16 xl:mt-20"
        >
          <Card className="bg-gradient-to-r from-green-500 to-blue-500 text-white border-0 shadow-lg sm:shadow-xl md:shadow-2xl">
            <CardContent className="p-3 sm:p-4 md:p-6 lg:p-8 xl:p-10">
              <div className="text-center space-y-2 sm:space-y-3 md:space-y-4 lg:space-y-6">
                <div className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 lg:w-14 lg:h-14 xl:w-16 xl:h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto">
                  <Upload className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 lg:w-7 lg:h-7 xl:w-8 xl:h-8 text-white" />
                </div>
                <h3 className="font-heading text-base sm:text-lg md:text-xl lg:text-2xl xl:text-3xl uppercase tracking-wide">
                  Ready to Share Your Knowledge?
                </h3>
                <p className="font-paragraph text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl italic opacity-90 max-w-3xl mx-auto">
                  Upload your academic content in just a few clicks. Support the global learning community.
                </p>
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 md:gap-4 justify-center pt-2 sm:pt-3 md:pt-4">
                  <Button 
                    asChild 
                    size="lg"
                    className="bg-white text-green-600 hover:bg-gray-100 font-heading uppercase tracking-wide px-3 sm:px-4 md:px-6 lg:px-8 py-2 sm:py-3 md:py-4 lg:py-5 text-xs sm:text-sm md:text-base lg:text-lg"
                  >
                    <Link to="/submit-content">
                      <FileText className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 mr-1 sm:mr-2" />
                      Upload Documents
                    </Link>
                  </Button>
                  <Button 
                    asChild 
                    size="lg"
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-green-600 font-heading uppercase tracking-wide px-3 sm:px-4 md:px-6 lg:px-8 py-2 sm:py-3 md:py-4 lg:py-5 text-xs sm:text-sm md:text-base lg:text-lg"
                  >
                    <Link to="/upload-video">
                      <Video className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 mr-1 sm:mr-2" />
                      Upload Videos
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Blocked Platforms Notice - Collapsible */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="max-w-5xl mx-auto mt-6 sm:mt-8 md:mt-12 lg:mt-16 xl:mt-20"
        >
          {/* Collapsed View - Link Style */}
          {!isNoticeExpanded && (
            <button
              onClick={() => setIsNoticeExpanded(true)}
              className="flex items-center gap-2 text-red-600 hover:text-red-700 transition-colors duration-200 group"
            >
              <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
              <span className="font-paragraph text-sm sm:text-base underline group-hover:no-underline">
                ⚠️ Content Upload Guidelines - click to view
              </span>
              <ChevronDown className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0 group-hover:translate-y-0.5 transition-transform" />
            </button>
          )}

          {/* Expanded View - Full Details */}
          {isNoticeExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-red-50 border-2 border-red-300 rounded-lg sm:rounded-xl md:rounded-2xl p-4 sm:p-6 md:p-8 lg:p-10 shadow-md"
            >
              <div className="flex gap-3 sm:gap-4 md:gap-6">
                <AlertTriangle className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 lg:w-10 lg:h-10 text-red-600 flex-shrink-0 mt-1" />
                <div className="space-y-3 sm:space-y-4 md:space-y-5 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-heading text-base sm:text-lg md:text-xl lg:text-2xl text-red-700 uppercase tracking-wide">
                      ⚠️ Blocked Video Hosting Platforms
                    </h3>
                    <button
                      onClick={() => setIsNoticeExpanded(false)}
                      className="text-red-600 hover:text-red-700 transition-colors"
                      aria-label="Close notice"
                    >
                      <X className="w-5 h-5 sm:w-6 sm:h-6" />
                    </button>
                  </div>
                  
                  <div className="space-y-2 sm:space-y-3">
                    <p className="font-paragraph text-sm sm:text-base md:text-lg text-red-600 leading-relaxed">
                      <strong>The following platforms are NOT allowed for video uploads:</strong>
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 sm:gap-3">
                      {['YouTube', 'Facebook', 'Instagram', 'Twitter', 'Telegram', 'TikTok', 'Snapchat', 'WhatsApp'].map((platform) => (
                        <div key={platform} className="flex items-center gap-2 text-sm sm:text-base text-red-600 bg-white rounded px-2 sm:px-3 py-1.5 sm:py-2 border border-red-200">
                          <X className="w-4 h-4 flex-shrink-0" />
                          <span>{platform}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white rounded-lg p-3 sm:p-4 md:p-5 border border-red-200 space-y-2 sm:space-y-3">
                    <p className="font-paragraph text-sm sm:text-base text-red-700">
                      <strong>⚠️ Copyright Warning:</strong> Using videos from social media platforms may violate copyright laws and intellectual property rights. We take copyright protection seriously.
                    </p>
                  </div>

                  <div className="bg-green-50 rounded-lg p-3 sm:p-4 md:p-5 border border-green-300 space-y-2 sm:space-y-3">
                    <p className="font-paragraph text-sm sm:text-base md:text-lg text-green-700">
                      <strong>✅ Recommended Video Hosting Services:</strong>
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 sm:gap-3">
                      {['Vimeo', 'Google Drive', 'Dropbox', 'OneDrive', 'AWS S3', 'Cloudinary'].map((service) => (
                        <div key={service} className="flex items-center gap-2 text-sm sm:text-base text-green-700 bg-white rounded px-2 sm:px-3 py-1.5 sm:py-2 border border-green-200">
                          <CheckCircle className="w-4 h-4 flex-shrink-0" />
                          <span>{service}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <p className="font-paragraph text-xs sm:text-sm md:text-base text-red-600 italic">
                    Please use direct video hosting services to ensure compliance with copyright laws and platform policies. Thank you for maintaining the integrity of our academic community!
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>
      </section>
      {/* Platform Features */}
      <section className="w-full bg-gradient-to-br from-blue-50 to-white">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-8 sm:py-12 md:py-16 lg:py-20 xl:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-10 md:gap-12 lg:gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="order-2 lg:order-1"
            >
              <div className="aspect-[4/3] w-full rounded-xl sm:rounded-2xl md:rounded-3xl overflow-hidden shadow-lg sm:shadow-xl md:shadow-2xl">
                <Image
                  src="https://static.wixstatic.com/media/179bf7_3ac7c77e338b424fa83cbc92069b85d3~mv2.png?id=platform-features"
                  alt="OneMaya platform features - Digital library with books, research papers, and educational content for students and researchers"
                  width={600}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-4 sm:space-y-6 md:space-y-8 lg:space-y-10 text-center lg:text-left order-1 lg:order-2"
            >
              <div>
                <h2 className="font-heading text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl text-blue-900 uppercase tracking-tight mb-3 sm:mb-4 md:mb-6">
                  Why Choose OneMaya?
                </h2>
                <p className="font-paragraph text-base sm:text-lg md:text-xl text-blue-600 italic max-w-3xl mx-auto lg:mx-0">
                  Professional platform designed for academic excellence and easy content sharing
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 md:gap-8">
                <div className="text-center lg:text-left space-y-3 sm:space-y-4 md:space-y-5 opacity-[0.99]">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 lg:w-16 lg:h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto lg:mx-0">
                    <Upload className="w-5 h-5 sm:w-6 sm:h-6 md:w-7 md:h-7 lg:w-8 lg:h-8 text-blue-600" />
                  </div>
                  <h3 className="font-heading text-base sm:text-lg md:text-xl lg:text-2xl text-blue-900 uppercase tracking-wide">Easy Upload</h3>
                  <p className="font-paragraph text-sm sm:text-base md:text-lg text-blue-600">Simple drag-and-drop interface for quick content sharing</p>
                </div>

                <div className="text-center lg:text-left space-y-3 sm:space-y-4 md:space-y-5">
                  <div className="bg-gradient-to-br from-green-50 to-blue-50 border border-green-200 rounded-xl p-4 sm:p-6 md:p-8">
                    <div className="space-y-3 sm:space-y-4">
                      <div className="flex items-center gap-2 text-sm sm:text-base md:text-lg text-green-700">
                        <span>✅</span>
                        <span className="font-heading uppercase tracking-wide">Fair Rating System</span>
                      </div>
                      <p className="font-paragraph text-sm sm:text-base text-blue-600">Every creator's work is rated by real users based on how well it explains ideas with real-life examples and practical value.</p>
                      
                      <div className="flex items-center gap-2 text-sm sm:text-base md:text-lg text-blue-700">
                        <span>💬</span>
                        <span className="font-heading uppercase tracking-wide">Transparent Feedback</span>
                      </div>
                      <p className="font-paragraph text-sm sm:text-base text-blue-600">You get ratings out of 10 and direct feedback on your uploads — no hidden reviews.</p>
                      
                      <div className="flex items-center gap-2 text-sm sm:text-base md:text-lg text-orange-700">
                        <span>🏆</span>
                        <span className="font-heading uppercase tracking-wide">Grow to Paid Creator</span>
                      </div>
                      <p className="font-paragraph text-sm sm:text-base text-blue-600">Top-rated creators are selected for our Paid Creator Program — earn monthly by sharing your knowledge.</p>
                      
                      <div className="flex items-center gap-2 text-sm sm:text-base md:text-lg text-red-700">
                        <span>🔥</span>
                        <span className="font-heading uppercase tracking-wide">Value-Based Recognition</span>
                      </div>
                      <p className="font-paragraph text-sm sm:text-base text-blue-600">The more original and educational your content is, the higher your reach, rating, and rewards.</p>
                    </div>
                  </div>
                </div>

                <div className="text-center lg:text-left space-y-3 sm:space-y-4 md:space-y-5">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 lg:w-16 lg:h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto lg:mx-0">
                    <Users className="w-5 h-5 sm:w-6 sm:h-6 md:w-7 md:h-7 lg:w-8 lg:h-8 text-purple-600" />
                  </div>
                  <h3 className="font-heading text-base sm:text-lg md:text-xl lg:text-2xl text-blue-900 uppercase tracking-wide">Global Community</h3>
                  <p className="font-paragraph text-sm sm:text-base md:text-lg text-blue-600">Connect with students and researchers worldwide</p>
                </div>

                <div className="text-center lg:text-left space-y-3 sm:space-y-4 md:space-y-5">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 lg:w-16 lg:h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto lg:mx-0">
                    <Brain className="w-5 h-5 sm:w-6 sm:h-6 md:w-7 md:h-7 lg:w-8 lg:h-8 text-orange-600" />
                  </div>
                  <h3 className="font-heading text-base sm:text-lg md:text-xl lg:text-2xl text-blue-900 uppercase tracking-wide">AI-Powered</h3>
                  <p className="font-paragraph text-sm sm:text-base md:text-lg text-blue-600">Smart recommendations and content organization</p>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="pt-4 sm:pt-6 md:pt-8 lg:pt-10 border-t border-blue-200">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 md:gap-6 lg:gap-8 text-center lg:text-left">
                  <div className="space-y-2 sm:space-y-3">
                    <div className="font-heading text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl text-blue-600">{bookGroups.length}+</div>
                    <div className="font-paragraph text-sm sm:text-base text-blue-500">Study Groups</div>
                  </div>
                  <div className="space-y-2 sm:space-y-3">
                    <div className="font-heading text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl text-blue-600">{popularBooks.length}+</div>
                    <div className="font-paragraph text-sm sm:text-base text-blue-500">Books Available</div>
                  </div>
                  <div className="space-y-2 sm:space-y-3">
                    <div className="font-heading text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl text-blue-600">9</div>
                    <div className="font-paragraph text-sm sm:text-base text-blue-500">Languages</div>
                  </div>
                  <div className="space-y-2 sm:space-y-3">
                    <div className="font-heading text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl text-blue-600">AI</div>
                    <div className="font-paragraph text-sm sm:text-base text-blue-500">Powered</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      {/* Browse Content Section */}
      <section className="w-full bg-white">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6 sm:space-y-8 text-center lg:text-left order-2 lg:order-1"
            >
              <div>
                <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl text-blue-900 uppercase tracking-tight mb-3 sm:mb-4">
                  Explore Academic Content
                </h2>
                <p className="font-paragraph text-base sm:text-lg text-blue-600 italic max-w-2xl mx-auto lg:mx-0">
                  Discover thousands of research papers, books, and educational materials
                </p>
              </div>

              <div className="space-y-6 sm:space-y-8">
                {/* Popular Books Preview */}
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-6 mb-4 sm:mb-6">
                    <h3 className="font-heading text-xl sm:text-2xl text-blue-900 uppercase tracking-wide">Popular Books</h3>
                    <Button asChild variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white text-sm sm:text-base">
                      <Link to="/library">
                        View All <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 ml-2" />
                      </Link>
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    {popularBooks.slice(0, 4).map((book, index) => (
                      <motion.div
                        key={book._id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: index * 0.1 }}
                      >
                        <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-blue-200">
                          <CardContent className="p-3 sm:p-4">
                            <div className="flex gap-2 sm:gap-3">
                              {book.coverImage && (
                                <div className="w-12 h-16 sm:w-16 sm:h-20 rounded overflow-hidden bg-gray-100 flex-shrink-0">
                                  <Image
                                    src={book.coverImage}
                                    alt={`Cover of ${book.title}`}
                                    width={64}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              )}
                              <div className="flex-1 min-w-0">
                                <h4 className="font-heading text-xs sm:text-sm text-blue-900 uppercase tracking-wide line-clamp-2 mb-1">
                                  {book.title}
                                </h4>
                                <p className="font-paragraph text-xs text-blue-600 italic mb-2">
                                  by {book.author}
                                </p>
                                {book.averageRating && (
                                  <div className="flex items-center gap-1">
                                    <div className="flex">
                                      {[...Array(5)].map((_, i) => (
                                        <Star 
                                          key={i} 
                                          className={`w-2 h-2 sm:w-3 sm:h-3 ${i < Math.floor(book.averageRating!) ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                                        />
                                      ))}
                                    </div>
                                    <span className="text-xs text-gray-600">{book.averageRating.toFixed(1)}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Study Groups Preview */}
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-6 mb-4 sm:mb-6">
                    <h3 className="font-heading text-xl sm:text-2xl text-blue-900 uppercase tracking-wide">Study Groups</h3>
                    <Button asChild variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white text-sm sm:text-base">
                      <Link to="/discussions">
                        View All <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 ml-2" />
                      </Link>
                    </Button>
                  </div>
                  
                  <div className="space-y-3 sm:space-y-4">
                    {bookGroups.slice(0, 3).map((group, index) => (
                      <motion.div
                        key={group._id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: index * 0.1 }}
                      >
                        <Card className="hover:shadow-lg transition-shadow duration-300 border-blue-200">
                          <CardContent className="p-3 sm:p-4">
                            <div className="flex gap-2 sm:gap-3">
                              {group.bookCover && (
                                <div className="w-10 h-12 sm:w-12 sm:h-16 rounded overflow-hidden bg-gray-100 flex-shrink-0">
                                  <Image
                                    src={group.bookCover}
                                    alt={`Cover of ${group.currentBook}`}
                                    width={48}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              )}
                              <div className="flex-1 min-w-0">
                                <h4 className="font-heading text-sm sm:text-base text-blue-900 uppercase tracking-wide line-clamp-1 mb-1">
                                  {group.groupName}
                                </h4>
                                <p className="font-paragraph text-xs sm:text-sm text-blue-600 italic line-clamp-2 mb-2">
                                  {group.description}
                                </p>
                                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                                  <Badge variant={group.isPublic ? "default" : "secondary"} className="text-xs w-fit">
                                    {group.isPublic ? 'Open' : 'Private'}
                                  </Badge>
                                  <Button asChild size="sm" variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white text-xs sm:text-sm">
                                    <Link to={`/group/${group._id}`}>
                                      Join
                                    </Link>
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Hindi Language Library Section */}
                <div className="pt-6 sm:pt-8 border-t border-blue-200">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-6 mb-4 sm:mb-6">
                    <div>
                      <h3 className="font-heading text-xl sm:text-2xl text-orange-900 uppercase tracking-wide">Hindi Language Library</h3>
                      <p className="font-paragraph text-xs sm:text-sm text-orange-600 italic mt-1">हिंदी भाषा की किताबें और सामग्री</p>
                    </div>
                    <Button asChild variant="outline" className="border-orange-600 text-orange-600 hover:bg-orange-600 hover:text-white text-sm sm:text-base">
                      <Link to="/hindi-library">
                        View All <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 ml-2" />
                      </Link>
                    </Button>
                  </div>
                  
                  {hindiBooks.length > 0 ? (
                    <>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 mb-6">
                        {hindiBooks.slice(0, 4).map((book, index) => (
                          <motion.div
                            key={`hindi-${book._id}`}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: index * 0.1 }}
                          >
                            <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-orange-200">
                              <CardContent className="p-3 sm:p-4">
                                <div className="flex gap-2 sm:gap-3">
                                  {book.coverImage && (
                                    <div className="w-12 h-16 sm:w-16 sm:h-20 rounded overflow-hidden bg-gray-100 flex-shrink-0">
                                      <Image
                                        src={book.coverImage}
                                        alt={`Cover of ${book.title}`}
                                        width={64}
                                        className="w-full h-full object-cover"
                                      />
                                    </div>
                                  )}
                                  <div className="flex-1 min-w-0">
                                    <h4 className="font-heading text-xs sm:text-sm text-orange-900 uppercase tracking-wide line-clamp-2 mb-1">
                                      {book.title}
                                    </h4>
                                    <p className="font-paragraph text-xs text-orange-600 italic mb-2">
                                      by {book.author}
                                    </p>
                                    {book.averageRating && (
                                      <div className="flex items-center gap-1">
                                        <div className="flex">
                                          {[...Array(5)].map((_, i) => (
                                            <Star 
                                              key={i} 
                                              className={`w-2 h-2 sm:w-3 sm:h-3 ${i < Math.floor(book.averageRating!) ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                                            />
                                          ))}
                                        </div>
                                        <span className="text-xs text-gray-600">{book.averageRating.toFixed(1)}</span>
                                      </div>
                                    )}
                                    {book.genre && (
                                      <Badge variant="secondary" className="text-xs mt-2 bg-orange-100 text-orange-800">
                                        {book.genre}
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          </motion.div>
                        ))}
                      </div>
                      <HindiContentUpload />
                    </>
                  ) : (
                    <div className="text-center py-8 sm:py-12 space-y-4 sm:space-y-6">
                      <BookOpen className="w-10 h-10 sm:w-12 sm:h-12 lg:w-16 lg:h-16 text-orange-300 mx-auto" />
                      <div className="space-y-2">
                        <h4 className="font-heading text-lg sm:text-xl lg:text-2xl text-orange-900 uppercase">Hindi Content Coming Soon</h4>
                        <p className="font-paragraph text-sm sm:text-base text-orange-600 italic max-w-md mx-auto">
                          Be the first to contribute Hindi language content to our community
                        </p>
                      </div>
                      <HindiContentUpload />
                    </div>
                  )}
                </div>
              </div>
            </motion.div>

            {/* Content Browse Image */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative order-1 lg:order-2"
            >
              <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden shadow-xl">
                <Image
                  src="https://static.wixstatic.com/media/179bf7_a25c4ffacc464317b8fd754a4f5f9e46~mv2.png?id=content-browse"
                  alt="OneMaya content library - Students browsing academic books, research papers, and educational materials in digital format"
                  width={600}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      {/* Call to Action Section */}
      <section className="w-full bg-gradient-to-r from-blue-600 to-green-600 text-white">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6 sm:space-y-8 text-center lg:text-left order-2 lg:order-1"
            >
              <div>
                <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl uppercase tracking-tight mb-4 sm:mb-6">
                  Ready to Share Your Knowledge?
                </h2>
                <p className="font-paragraph text-lg sm:text-xl italic max-w-3xl mx-auto lg:mx-0 opacity-90 leading-relaxed">
                  Join thousands of educators, researchers, and students who are building the world's largest academic knowledge base. Your contribution matters.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center lg:justify-start pt-6 sm:pt-8">
                <Button 
                  asChild 
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-gray-100 px-8 sm:px-10 py-4 sm:py-6 text-base sm:text-lg font-heading uppercase tracking-wide"
                >
                  <Link to="/submit-content">
                    <Upload className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3" />
                    Start Uploading Now
                  </Link>
                </Button>
                <Button 
                  asChild 
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-blue-600 px-8 sm:px-10 py-4 sm:py-6 text-base sm:text-lg font-heading uppercase tracking-wide"
                >
                  <Link to="/library">
                    <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3" />
                    Explore Content
                  </Link>
                </Button>
              </div>
            </motion.div>

            {/* CTA Image */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative order-1 lg:order-2"
            >
              <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden shadow-2xl">
                <Image
                  src="https://static.wixstatic.com/media/179bf7_026617d7d6bb4e228ac5cedf0ea026f3~mv2.png?id=cta-collaboration"
                  alt="OneMaya community - Students and researchers collaborating, sharing knowledge, and contributing to global education"
                  width={600}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      {/* Support Section */}
      <section className="w-full bg-white border-t border-blue-100">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative order-2 lg:order-1"
            >
              <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden shadow-xl">
                <Image
                  src="https://static.wixstatic.com/media/179bf7_23861adffe7b4dedbb00f17317d56c27~mv2.png?id=support-team"
                  alt="OneMaya support team - Dedicated professionals helping students and researchers with platform guidance and technical assistance"
                  width={600}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-6 sm:space-y-8 text-center lg:text-left order-1 lg:order-2"
            >
              <div>
                <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl text-blue-900 uppercase tracking-tight">
                  Need Help Getting Started?
                </h2>
                <p className="font-paragraph text-base sm:text-lg text-blue-600 italic max-w-2xl mx-auto lg:mx-0">
                  Our support team is here to help you upload and share your content successfully
                </p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
                <div className="text-center lg:text-left space-y-3 sm:space-y-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto lg:mx-0">
                    <Mail className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-heading text-base sm:text-lg text-blue-900 uppercase tracking-wide mb-2">Email Support</h3>
                    <a 
                      href="mailto:onemaya96@gmail.com" 
                      className="font-paragraph text-sm sm:text-base text-blue-600 italic hover:text-blue-800 transition-colors break-all"
                    >
                      onemaya96@gmail.com
                    </a>
                  </div>
                </div>
                
                <div className="text-center lg:text-left space-y-3 sm:space-y-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto lg:mx-0">
                    <Brain className="w-6 h-6 sm:w-8 sm:h-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-heading text-base sm:text-lg text-blue-900 uppercase tracking-wide mb-2">AI Assistant</h3>
                    <Link 
                      to="/ask-ai" 
                      className="font-paragraph text-sm sm:text-base text-blue-600 italic hover:text-blue-800 transition-colors"
                    >
                      Get instant help
                    </Link>
                  </div>
                </div>
                
                <div className="text-center lg:text-left space-y-3 sm:space-y-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto lg:mx-0">
                    <FileText className="w-6 h-6 sm:w-8 sm:h-8 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-heading text-base sm:text-lg text-blue-900 uppercase tracking-wide mb-2">Help Center</h3>
                    <Link 
                      to="/help" 
                      className="font-paragraph text-sm sm:text-base text-blue-600 italic hover:text-blue-800 transition-colors"
                    >
                      Browse guides
                    </Link>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      {/* Study Groups Section */}
      <section className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 lg:py-24" role="region" aria-labelledby="study-groups-heading">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6 sm:space-y-8 text-center lg:text-left order-2 lg:order-1"
          >
            <div className="space-y-3 sm:space-y-4">
              <h2 id="study-groups-heading" className="font-heading text-2xl sm:text-3xl lg:text-4xl xl:text-5xl text-blue-900 uppercase tracking-tight">
                Active Study Groups
              </h2>
              <p className="font-paragraph text-sm sm:text-base lg:text-lg text-blue-600 italic max-w-2xl mx-auto lg:mx-0">
                Join collaborative learning communities across various subjects and research areas
              </p>
            </div>

            {bookGroups.length > 0 ? (
              <div className="space-y-4 sm:space-y-6">
                {bookGroups.slice(0, 3).map((group, index) => (
                  <motion.div
                    key={group._id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Card className="border-blue-200 hover:border-blue-400 transition-colors duration-300 bg-white hover:shadow-lg">
                      <CardContent className="p-4 sm:p-6">
                        <div className="flex gap-3 sm:gap-4 items-start">
                          {group.bookCover && (
                            <div className="w-12 h-16 sm:w-16 sm:h-20 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                              <Image
                                src={group.bookCover}
                                alt={`OneMaya Study Group - Cover of ${group.currentBook} by ${group.bookAuthor || 'Unknown Author'} - Join our reading group for collaborative learning`}
                                width={64}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          )}
                          <div className="flex-1 space-y-2 sm:space-y-3">
                            <div>
                              <h3 className="font-heading text-base sm:text-lg text-blue-900 uppercase tracking-wide">
                                {group.groupName}
                              </h3>
                              <p className="font-paragraph text-blue-600 italic text-xs sm:text-sm">
                                {group.description}
                              </p>
                            </div>
                            
                            {group.currentBook && (
                              <div className="space-y-1">
                                <h4 className="font-heading text-xs sm:text-sm text-blue-900 uppercase tracking-wide">
                                  Current Focus
                                </h4>
                                <p className="font-paragraph text-xs sm:text-sm text-blue-700">
                                  {group.currentBook}
                                </p>
                                {group.bookAuthor && (
                                  <p className="font-paragraph text-xs text-blue-500 italic">
                                    by {group.bookAuthor}
                                  </p>
                                )}
                              </div>
                            )}
                            
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pt-2">
                              <div className="flex items-center gap-2">
                                <Badge 
                                  variant={group.isPublic ? "default" : "secondary"}
                                  className={`font-paragraph text-xs ${group.isPublic ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}
                                >
                                  {group.isPublic ? 'Open' : 'Private'}
                                </Badge>
                                <span className="font-paragraph text-xs text-blue-500 italic">
                                  {formatDate(group.creationDate)}
                                </span>
                              </div>
                              
                              <Button 
                                asChild 
                                variant="outline" 
                                size="sm"
                                className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-heading uppercase tracking-wide text-xs sm:text-sm"
                              >
                                <Link to={`/group/${group._id}`}>Join Group</Link>
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center lg:text-left py-8 sm:py-12 space-y-4 sm:space-y-6">
                <GraduationCap className="w-10 h-10 sm:w-12 sm:h-12 lg:w-16 lg:h-16 text-blue-300 mx-auto lg:mx-0" />
                <div className="space-y-2">
                  <h3 className="font-heading text-lg sm:text-xl lg:text-2xl text-blue-900 uppercase">Start Your Learning Journey</h3>
                  <p className="font-paragraph text-sm sm:text-base text-blue-600 italic max-w-md mx-auto lg:mx-0">
                    Create or join study groups to collaborate with fellow learners
                  </p>
                </div>
                <Button 
                  asChild 
                  className="bg-blue-600 text-white hover:bg-blue-700 px-4 sm:px-6 lg:px-8 py-2 sm:py-3 font-heading uppercase tracking-wide text-sm sm:text-base"
                >
                  <Link to="/create-group">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Study Group
                  </Link>
                </Button>
              </div>
            )}
          </motion.div>

          {/* Study Groups Image */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative order-1 lg:order-2"
          >
            <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden shadow-xl">
              <Image
                src="https://static.wixstatic.com/media/179bf7_f5253d30b7d64841ac553dcdeda4b1c7~mv2.png?id=study-groups"
                alt="OneMaya study groups - Students collaborating in reading groups, discussing books and academic topics together"
                width={600}
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>
      </section>
      {/* Paid Creator Payment Process Section */}
      <section className="w-full bg-gradient-to-br from-green-50 to-blue-50 border-t border-blue-100">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 lg:py-24">
          <div className="text-center space-y-6 sm:space-y-8 mb-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-blue-900 uppercase tracking-tight">
                  Paid Creator Program
                </h2>
              </div>
              <p className="font-paragraph text-base sm:text-lg text-blue-600 italic max-w-3xl mx-auto">
                Understand how our transparent payment system works for creators and customers
              </p>
            </motion.div>
          </div>

          {/* Payment Process Flow */}
          <div className="max-w-6xl mx-auto mb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Card className="bg-white border-2 border-green-200 shadow-lg">
                <CardHeader className="text-center">
                  <CardTitle className="font-heading text-2xl text-blue-900 uppercase tracking-wide">
                    How Payment Works
                  </CardTitle>
                  <CardDescription className="font-paragraph text-blue-600 italic">
                    Simple, transparent, and secure payment process
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Step 1 */}
                    <div className="text-center space-y-4">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                        <span className="font-heading text-2xl text-blue-600">1</span>
                      </div>
                      <div>
                        <h3 className="font-heading text-lg text-blue-900 uppercase tracking-wide mb-2">
                          Creator Sets Price
                        </h3>
                        <p className="font-paragraph text-sm text-blue-700">
                          Paid Creators set their own content pricing between <strong>₹10–₹70 per month</strong> based on content quality and value.
                        </p>
                      </div>
                    </div>

                    {/* Step 2 */}
                    <div className="text-center space-y-4">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                        <span className="font-heading text-2xl text-green-600">2</span>
                      </div>
                      <div>
                        <h3 className="font-heading text-lg text-blue-900 uppercase tracking-wide mb-2">
                          Customer Pays
                        </h3>
                        <p className="font-paragraph text-sm text-blue-700">
                          Customers pay through our secure website wallet/payment gateway using UPI, cards, or net banking.
                        </p>
                      </div>
                    </div>

                    {/* Step 3 */}
                    <div className="text-center space-y-4">
                      <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto">
                        <span className="font-heading text-2xl text-purple-600">3</span>
                      </div>
                      <div>
                        <h3 className="font-heading text-lg text-blue-900 uppercase tracking-wide mb-2">
                          Payout Process
                        </h3>
                        <p className="font-paragraph text-sm text-blue-700">
                          Payment goes to OneMaya first. Creator requests payout, and we transfer earnings to their account.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Detailed Explanation Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 mb-12">
            {/* For Creators */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="h-full border-2 border-blue-200 bg-white hover:shadow-lg transition-all duration-300">
                <CardHeader className="text-center space-y-4">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                    <Crown className="w-8 h-8 text-blue-600" />
                  </div>
                  <CardTitle className="font-heading text-xl text-blue-900 uppercase tracking-wide">
                    For Paid Creators
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-paragraph text-sm text-blue-700 font-medium">Set Your Own Price</p>
                        <p className="font-paragraph text-xs text-blue-600">Choose between ₹10–₹70/month based on your content value</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-paragraph text-sm text-blue-700 font-medium">Secure Payment Handling</p>
                        <p className="font-paragraph text-xs text-blue-600">All payments processed through OneMaya's secure system</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-paragraph text-sm text-blue-700 font-medium">Easy Payout Requests</p>
                        <p className="font-paragraph text-xs text-blue-600">Request payouts anytime through your creator dashboard</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-paragraph text-sm text-blue-700 font-medium">Transparent Earnings</p>
                        <p className="font-paragraph text-xs text-blue-600">Track your earnings and payout history in real-time</p>
                      </div>
                    </div>
                  </div>
                  <Button 
                    asChild
                    className="w-full bg-blue-600 text-white hover:bg-blue-700 font-heading uppercase tracking-wide"
                  >
                    <Link to="/become-paid-creator">
                      <Crown className="w-4 h-4 mr-2" />
                      Become Paid Creator
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* For Customers */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Card className="h-full border-2 border-green-200 bg-white hover:shadow-lg transition-all duration-300">
                <CardHeader className="text-center space-y-4">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <Users className="w-8 h-8 text-green-600" />
                  </div>
                  <CardTitle className="font-heading text-xl text-blue-900 uppercase tracking-wide">
                    For Customers
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-paragraph text-sm text-blue-700 font-medium">Affordable Pricing</p>
                        <p className="font-paragraph text-xs text-blue-600">Access premium content for just ₹10–₹70/month</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-paragraph text-sm text-blue-700 font-medium">Secure Payment Options</p>
                        <p className="font-paragraph text-xs text-blue-600">Pay via UPI, cards, net banking, or digital wallets</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-paragraph text-sm text-blue-700 font-medium">Instant Access</p>
                        <p className="font-paragraph text-xs text-blue-600">Get immediate access to premium content after payment</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-paragraph text-sm text-blue-700 font-medium">Quality Assurance</p>
                        <p className="font-paragraph text-xs text-blue-600">All content moderated for quality and educational value</p>
                      </div>
                    </div>
                  </div>
                  <Button 
                    asChild
                    variant="outline"
                    className="w-full border-green-600 text-green-600 hover:bg-green-600 hover:text-white font-heading uppercase tracking-wide"
                  >
                    <Link to="/library">
                      <BookOpen className="w-4 h-4 mr-2" />
                      Browse Content
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Payment Security Notice */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Card className="max-w-4xl mx-auto bg-gradient-to-r from-blue-50 to-green-50 border-2 border-blue-200">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-heading text-lg text-blue-900 uppercase tracking-wide">
                      Secure & Transparent Payment System
                    </h3>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4 text-sm font-paragraph text-blue-700">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span>SSL encrypted payment gateway</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span>PCI DSS compliant processing</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span>Real-time transaction tracking</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span>24/7 payment support</span>
                    </div>
                  </div>
                  <p className="font-paragraph text-xs text-blue-600 italic max-w-2xl mx-auto">
                    All transactions are processed securely through OneMaya. We ensure fair compensation for creators while providing affordable access to quality educational content for learners.
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>
      {/* Subscription Plans Section */}
      <section className="w-full bg-gradient-to-br from-blue-50 to-white border-t border-blue-100">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 lg:py-24">
          <div className="text-center space-y-6 sm:space-y-8 mb-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-blue-900 uppercase tracking-tight">
                  Choose Your Reading Journey
                </h2>
              </div>
              <p className="font-paragraph text-base sm:text-lg text-blue-600 italic max-w-2xl mx-auto">
                Start with 60 days free, then continue with our affordable monthly plans designed for book lovers.
              </p>
            </motion.div>
          </div>

          <div className="grid gap-6 sm:gap-8 grid-cols-1 md:grid-cols-3 max-w-6xl mx-auto">
            {/* Free Trial Plan */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Card className="h-full border-blue-200 bg-white hover:border-blue-400 transition-colors duration-300 hover:shadow-lg">
                <CardHeader className="text-center space-y-4">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                    <Zap className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-xl text-blue-900 uppercase tracking-wide">
                      Free Trial
                    </CardTitle>
                    <CardDescription className="font-paragraph text-blue-600 italic">
                      Perfect for getting started
                    </CardDescription>
                  </div>
                  <div className="space-y-2">
                    <div className="text-4xl font-heading font-bold text-blue-900">Free</div>
                    <p className="font-paragraph text-sm text-blue-500 italic">60 days trial</p>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Access to public reading groups</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Basic discussion participation</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Limited video content</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Community support</span>
                    </li>
                  </ul>
                  <Button 
                    variant="outline"
                    className="w-full border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-heading uppercase tracking-wide"
                  >
                    Already Included
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Month 1 Plan */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 z-10">
                <Badge className="bg-blue-600 text-white font-heading uppercase tracking-wide">Most Popular</Badge>
              </div>
              <Card className="h-full border-2 border-blue-600 bg-white hover:shadow-xl transition-all duration-300">
                <CardHeader className="text-center space-y-4">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                    <Star className="w-8 h-8 text-yellow-600" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-xl text-blue-900 uppercase tracking-wide">
                      Month 1 Plan
                    </CardTitle>
                    <CardDescription className="font-paragraph text-blue-600 italic">
                      Enhanced reading experience
                    </CardDescription>
                  </div>
                  <div className="space-y-2">
                    <div className="text-4xl font-heading font-bold text-blue-900">₹49</div>
                    <p className="font-paragraph text-sm text-blue-500 italic">30 days access</p>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Access to all reading groups</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Unlimited discussion participation</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Full video content library</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Live session scheduling</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Ad-free experience</span>
                    </li>
                  </ul>
                  <Button 
                    asChild
                    className="w-full bg-blue-600 text-white hover:bg-blue-700 font-heading uppercase tracking-wide"
                  >
                    <Link to="/subscription-plans">
                      Choose Payment Method
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Month 2 Plan */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Card className="h-full border-blue-200 bg-white hover:border-blue-400 transition-colors duration-300 hover:shadow-lg">
                <CardHeader className="text-center space-y-4">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto">
                    <Crown className="w-8 h-8 text-purple-600" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-xl text-blue-900 uppercase tracking-wide">
                      Month 2 Plan
                    </CardTitle>
                    <CardDescription className="font-paragraph text-blue-600 italic">
                      Premium features included
                    </CardDescription>
                  </div>
                  <div className="space-y-2">
                    <div className="text-4xl font-heading font-bold text-blue-900">₹49</div>
                    <p className="font-paragraph text-sm text-blue-500 italic">30 days access</p>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">All Month 1 features</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Priority support</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Advanced AI features</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Exclusive content access</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="font-paragraph text-sm text-blue-700">Early feature previews</span>
                    </li>
                  </ul>
                  <Button 
                    asChild
                    variant="outline"
                    className="w-full border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-heading uppercase tracking-wide"
                  >
                    <Link to="/subscription-plans">
                      Choose Payment Method
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Payment Options Notice */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-12"
          >
            <Card className="max-w-md mx-auto bg-gradient-to-r from-green-50 to-blue-50 border border-green-200">
              <CardContent className="pt-6 text-center">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                    <Smartphone className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-heading text-sm text-blue-800 uppercase tracking-wide">Multiple Payment Options</span>
                </div>
                <p className="font-paragraph text-xs text-blue-700 italic">
                  Pay via UPI (instant) or Razorpay (cards, netbanking, wallets) - your choice!
                </p>
                <Button 
                  asChild
                  variant="outline"
                  size="sm"
                  className="mt-4 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-heading uppercase tracking-wide"
                >
                  <Link to="/subscription-plans">
                    View All Plans
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>
      {/* Call to Action Section */}
      <section className="w-full bg-blue-600 text-white">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 lg:py-24">
          <div className="text-center space-y-6 sm:space-y-8">
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl uppercase tracking-tight">
              Join the Knowledge Revolution
            </h2>
            <p className="font-paragraph text-base sm:text-lg italic max-w-2xl mx-auto opacity-90 px-4">
              Connect with learners worldwide, access AI-powered tools, and contribute to the global knowledge base
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
              <Button 
                asChild 
                variant="secondary"
                className="bg-white text-blue-600 hover:bg-blue-50 px-6 sm:px-8 py-4 sm:py-6 text-sm sm:text-base font-heading uppercase tracking-wide w-full sm:w-auto"
              >
                <Link to="/library">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Explore Library
                </Link>
              </Button>
              <Button 
                asChild 
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600 px-6 sm:px-8 py-4 sm:py-6 text-sm sm:text-base font-heading uppercase tracking-wide w-full sm:w-auto"
              >
                <Link to="/discussions">
                  <Users className="w-4 h-4 mr-2" />
                  Join Discussions
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
      {/* Contact & Support Section */}
      <section className="w-full bg-white border-t border-blue-100">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 lg:py-24">
          <div className="text-center space-y-6 sm:space-y-8">
            <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl xl:text-5xl text-blue-900 uppercase tracking-tight">
              Support & Community
            </h2>
            <p className="font-paragraph text-sm sm:text-base lg:text-lg text-blue-600 italic max-w-2xl mx-auto">
              Get help, connect with our team, and join our growing community of learners
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-4xl mx-auto">
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  <Mail className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <div>
                  <p className="font-heading text-xs sm:text-sm text-blue-900 uppercase tracking-wide">Email Support</p>
                  <a 
                    href="mailto:onemaya96@gmail.com" 
                    className="font-paragraph text-sm sm:text-base text-blue-600 italic hover:text-blue-800 transition-colors break-all"
                  >
                    onemaya96@gmail.com
                  </a>
                </div>
              </div>
              
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  <Bot className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <div>
                  <p className="font-heading text-xs sm:text-sm text-blue-900 uppercase tracking-wide">AI Assistant</p>
                  <Link 
                    to="/ask-ai" 
                    className="font-paragraph text-sm sm:text-base text-blue-600 italic hover:text-blue-800 transition-colors"
                  >
                    Get instant help
                  </Link>
                </div>
              </div>
              
              <div className="flex flex-col items-center gap-3 text-center sm:col-span-2 lg:col-span-1">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  <Users className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <div>
                  <p className="font-heading text-xs sm:text-sm text-blue-900 uppercase tracking-wide">Community</p>
                  <Link 
                    to="/discussions" 
                    className="font-paragraph text-sm sm:text-base text-blue-600 italic hover:text-blue-800 transition-colors"
                  >
                    Join discussions
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Login Welcome Banner - Shows once per login session */}
      <LoginWelcomeBanner />
    </div>
  );
}