import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, CreditCard, Clock, Shield, AlertTriangle, CheckCircle, Mail, Phone } from 'lucide-react';

export default function RefundCancellationPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[100rem] mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <RefreshCw className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-heading font-bold text-foreground">
              Refund & Cancellation Policy
            </h1>
          </div>
          <p className="text-lg font-paragraph text-secondary max-w-3xl mx-auto">
            We want you to be completely satisfied with our service. Here's our comprehensive refund and cancellation policy.
          </p>
          <p className="text-sm font-paragraph text-mutedgray mt-2">
            Last updated: November 3, 2025
          </p>
        </div>

        <div className="grid gap-8 max-w-4xl mx-auto">
          {/* Overview */}
          <Card className="border-2 border-primary bg-blue-50">
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2 text-primary">
                <Shield className="h-5 w-5" />
                Policy Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <CheckCircle className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-heading text-sm font-semibold mb-1">7-Day Guarantee</h3>
                  <p className="font-paragraph text-xs text-secondary">Full refund within 7 days of subscription activation</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Clock className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-heading text-sm font-semibold mb-1">Quick Processing</h3>
                  <p className="font-paragraph text-xs text-secondary">Refunds processed within 5-7 business days</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <RefreshCw className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-heading text-sm font-semibold mb-1">Easy Process</h3>
                  <p className="font-paragraph text-xs text-secondary">Simple online refund request system</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Subscription Plans Refund Policy */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" />
                Subscription Refund Policy
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-3 flex items-center gap-2">
                  Month 1 Plan (₹49)
                  <Badge className="bg-green-100 text-green-800">7-Day Refund</Badge>
                </h3>
                <ul className="font-paragraph text-sm text-secondary space-y-2 ml-4">
                  <li>• <strong>Full refund available:</strong> Within 7 days of subscription activation</li>
                  <li>• <strong>Partial refund:</strong> Pro-rated refund available up to 15 days</li>
                  <li>• <strong>No refund:</strong> After 15 days of subscription activation</li>
                  <li>• <strong>Condition:</strong> Must not have accessed more than 5 premium content items</li>
                </ul>
              </div>

              <div>
                <h3 className="font-heading text-lg font-semibold mb-3 flex items-center gap-2">
                  Month 2 Plan (₹49)
                  <Badge className="bg-blue-100 text-blue-800">7-Day Refund</Badge>
                </h3>
                <ul className="font-paragraph text-sm text-secondary space-y-2 ml-4">
                  <li>• <strong>Full refund available:</strong> Within 7 days of subscription activation</li>
                  <li>• <strong>Partial refund:</strong> Pro-rated refund available up to 15 days</li>
                  <li>• <strong>No refund:</strong> After 15 days of subscription activation</li>
                  <li>• <strong>Condition:</strong> Must not have accessed premium AI features extensively</li>
                </ul>
              </div>

              <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div>
                    <h4 className="font-heading text-sm font-semibold text-amber-800 mb-1">Important Note</h4>
                    <p className="font-paragraph text-xs text-amber-700">
                      The 60-day free trial period is completely free with no charges. Refund policies apply only to paid subscriptions (Month 1 and Month 2 plans).
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Cancellation Policy */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Subscription Cancellation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">How to Cancel</h3>
                <ol className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>1. Log into your account and go to Profile settings</li>
                  <li>2. Navigate to "Subscription Management"</li>
                  <li>3. Click "Cancel Subscription" button</li>
                  <li>4. Follow the cancellation confirmation steps</li>
                  <li>5. You'll receive an email confirmation</li>
                </ol>
              </div>

              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">What Happens After Cancellation</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• Your subscription remains active until the end of the current billing period</li>
                  <li>• You can continue using premium features until expiration</li>
                  <li>• No further charges will be made</li>
                  <li>• Your account data is preserved for 90 days in case you want to reactivate</li>
                  <li>• You can reactivate anytime by purchasing a new subscription</li>
                </ul>
              </div>

              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h4 className="font-heading text-sm font-semibold text-green-800 mb-2">No Automatic Renewals</h4>
                <p className="font-paragraph text-xs text-green-700">
                  Our subscriptions do not auto-renew. Each Month 1 and Month 2 plan is a one-time purchase for 30 days. You have full control over when and if you want to purchase additional subscription periods.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Refund Process */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <RefreshCw className="h-5 w-5 text-primary" />
                Refund Request Process
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-3">Step-by-Step Process</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                    <div>
                      <h4 className="font-heading text-sm font-semibold">Submit Request</h4>
                      <p className="font-paragraph text-xs text-secondary">Contact us via email with your refund request</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                    <div>
                      <h4 className="font-heading text-sm font-semibold">Provide Information</h4>
                      <p className="font-paragraph text-xs text-secondary">Share your account email, subscription details, and reason for refund</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                    <div>
                      <h4 className="font-heading text-sm font-semibold">Review Process</h4>
                      <p className="font-paragraph text-xs text-secondary">We'll review your request within 24 hours</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                    <div>
                      <h4 className="font-heading text-sm font-semibold">Refund Processing</h4>
                      <p className="font-paragraph text-xs text-secondary">Approved refunds are processed within 5-7 business days</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-heading text-lg font-semibold mb-2">Required Information for Refund</h3>
                <ul className="font-paragraph text-sm text-secondary space-y-1 ml-4">
                  <li>• Account email address</li>
                  <li>• Transaction ID or payment reference number</li>
                  <li>• Date of subscription purchase</li>
                  <li>• Reason for refund request</li>
                  <li>• UPI ID used for original payment (for UPI refunds)</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Refund Methods */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Refund Methods & Timeline</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-heading text-lg font-semibold mb-3">Refund Methods</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-heading text-sm font-semibold mb-2 flex items-center gap-2">
                      <CreditCard className="h-4 w-4 text-green-600" />
                      UPI Refund
                    </h4>
                    <p className="font-paragraph text-xs text-secondary mb-2">
                      Refunds are processed back to the same UPI ID used for payment
                    </p>
                    <p className="font-paragraph text-xs text-mutedgray">
                      <strong>Timeline:</strong> 3-5 business days
                    </p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h4 className="font-heading text-sm font-semibold mb-2 flex items-center gap-2">
                      <CreditCard className="h-4 w-4 text-blue-600" />
                      Bank Transfer
                    </h4>
                    <p className="font-paragraph text-xs text-secondary mb-2">
                      Direct bank transfer if UPI refund is not possible
                    </p>
                    <p className="font-paragraph text-xs text-mutedgray">
                      <strong>Timeline:</strong> 5-7 business days
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 className="font-heading text-sm font-semibold text-blue-800 mb-2">Processing Timeline</h4>
                <ul className="font-paragraph text-xs text-blue-700 space-y-1">
                  <li>• <strong>Request Review:</strong> Within 24 hours</li>
                  <li>• <strong>Approval Notification:</strong> Within 48 hours</li>
                  <li>• <strong>Refund Processing:</strong> 3-7 business days after approval</li>
                  <li>• <strong>Bank Processing:</strong> Additional 1-2 days depending on your bank</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Non-Refundable Situations */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-600" />
                Non-Refundable Situations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary mb-4">
                Refunds may not be available in the following situations:
              </p>
              <ul className="font-paragraph text-sm text-secondary space-y-2 ml-4">
                <li>• Subscription used for more than 15 days</li>
                <li>• Excessive usage of premium features (accessing 10+ premium content items, extensive AI usage)</li>
                <li>• Violation of our Terms and Conditions</li>
                <li>• Account suspension due to misuse</li>
                <li>• Technical issues on user's device or internet connection</li>
                <li>• Change of mind after extensive usage</li>
                <li>• Duplicate payments (we'll refund the duplicate, not both)</li>
              </ul>
            </CardContent>
          </Card>

          {/* Dispute Resolution */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Dispute Resolution</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary mb-4">
                If you're not satisfied with our refund decision, you can:
              </p>
              <ul className="font-paragraph text-sm text-secondary space-y-2 ml-4">
                <li>• Request a review of the decision by emailing our management team</li>
                <li>• Provide additional information or documentation</li>
                <li>• Escalate to our customer service manager via email</li>
                <li>• Contact us via email for detailed discussion</li>
              </ul>
              <p className="font-paragraph text-sm text-secondary mt-4">
                We're committed to fair and reasonable resolution of all refund requests.
              </p>
            </CardContent>
          </Card>

          {/* Contact for Refunds */}
          <Card className="border-2 border-primary bg-blue-50">
            <CardHeader>
              <CardTitle className="font-heading flex items-center gap-2 text-primary">
                <Mail className="h-5 w-5" />
                Request a Refund
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary mb-4">
                To request a refund or if you have questions about our refund policy:
              </p>
              <div className="grid gap-4 md:grid-cols-1">
                <div>
                  <h4 className="font-heading text-sm font-semibold mb-2 flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email Support
                  </h4>
                  <p className="font-paragraph text-sm">
                    <strong>onemaya96@gmail.com</strong>
                  </p>
                  <p className="font-paragraph text-xs text-mutedgray">
                    Include "Refund Request" in subject line. We respond within 24 hours.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Policy Updates */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Policy Updates</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-sm text-secondary">
                We may update this Refund & Cancellation Policy from time to time. Any changes will be posted on this page with an updated "Last updated" date. Continued use of our service after changes constitutes acceptance of the updated policy. We recommend reviewing this policy periodically.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}