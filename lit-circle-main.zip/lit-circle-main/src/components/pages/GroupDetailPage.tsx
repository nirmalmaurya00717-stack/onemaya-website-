import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { BookReadingGroups, DiscussionTopics } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Image } from '@/components/ui/image';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { ArrowLeft, BookOpen, Users, MessageCircle, Calendar, Eye, Pin } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';
import { useContentTranslator } from '@/lib/content-translator';

export default function GroupDetailPage() {
  const { groupId } = useParams<{ groupId: string }>();
  const { t, currentLanguage } = useTranslation();
  const { translateObject, translateArray } = useContentTranslator();
  const [group, setGroup] = useState<BookReadingGroups | null>(null);
  const [discussions, setDiscussions] = useState<DiscussionTopics[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchGroupData = async () => {
      if (!groupId) return;
      
      try {
        const groupData = await BaseCrudService.getById<BookReadingGroups>('bookreadinggroups', groupId);
        
        // Translate group data
        const translatedGroup = await translateObject(
          groupData, 
          ['groupName', 'description', 'currentBook', 'bookAuthor'], 
          currentLanguage
        );
        setGroup(translatedGroup);

        const { items: discussionItems } = await BaseCrudService.getAll<DiscussionTopics>('discussiontopics');
        
        // Translate discussion topics
        const translatedDiscussions = await translateArray(
          discussionItems, 
          ['topicTitle', 'topicContent'], 
          currentLanguage
        );
        setDiscussions(translatedDiscussions);
      } catch (error) {
        console.error('Error fetching group data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchGroupData();
  }, [groupId, currentLanguage, translateObject, translateArray]);

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatDateTime = (date: Date | string | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="w-12 h-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="font-paragraph text-secondary italic">Loading group details...</p>
        </div>
      </div>
    );
  }

  if (!group) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <BookOpen className="w-16 h-16 text-mutedgray mx-auto" />
          <h2 className="font-heading text-2xl text-primary uppercase">Group Not Found</h2>
          <p className="font-paragraph text-secondary italic">This reading group doesn't exist or has been removed.</p>
          <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Link to="/">Return to Groups</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-subtleborder bg-background">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button variant="ghost" asChild className="text-primary hover:bg-primary/10 self-start">
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Groups
              </Link>
            </Button>
            <div className="hidden sm:block w-px h-6 bg-subtleborder"></div>
            <div className="flex items-center gap-3 min-w-0">
              <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-primary flex-shrink-0" />
              <h1 className="font-heading text-lg sm:text-xl text-primary uppercase tracking-wide line-clamp-1 min-w-0">
                {group.groupName}
              </h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-[100rem] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16">
        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Group Info Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-1"
          >
            <Card className="border-subtleborder bg-background lg:sticky lg:top-8">
              <CardHeader className="space-y-3 sm:space-y-4 p-4 sm:p-6">
                {group.bookCover && (
                  <div className="aspect-[3/4] w-full max-w-32 sm:max-w-48 mx-auto rounded-lg overflow-hidden">
                    <Image
                      src={group.bookCover}
                      alt={`Cover of ${group.currentBook}`}
                      width={192}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <div className="text-center space-y-2 sm:space-y-3">
                  <CardTitle className="font-heading text-lg sm:text-xl text-primary uppercase tracking-wide">
                    {group.groupName}
                  </CardTitle>
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
                    <Badge variant={group.isPublic ? "default" : "secondary"}>
                      {group.isPublic ? "Public" : "Private"}
                    </Badge>
                    <span className="font-paragraph text-xs text-secondary italic">
                      Created {formatDate(group.creationDate)}
                    </span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4 sm:space-y-6 p-4 sm:p-6 pt-0">
                <div className="space-y-2 sm:space-y-3">
                  <h3 className="font-heading text-sm text-primary uppercase tracking-wide">
                    About This Group
                  </h3>
                  <p className="font-paragraph text-sm sm:text-base text-secondary italic leading-relaxed">
                    {group.description}
                  </p>
                </div>

                {group.currentBook && (
                  <div className="space-y-2 sm:space-y-3 pt-3 sm:pt-4 border-t border-subtleborder">
                    <h3 className="font-heading text-sm text-primary uppercase tracking-wide">
                      Current Reading
                    </h3>
                    <div className="space-y-1 sm:space-y-2">
                      <p className="font-paragraph text-sm sm:text-base text-primary">
                        {group.currentBook}
                      </p>
                      {group.bookAuthor && (
                        <p className="font-paragraph text-xs sm:text-sm text-secondary italic">
                          by {group.bookAuthor}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                <div className="pt-3 sm:pt-4 border-t border-subtleborder">
                  <Button 
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide text-sm"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    Join Group
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Discussions Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-2 space-y-6 sm:space-y-8"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="space-y-1 sm:space-y-2">
                <h2 className="font-heading text-2xl sm:text-3xl text-primary uppercase tracking-tight">
                  Group Discussions
                </h2>
                <p className="font-paragraph text-sm sm:text-base text-secondary italic">
                  Engage in meaningful conversations about literature and ideas
                </p>
              </div>
              <Button 
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide text-sm w-full sm:w-auto"
              >
                <Link to={`/group/${groupId}/new-topic`}>
                  <MessageCircle className="w-4 h-4 mr-2" />
                  New Topic
                </Link>
              </Button>
            </div>

            {discussions.length > 0 ? (
              <div className="space-y-4">
                {discussions.map((topic, index) => (
                  <motion.div
                    key={topic._id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <Card className="border-subtleborder hover:border-primary transition-colors duration-300 bg-background">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 space-y-3">
                            <div className="flex items-center gap-3">
                              {topic.isPinned && (
                                <Pin className="w-4 h-4 text-primary" />
                              )}
                              <h3 className="font-heading text-lg text-primary uppercase tracking-wide">
                                {topic.topicTitle}
                              </h3>
                            </div>
                            
                            <p className="font-paragraph text-secondary italic line-clamp-2">
                              {topic.topicContent}
                            </p>
                            
                            <div className="flex items-center gap-6 text-sm">
                              <div className="flex items-center gap-1 text-secondary">
                                <Calendar className="w-4 h-4" />
                                <span className="font-paragraph italic">
                                  {formatDateTime(topic.creationDate)}
                                </span>
                              </div>
                              
                              {topic.viewCount !== undefined && (
                                <div className="flex items-center gap-1 text-secondary">
                                  <Eye className="w-4 h-4" />
                                  <span className="font-paragraph italic">
                                    {topic.viewCount} views
                                  </span>
                                </div>
                              )}
                              
                              {topic.lastUpdatedDate && (
                                <div className="flex items-center gap-1 text-secondary">
                                  <MessageCircle className="w-4 h-4" />
                                  <span className="font-paragraph italic">
                                    Updated {formatDateTime(topic.lastUpdatedDate)}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <Button 
                            asChild 
                            variant="outline"
                            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-heading uppercase tracking-wide"
                          >
                            <Link to={`/topic/${topic._id}`}>
                              View
                            </Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              <Card className="border-subtleborder bg-background">
                <CardContent className="p-12 text-center space-y-6">
                  <MessageCircle className="w-16 h-16 text-mutedgray mx-auto" />
                  <div className="space-y-2">
                    <h3 className="font-heading text-2xl text-primary uppercase">
                      No Discussions Yet
                    </h3>
                    <p className="font-paragraph text-secondary italic max-w-md mx-auto">
                      Be the first to start a conversation in this reading group. 
                      Share your thoughts about the current book or suggest new topics.
                    </p>
                  </div>
                  <Button 
                    asChild
                    className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-3 font-heading uppercase tracking-wide"
                  >
                    <Link to={`/group/${groupId}/new-topic`}>
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Start First Discussion
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </motion.div>
        </div>
      </main>

      {/* Content Evaluation Widget */}
      <FeedbackWidget featureName="Reading Group Content" variant="floating" />
    </div>
  );
}