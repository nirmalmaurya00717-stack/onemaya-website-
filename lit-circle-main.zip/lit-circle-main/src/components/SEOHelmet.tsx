import { useLocation } from 'react-router-dom';
import { useEffect } from 'react';

interface SEOHelmetProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
}

export function SEOHelmet({ 
  title = "OneMaya - AI-Powered Learning & Discussion Platform",
  description = "Join OneMaya, the premier AI-powered learning platform for hostel boys, college students, researchers, and PhD scholars. Create study groups, access digital library, upload academic content, and engage in meaningful discussions.",
  keywords = "learning platform, study groups, digital library, AI assistant, academic discussions, research platform, students, education, hostel boys, college students, PhD scholars, researchers",
  image = "https://static.wixstatic.com/media/179bf7_94d54855e1984d34991d3bf0200fb178~mv2.png?id=og-image",
  url
}: SEOHelmetProps) {
  const location = useLocation();
  const currentUrl = url || `https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com${location.pathname}`;

  useEffect(() => {
    // Update document title
    document.title = title;

    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', description);
    }

    // Update meta keywords
    const metaKeywords = document.querySelector('meta[name="keywords"]');
    if (metaKeywords) {
      metaKeywords.setAttribute('content', keywords);
    }

    // Update Open Graph tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute('content', title);
    }

    const ogDescription = document.querySelector('meta[property="og:description"]');
    if (ogDescription) {
      ogDescription.setAttribute('content', description);
    }

    const ogImage = document.querySelector('meta[property="og:image"]');
    if (ogImage) {
      ogImage.setAttribute('content', image);
    }

    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl) {
      ogUrl.setAttribute('content', currentUrl);
    }

    // Update Twitter tags
    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (twitterTitle) {
      twitterTitle.setAttribute('content', title);
    }

    const twitterDescription = document.querySelector('meta[name="twitter:description"]');
    if (twitterDescription) {
      twitterDescription.setAttribute('content', description);
    }

    const twitterImage = document.querySelector('meta[name="twitter:image"]');
    if (twitterImage) {
      twitterImage.setAttribute('content', image);
    }

    const twitterUrl = document.querySelector('meta[name="twitter:url"]');
    if (twitterUrl) {
      twitterUrl.setAttribute('content', currentUrl);
    }

    // Update canonical URL
    const canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute('href', currentUrl);
    }
  }, [title, description, keywords, image, currentUrl]);

  return null; // This component doesn't render anything
}