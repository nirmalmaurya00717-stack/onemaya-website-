import { MemberProvider } from '@/integrations';
import { createBrowserRouter, RouterProvider, Navigate, Outlet } from 'react-router-dom';
import { ScrollToTop } from '@/lib/scroll-to-top';
import ErrorPage from '@/integrations/errorHandlers/ErrorPage';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { MemberProtectedRoute } from '@/components/ui/member-protected-route';
import HomePage from '@/components/pages/HomePage';
import HindiLibraryPage from '@/components/pages/HindiLibraryPage';
import CreateGroupPage from '@/components/pages/CreateGroupPage';
import GroupDetailPage from '@/components/pages/GroupDetailPage';
import DiscussionsPage from '@/components/pages/DiscussionsPage';
import NewTopicPage from '@/components/pages/NewTopicPage';
import TopicDetailPage from '@/components/pages/TopicDetailPage';
import LibraryPage from '@/components/pages/LibraryPage';
import SubmitContentPage from '@/components/pages/SubmitContentPage';
import UploadVideoPage from '@/components/pages/UploadVideoPage';
import ScheduleSessionPage from '@/components/pages/ScheduleSessionPage';
import AskAIPage from '@/components/pages/AskAIPage';
import HelpPage from '@/components/pages/HelpPage';
import SubscriptionPlansPage from '@/components/pages/SubscriptionPlansPage';
import ProfilePage from '@/components/pages/ProfilePage';
import FeedbackPage from '@/components/pages/FeedbackPage';
import PrivacyPolicyPage from '@/components/pages/PrivacyPolicyPage';
import TermsConditionsPage from '@/components/pages/TermsConditionsPage';
import ContactPage from '@/components/pages/ContactPage';
import RefundCancellationPage from '@/components/pages/RefundCancellationPage';
import BecomePaidCreatorPage from '@/components/pages/BecomePaidCreatorPage';
// ... keep existing code (other imports) ...

// Layout component that includes ScrollToTop and Header
function Layout() {
  return (
    <>
      <ScrollToTop />
      <Header />
      <main>
        <Outlet />
      </main>
      <Footer />
    </>
  );
}

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    errorElement: <ErrorPage />,
    children: [
      {
        index: true,
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to access the platform">
            <HomePage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "hindi-library",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to access the Hindi Library">
            <HindiLibraryPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "create-group",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to create reading groups">
            <CreateGroupPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "group/:groupId",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to access reading groups">
            <GroupDetailPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "group/:groupId/new-topic",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to create discussion topics">
            <NewTopicPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "discussions",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to access discussions">
            <DiscussionsPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "new-topic",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to create discussion topics">
            <NewTopicPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "topic/:topicId",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to view discussion topics">
            <TopicDetailPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "library",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to access the library">
            <LibraryPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "submit-content",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to submit content">
            <SubmitContentPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "upload-video",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to upload videos">
            <UploadVideoPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "schedule-session",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to schedule sessions">
            <ScheduleSessionPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "ask-ai",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to access AI features">
            <AskAIPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "help",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to access help and support">
            <HelpPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "subscription-plans",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to view subscription plans">
            <SubscriptionPlansPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "feedback",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to provide feedback">
            <FeedbackPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "privacy-policy",
        element: <PrivacyPolicyPage />,
      },
      {
        path: "terms-conditions",
        element: <TermsConditionsPage />,
      },
      {
        path: "contact",
        element: <ContactPage />,
      },
      {
        path: "refund-cancellation",
        element: <RefundCancellationPage />,
      },
      {
        path: "become-paid-creator",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to become a Paid Creator">
            <BecomePaidCreatorPage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "profile",
        element: (
          <MemberProtectedRoute messageToSignIn="Sign in to access your profile">
            <ProfilePage />
          </MemberProtectedRoute>
        ),
      },
      {
        path: "*",
        element: <Navigate to="/" replace />,
      },
    ],
  },
], {
  basename: import.meta.env.BASE_NAME,
});

export default function AppRouter() {
  return (
    <MemberProvider>
      <RouterProvider router={router} />
    </MemberProvider>
  );
}
