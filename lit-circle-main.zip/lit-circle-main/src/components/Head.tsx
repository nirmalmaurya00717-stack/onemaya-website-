export const Head = () => {
  return (
    <>
      {/* Basic Meta Tags */}
      <meta charSet="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
      
      {/* Primary SEO Tags */}
      <title>OneMaya - AI-Powered Learning & Discussion Platform for Students & Researchers</title>
      <meta name="description" content="Join OneMaya, the premier AI-powered learning platform for hostel boys, college students, researchers, and PhD scholars. Create study groups, access digital library, upload academic content, and engage in meaningful discussions. Free 60-day trial available." />
      <meta name="keywords" content="learning platform, study groups, digital library, AI assistant, academic discussions, research platform, students, education, hostel boys, college students, PhD scholars, researchers, book discussions, academic content, video lectures, research papers, online learning, collaborative learning, educational technology" />
      <meta name="author" content="OneMaya" />
      <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
      <meta name="language" content="English" />
      <meta name="revisit-after" content="7 days" />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content="website" />
      <meta property="og:url" content="https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/" />
      <meta property="og:title" content="OneMaya - AI-Powered Learning & Discussion Platform for Students & Researchers" />
      <meta property="og:description" content="Join OneMaya, the premier AI-powered learning platform for hostel boys, college students, researchers, and PhD scholars. Create study groups, access digital library, upload academic content, and engage in meaningful discussions." />
      <meta property="og:image" content="https://static.wixstatic.com/media/179bf7_94d54855e1984d34991d3bf0200fb178~mv2.png?id=og-image" />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:site_name" content="OneMaya" />
      <meta property="og:locale" content="en_US" />
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:url" content="https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/" />
      <meta name="twitter:title" content="OneMaya - AI-Powered Learning & Discussion Platform" />
      <meta name="twitter:description" content="Join OneMaya for collaborative learning, study groups, and academic discussions. Perfect for students, researchers, and knowledge seekers." />
      <meta name="twitter:image" content="https://static.wixstatic.com/media/179bf7_94d54855e1984d34991d3bf0200fb178~mv2.png?id=twitter-image" />
      <meta name="twitter:creator" content="@OneMaya" />
      <meta name="twitter:site" content="@OneMaya" />
      
      {/* Additional SEO Meta Tags */}
      <meta name="theme-color" content="#1E40AF" />
      <meta name="msapplication-TileColor" content="#1E40AF" />
      <meta name="application-name" content="OneMaya" />
      <meta name="apple-mobile-web-app-title" content="OneMaya" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      <meta name="mobile-web-app-capable" content="yes" />
      
      {/* Search Engine Verification Tags */}
      <meta name="google-site-verification" content="OneMaya-Learning-Platform-Verification" />
      <meta name="msvalidate.01" content="OneMaya-Bing-Verification" />
      <meta name="yandex-verification" content="OneMaya-Yandex-Verification" />
      
      {/* Additional Search Engine Directives */}
      <meta name="googlebot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
      <meta name="bingbot" content="index, follow" />
      <meta name="slurp" content="index, follow" />
      <meta name="duckduckbot" content="index, follow" />
      <meta name="baiduspider" content="index, follow" />
      <meta name="yandexbot" content="index, follow" />
      
      {/* Canonical URL */}
      <link rel="canonical" href="https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/" />
      
      {/* Alternate Languages */}
      <link rel="alternate" hrefLang="en" href="https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/" />
      <link rel="alternate" hrefLang="x-default" href="https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/" />
      
      {/* Preconnect for Performance */}
      <link rel="preconnect" href="https://static.parastorage.com" />
      <link rel="preconnect" href="https://static.wixstatic.com" />
      <link rel="dns-prefetch" href="https://fonts.googleapis.com" />
      <link rel="dns-prefetch" href="https://www.google.com" />
      <link rel="dns-prefetch" href="https://www.bing.com" />
      <link rel="dns-prefetch" href="https://search.yahoo.com" />
      <link rel="dns-prefetch" href="https://yandex.com" />
      
      {/* Favicon and Icons */}
      <link rel="icon" type="image/x-icon" href="/favicon.ico" />
      <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
      <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
      <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
      <link rel="manifest" href="/site.webmanifest" />
      
      {/* Structured Data - Organization */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "OneMaya",
          "url": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/",
          "logo": "https://static.wixstatic.com/media/179bf7_94d54855e1984d34991d3bf0200fb178~mv2.png?id=logo",
          "description": "AI-powered learning platform for students, researchers, and knowledge seekers",
          "email": "onemaya96@gmail.com",
          "sameAs": [
            "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/"
          ],
          "contactPoint": {
            "@type": "ContactPoint",
            "email": "onemaya96@gmail.com",
            "contactType": "customer service"
          }
        })}
      </script>
      
      {/* Structured Data - Website */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          "name": "OneMaya",
          "url": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/",
          "description": "AI-powered learning platform for students, researchers, and knowledge seekers",
          "potentialAction": {
            "@type": "SearchAction",
            "target": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/search?q={search_term_string}",
            "query-input": "required name=search_term_string"
          }
        })}
      </script>
      
      {/* Structured Data - Educational Organization */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "EducationalOrganization",
          "name": "OneMaya",
          "url": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/",
          "description": "AI-powered learning platform for students, researchers, and knowledge seekers",
          "email": "onemaya96@gmail.com",
          "offers": {
            "@type": "Offer",
            "name": "Learning Platform Access",
            "description": "Access to study groups, digital library, and AI-powered learning tools",
            "price": "49",
            "priceCurrency": "INR",
            "availability": "https://schema.org/InStock"
          }
        })}
      </script>
      
      {/* Structured Data - Course */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Course",
          "name": "OneMaya Learning Platform",
          "description": "Comprehensive AI-powered learning platform for academic discussions, study groups, and research collaboration",
          "provider": {
            "@type": "Organization",
            "name": "OneMaya",
            "url": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/"
          },
          "educationalLevel": "Higher Education",
          "teaches": [
            "Collaborative Learning",
            "Academic Research",
            "Study Group Management",
            "Digital Library Access",
            "AI-Assisted Learning"
          ]
        })}
      </script>
      
      {/* Structured Data - BreadcrumbList */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            {
              "@type": "ListItem",
              "position": 1,
              "name": "Home",
              "item": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/"
            },
            {
              "@type": "ListItem",
              "position": 2,
              "name": "Digital Library",
              "item": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/library"
            },
            {
              "@type": "ListItem",
              "position": 3,
              "name": "Study Groups",
              "item": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/create-group"
            },
            {
              "@type": "ListItem",
              "position": 4,
              "name": "Discussions",
              "item": "https://my-site-za4ocqmd-nirmalmaurya00717.wix-vibe.com/discussions"
            }
          ]
        })}
      </script>
    </>
  );
};
