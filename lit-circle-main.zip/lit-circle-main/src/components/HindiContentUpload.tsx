import { useState } from 'react';
import { BaseCrudService } from '@/integrations';
import { PopularBooks } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, BookOpen, FileText, Video, AlertCircle, Crown, Star, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useMember } from '@/integrations';

interface HindiContentUploadProps {
  onContentUploaded?: () => void;
}

export default function HindiContentUpload({ onContentUploaded }: HindiContentUploadProps) {
  const { member } = useMember();
  const [activeTab, setActiveTab] = useState('book');
  const [isExpanded, setIsExpanded] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Book form state
  const [bookForm, setBookForm] = useState({
    bookName: '',
    authorName: '',
    pdf: null as File | null,
    video: null as File | null,
    images: [] as File[],
  });

  // Book PDF form state
  const [pdfForm, setPdfForm] = useState({
    bookName: '',
    authorName: '',
    pdf: null as File | null,
  });

  // Summary form state
  const [summaryForm, setSummaryForm] = useState({
    bookName: '',
    authorName: '',
    summary: '',
    images: [] as File[],
    notesPdf: null as File | null,
    video: null as File | null,
  });

  // Video form state
  const [videoForm, setVideoForm] = useState({
    bookName: '',
    authorName: '',
    video: null as File | null,
  });

  const handleBookSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookForm.bookName || !bookForm.authorName) {
      alert('Please fill in book name and author name');
      return;
    }
    
    setIsSubmitting(true);
    try {
      const newBook: PopularBooks = {
        _id: crypto.randomUUID(),
        title: `${bookForm.bookName} (Hindi)`,
        author: bookForm.authorName,
        genre: 'Hindi',
        coverImage: 'https://static.wixstatic.com/media/179bf7_3ac7c77e338b424fa83cbc92069b85d3~mv2.png?id=hindi-book-cover-' + crypto.randomUUID(),
        averageRating: 0,
        publicationYear: new Date().getFullYear(),
        synopsis: `Hindi language book: ${bookForm.bookName}`,
        downloadLink: bookForm.pdf ? 'https://static.wixstatic.com/media/179bf7_pdf_' + crypto.randomUUID() + '.pdf' : ''
      };
      
      await BaseCrudService.create('popularbooks', newBook);
      setBookForm({ bookName: '', authorName: '', pdf: null, video: null, images: [] });
      alert('Book published successfully! It will appear in the Hindi Library for all users.');
      onContentUploaded?.();
    } catch (error) {
      console.error('Error uploading book:', error);
      alert('Failed to upload book. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePdfSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pdfForm.bookName || !pdfForm.authorName) {
      alert('Please fill in book name and author name');
      return;
    }

    if (!pdfForm.pdf) {
      alert('Please select a PDF file to upload');
      return;
    }
    
    setIsSubmitting(true);
    try {
      // Convert PDF file to data URL for viewing
      const reader = new FileReader();
      
      const pdfDataUrl = await new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result);
        };
        reader.onerror = reject;
        reader.readAsDataURL(pdfForm.pdf!);
      });
      
      const newBook: PopularBooks = {
        _id: crypto.randomUUID(),
        title: `${pdfForm.bookName} - PDF (Hindi)`,
        author: pdfForm.authorName,
        genre: 'Hindi',
        coverImage: 'https://static.wixstatic.com/media/179bf7_3ac7c77e338b424fa83cbc92069b85d3~mv2.png?id=hindi-pdf-cover-' + crypto.randomUUID(),
        averageRating: 0,
        publicationYear: new Date().getFullYear(),
        synopsis: `Hindi PDF: ${pdfForm.bookName}`,
        downloadLink: pdfDataUrl
      };
      
      await BaseCrudService.create('popularbooks', newBook);
      setPdfForm({ bookName: '', authorName: '', pdf: null });
      alert('PDF published successfully! It will appear in the Hindi Library for all users.');
      onContentUploaded?.();
    } catch (error) {
      console.error('Error uploading PDF:', error);
      alert('Failed to upload PDF. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSummarySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!summaryForm.bookName || !summaryForm.authorName || !summaryForm.summary) {
      alert('Please fill in book name, author name, and summary');
      return;
    }
    
    setIsSubmitting(true);
    try {
      const newBook: PopularBooks = {
        _id: crypto.randomUUID(),
        title: `${summaryForm.bookName} - Summary (Hindi)`,
        author: summaryForm.authorName,
        genre: 'Hindi',
        coverImage: 'https://static.wixstatic.com/media/179bf7_3ac7c77e338b424fa83cbc92069b85d3~mv2.png?id=hindi-summary-cover-' + crypto.randomUUID(),
        averageRating: 0,
        publicationYear: new Date().getFullYear(),
        synopsis: summaryForm.summary.substring(0, 500),
        downloadLink: summaryForm.notesPdf ? 'https://static.wixstatic.com/media/179bf7_pdf_' + crypto.randomUUID() + '.pdf' : ''
      };
      
      await BaseCrudService.create('popularbooks', newBook);
      setSummaryForm({ bookName: '', authorName: '', summary: '', images: [], notesPdf: null, video: null });
      alert('Summary published successfully! It will appear in the Hindi Library for all users.');
      onContentUploaded?.();
    } catch (error) {
      console.error('Error uploading summary:', error);
      alert('Failed to upload summary. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVideoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoForm.bookName || !videoForm.authorName) {
      alert('Please fill in book name and author name');
      return;
    }
    
    setIsSubmitting(true);
    try {
      const newBook: PopularBooks = {
        _id: crypto.randomUUID(),
        title: `${videoForm.bookName} - Video (Hindi)`,
        author: videoForm.authorName,
        genre: 'Hindi',
        coverImage: 'https://static.wixstatic.com/media/179bf7_3ac7c77e338b424fa83cbc92069b85d3~mv2.png?id=hindi-video-cover-' + crypto.randomUUID(),
        averageRating: 0,
        publicationYear: new Date().getFullYear(),
        synopsis: `Hindi video discussion: ${videoForm.bookName}`,
        downloadLink: videoForm.video ? 'https://static.wixstatic.com/media/179bf7_video_' + crypto.randomUUID() + '.mp4' : ''
      };
      
      await BaseCrudService.create('popularbooks', newBook);
      setVideoForm({ bookName: '', authorName: '', video: null });
      alert('Video published successfully! It will appear in the Hindi Library for all users.');
      onContentUploaded?.();
    } catch (error) {
      console.error('Error uploading video:', error);
      alert('Failed to upload video. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isExpanded) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mt-6 sm:mt-8"
      >
        <Button
          onClick={() => setIsExpanded(true)}
          className="w-full bg-orange-600 text-white hover:bg-orange-700 font-heading uppercase tracking-wide py-3 sm:py-4 text-sm sm:text-base"
        >
          <Upload className="w-4 h-4 mr-2" />
          Upload Hindi Content
        </Button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="mt-6 sm:mt-8 space-y-6"
    >
      {/* Paid Creator Plan Card */}
      <Card className="border-2 border-orange-500 bg-gradient-to-r from-orange-50 to-amber-50">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="font-heading text-lg sm:text-xl text-orange-900 uppercase tracking-wide">
                  Become a Paid Creator
                </CardTitle>
                <CardDescription className="font-paragraph text-orange-700 italic">
                  Earn money by sharing your content with the community
                </CardDescription>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="flex items-start gap-2 p-3 bg-white rounded-lg border border-orange-200">
              <Star className="w-4 h-4 text-yellow-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-heading text-xs text-orange-900 uppercase tracking-wide">Get Rated</p>
                <p className="font-paragraph text-xs text-orange-700">Reach 4⭐ rating</p>
              </div>
            </div>
            <div className="flex items-start gap-2 p-3 bg-white rounded-lg border border-orange-200">
              <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-heading text-xs text-orange-900 uppercase tracking-wide">Get Feedback</p>
                <p className="font-paragraph text-xs text-orange-700">Collect 50+ reviews</p>
              </div>
            </div>
            <div className="flex items-start gap-2 p-3 bg-white rounded-lg border border-orange-200">
              <Crown className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-heading text-xs text-orange-900 uppercase tracking-wide">Unlock Premium</p>
                <p className="font-paragraph text-xs text-orange-700">Just ₹49/month</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg border border-orange-200 space-y-3">
            <p className="font-paragraph text-sm text-orange-900">
              <strong>Premium Creator Benefits:</strong>
            </p>
            <ul className="space-y-2 text-xs font-paragraph text-orange-800">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-3 h-3 text-green-600 flex-shrink-0 mt-0.5" />
                <span>Monetize your content and earn from community</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-3 h-3 text-green-600 flex-shrink-0 mt-0.5" />
                <span>AI-powered content protection</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-3 h-3 text-green-600 flex-shrink-0 mt-0.5" />
                <span>Priority support and analytics</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-3 h-3 text-green-600 flex-shrink-0 mt-0.5" />
                <span>Exclusive creator badges and recognition</span>
              </li>
            </ul>
          </div>

          <Link to="/subscription-plans" className="block">
            <Button className="w-full bg-orange-600 text-white hover:bg-orange-700 font-heading uppercase tracking-wide">
              <Crown className="w-4 h-4 mr-2" />
              View Paid Creator Plan
            </Button>
          </Link>
        </CardContent>
      </Card>

      <Card className="border-orange-200 bg-orange-50">
        <CardHeader className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="font-heading text-lg sm:text-xl text-orange-900 uppercase tracking-wide">
                Upload Hindi Content
              </CardTitle>
              <CardDescription className="font-paragraph text-orange-600 italic">
                Share your knowledge with the Hindi learning community
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(false)}
              className="text-orange-600 hover:bg-orange-100"
            >
              ✕
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 gap-2 bg-orange-100">
              <TabsTrigger value="book" className="text-xs sm:text-sm">
                <BookOpen className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                <span className="hidden sm:inline">Book</span>
              </TabsTrigger>
              <TabsTrigger value="pdf" className="text-xs sm:text-sm">
                <FileText className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                <span className="hidden sm:inline">PDF</span>
              </TabsTrigger>
              <TabsTrigger value="summary" className="text-xs sm:text-sm">
                <FileText className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                <span className="hidden sm:inline">Summary</span>
              </TabsTrigger>
              <TabsTrigger value="video" className="text-xs sm:text-sm">
                <Video className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                <span className="hidden sm:inline">Video</span>
              </TabsTrigger>
            </TabsList>

            {/* Book Upload Tab */}
            <TabsContent value="book" className="space-y-4 mt-6">
              <form onSubmit={handleBookSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="book-name" className="font-heading text-sm text-orange-900 uppercase">
                      Book Name *
                    </Label>
                    <Input
                      id="book-name"
                      placeholder="Enter book name"
                      value={bookForm.bookName}
                      onChange={(e) => setBookForm({ ...bookForm, bookName: e.target.value })}
                      className="border-orange-300 focus:border-orange-600"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="book-author" className="font-heading text-sm text-orange-900 uppercase">
                      Author Name *
                    </Label>
                    <Input
                      id="book-author"
                      placeholder="Enter author name"
                      value={bookForm.authorName}
                      onChange={(e) => setBookForm({ ...bookForm, authorName: e.target.value })}
                      className="border-orange-300 focus:border-orange-600"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="book-pdf" className="font-heading text-sm text-orange-900 uppercase">
                    PDF (Optional)
                  </Label>
                  <Input
                    id="book-pdf"
                    type="file"
                    accept=".pdf"
                    onChange={(e) => setBookForm({ ...bookForm, pdf: e.target.files?.[0] || null })}
                    className="border-orange-300 focus:border-orange-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="book-video" className="font-heading text-sm text-orange-900 uppercase">
                    Video (Optional)
                  </Label>
                  <Input
                    id="book-video"
                    type="file"
                    accept="video/*"
                    onChange={(e) => setBookForm({ ...bookForm, video: e.target.files?.[0] || null })}
                    className="border-orange-300 focus:border-orange-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="book-images" className="font-heading text-sm text-orange-900 uppercase">
                    Images (Optional)
                  </Label>
                  <Input
                    id="book-images"
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={(e) => setBookForm({ ...bookForm, images: Array.from(e.target.files || []) })}
                    className="border-orange-300 focus:border-orange-600"
                  />
                </div>

                <Button type="submit" className="w-full bg-orange-600 text-white hover:bg-orange-700 font-heading uppercase tracking-wide">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Book
                </Button>
              </form>
            </TabsContent>

            {/* Book PDF Upload Tab */}
            <TabsContent value="pdf" className="space-y-4 mt-6">
              <form onSubmit={handlePdfSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="pdf-book-name" className="font-heading text-sm text-orange-900 uppercase">
                      Book Name *
                    </Label>
                    <Input
                      id="pdf-book-name"
                      placeholder="Enter book name"
                      value={pdfForm.bookName}
                      onChange={(e) => setPdfForm({ ...pdfForm, bookName: e.target.value })}
                      className="border-orange-300 focus:border-orange-600"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pdf-author" className="font-heading text-sm text-orange-900 uppercase">
                      Author Name *
                    </Label>
                    <Input
                      id="pdf-author"
                      placeholder="Enter author name"
                      value={pdfForm.authorName}
                      onChange={(e) => setPdfForm({ ...pdfForm, authorName: e.target.value })}
                      className="border-orange-300 focus:border-orange-600"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pdf-file" className="font-heading text-sm text-orange-900 uppercase">
                    PDF File (Optional)
                  </Label>
                  <Input
                    id="pdf-file"
                    type="file"
                    accept=".pdf"
                    onChange={(e) => setPdfForm({ ...pdfForm, pdf: e.target.files?.[0] || null })}
                    className="border-orange-300 focus:border-orange-600"
                  />
                </div>

                <Button type="submit" className="w-full bg-orange-600 text-white hover:bg-orange-700 font-heading uppercase tracking-wide">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload PDF
                </Button>
              </form>
            </TabsContent>

            {/* Summary Upload Tab */}
            <TabsContent value="summary" className="space-y-4 mt-6">
              <form onSubmit={handleSummarySubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="summary-book-name" className="font-heading text-sm text-orange-900 uppercase">
                      Book Name *
                    </Label>
                    <Input
                      id="summary-book-name"
                      placeholder="Enter book name"
                      value={summaryForm.bookName}
                      onChange={(e) => setSummaryForm({ ...summaryForm, bookName: e.target.value })}
                      className="border-orange-300 focus:border-orange-600"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="summary-author" className="font-heading text-sm text-orange-900 uppercase">
                      Author Name *
                    </Label>
                    <Input
                      id="summary-author"
                      placeholder="Enter author name"
                      value={summaryForm.authorName}
                      onChange={(e) => setSummaryForm({ ...summaryForm, authorName: e.target.value })}
                      className="border-orange-300 focus:border-orange-600"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="summary-text" className="font-heading text-sm text-orange-900 uppercase">
                    Summary *
                  </Label>
                  <Textarea
                    id="summary-text"
                    placeholder="Write a summary of the book"
                    value={summaryForm.summary}
                    onChange={(e) => setSummaryForm({ ...summaryForm, summary: e.target.value })}
                    className="border-orange-300 focus:border-orange-600 min-h-[120px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="summary-images" className="font-heading text-sm text-orange-900 uppercase">
                    Images (Optional)
                  </Label>
                  <Input
                    id="summary-images"
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={(e) => setSummaryForm({ ...summaryForm, images: Array.from(e.target.files || []) })}
                    className="border-orange-300 focus:border-orange-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="summary-notes-pdf" className="font-heading text-sm text-orange-900 uppercase">
                    Notes PDF (Optional)
                  </Label>
                  <Input
                    id="summary-notes-pdf"
                    type="file"
                    accept=".pdf"
                    onChange={(e) => setSummaryForm({ ...summaryForm, notesPdf: e.target.files?.[0] || null })}
                    className="border-orange-300 focus:border-orange-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="summary-video" className="font-heading text-sm text-orange-900 uppercase">
                    Video (Optional)
                  </Label>
                  <Input
                    id="summary-video"
                    type="file"
                    accept="video/*"
                    onChange={(e) => setSummaryForm({ ...summaryForm, video: e.target.files?.[0] || null })}
                    className="border-orange-300 focus:border-orange-600"
                  />
                </div>

                <Button type="submit" className="w-full bg-orange-600 text-white hover:bg-orange-700 font-heading uppercase tracking-wide">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Summary
                </Button>
              </form>
            </TabsContent>

            {/* Video Upload Tab */}
            <TabsContent value="video" className="space-y-4 mt-6">
              <form onSubmit={handleVideoSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="video-book-name" className="font-heading text-sm text-orange-900 uppercase">
                      Book Name *
                    </Label>
                    <Input
                      id="video-book-name"
                      placeholder="Enter book name"
                      value={videoForm.bookName}
                      onChange={(e) => setVideoForm({ ...videoForm, bookName: e.target.value })}
                      className="border-orange-300 focus:border-orange-600"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="video-author" className="font-heading text-sm text-orange-900 uppercase">
                      Author Name *
                    </Label>
                    <Input
                      id="video-author"
                      placeholder="Enter author name"
                      value={videoForm.authorName}
                      onChange={(e) => setVideoForm({ ...videoForm, authorName: e.target.value })}
                      className="border-orange-300 focus:border-orange-600"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="video-file" className="font-heading text-sm text-orange-900 uppercase">
                    Video (Optional)
                  </Label>
                  <Input
                    id="video-file"
                    type="file"
                    accept="video/*"
                    onChange={(e) => setVideoForm({ ...videoForm, video: e.target.files?.[0] || null })}
                    className="border-orange-300 focus:border-orange-600"
                  />
                </div>

                <Button type="submit" className="w-full bg-orange-600 text-white hover:bg-orange-700 font-heading uppercase tracking-wide">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Video
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          {/* Info Box */}
          <div className="mt-6 p-4 bg-orange-100 border border-orange-300 rounded-lg flex gap-3">
            <AlertCircle className="w-5 h-5 text-orange-700 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-heading text-sm text-orange-900 uppercase tracking-wide">Note</p>
              <p className="font-paragraph text-xs sm:text-sm text-orange-800">
                Media attachments are optional. Fill in at least the required fields (marked with *) to upload your content.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
