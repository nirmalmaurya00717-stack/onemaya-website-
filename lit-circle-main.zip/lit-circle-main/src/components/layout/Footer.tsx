import React from 'react';
import { Link } from 'react-router-dom';
import { Brain, Mail, MapPin, BookOpen, Users, MessageSquare, Bot } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white" role="contentinfo">
      <div className="max-w-[120rem] mx-auto px-3 sm:px-4 md:px-6 lg:px-8 xl:px-10">
        {/* Main Footer Content */}
        <div className="py-4 sm:py-6 md:py-8 lg:py-10 xl:py-12 grid gap-3 sm:gap-4 md:gap-6 lg:gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand Section */}
          <div className="space-y-2 sm:space-y-3 md:space-y-4 text-center sm:text-left">
            <Link to="/" className="flex items-center gap-1 sm:gap-2 md:gap-3 lg:gap-4 justify-center sm:justify-start" aria-label="OneMaya Home">
              <div className="w-5 h-5 sm:w-6 sm:h-6 md:w-8 md:h-8 lg:w-10 lg:h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <Brain className="w-2.5 h-2.5 sm:w-3 sm:h-3 md:w-4 md:h-4 lg:w-5 lg:h-5 text-white" aria-hidden="true" />
              </div>
              <span className="font-heading text-base sm:text-lg md:text-xl lg:text-2xl text-white uppercase tracking-tight">
                OneMaya
              </span>
            </Link>
            <p className="font-paragraph text-xs sm:text-sm md:text-base text-slate-300 max-w-sm mx-auto sm:mx-0">
              AI-powered learning platform for students, researchers, and knowledge seekers. Join our community of passionate learners worldwide.
            </p>
            <div className="space-y-1 sm:space-y-2">
              <div className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm md:text-base text-slate-300 justify-center sm:justify-start">
                <Mail className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" aria-hidden="true" />
                <a href="mailto:onemaya96@gmail.com" className="hover:text-white transition-colors break-all" aria-label="Contact us via email">
                  onemaya96@gmail.com
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2 sm:space-y-3 md:space-y-4 text-center sm:text-left">
            <h3 className="font-heading text-sm sm:text-base md:text-lg font-semibold">Platform Features</h3>
            <nav className="space-y-1 sm:space-y-2" role="navigation" aria-label="Platform features">
              <Link to="/" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Home - OneMaya Learning Platform">
                <BookOpen className="h-3 w-3 sm:h-4 sm:w-4 inline mr-1 sm:mr-2" aria-hidden="true" />
                Home
              </Link>
              <Link to="/library" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Digital Library - Academic Resources">
                <BookOpen className="h-3 w-3 sm:h-4 sm:w-4 inline mr-1 sm:mr-2" aria-hidden="true" />
                Digital Library
              </Link>
              <Link to="/create-group" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Study Groups - Join Learning Communities">
                <Users className="h-3 w-3 sm:h-4 sm:w-4 inline mr-1 sm:mr-2" aria-hidden="true" />
                Study Groups
              </Link>
              <Link to="/discussions" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Academic Discussions - Book Discussions">
                <MessageSquare className="h-3 w-3 sm:h-4 sm:w-4 inline mr-1 sm:mr-2" aria-hidden="true" />
                Discussions
              </Link>
              <Link to="/ask-ai" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="AI Assistant - Learning Help">
                <Bot className="h-3 w-3 sm:h-4 sm:w-4 inline mr-1 sm:mr-2" aria-hidden="true" />
                AI Assistant
              </Link>
            </nav>
          </div>

          {/* Support & Help */}
          <div className="space-y-2 sm:space-y-3 md:space-y-4 text-center sm:text-left">
            <h3 className="font-heading text-sm sm:text-base md:text-lg font-semibold">Support & Help</h3>
            <nav className="space-y-1 sm:space-y-2" role="navigation" aria-label="Support and help">
              <Link to="/contact" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Contact Support">
                Contact Us
              </Link>
              <Link to="/help" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Help Center">
                Help Center
              </Link>
              <Link to="/feedback" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Provide Feedback">
                Feedback
              </Link>
              <Link to="/subscription-plans" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Subscription Plans - Pricing">
                Subscription Plans
              </Link>
            </nav>
          </div>

          {/* Legal & Policies */}
          <div className="space-y-2 sm:space-y-3 md:space-y-4 text-center sm:text-left">
            <h3 className="font-heading text-sm sm:text-base md:text-lg font-semibold">Legal & Policies</h3>
            <nav className="space-y-1 sm:space-y-2" role="navigation" aria-label="Legal and policies">
              <Link to="/privacy-policy" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Privacy Policy">
                Privacy Policy
              </Link>
              <Link to="/terms-conditions" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Terms and Conditions">
                Terms & Conditions
              </Link>
              <Link to="/refund-cancellation" className="block font-paragraph text-xs sm:text-sm md:text-base text-slate-300 hover:text-white transition-colors" aria-label="Refund and Cancellation Policy">
                Refund & Cancellation
              </Link>
            </nav>
            
            {/* Contact Info */}
            <div className="pt-2 sm:pt-3 md:pt-4 border-t border-slate-700">
              <h4 className="font-heading text-xs sm:text-sm font-semibold mb-1 sm:mb-2">Contact Information</h4>
              <div className="flex items-start gap-1 sm:gap-2 text-xs text-slate-300 justify-center sm:justify-start">
                <MapPin className="h-3 w-3 sm:h-4 sm:w-4 mt-0.5 flex-shrink-0" aria-hidden="true" />
                <address className="not-italic text-left">
                  OneMaya Learning Platform<br />
                  Digital Education Hub<br />
                  Knowledge District<br />
                  India
                </address>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="py-2 sm:py-3 md:py-4 lg:py-6 border-t border-slate-700">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-2 sm:gap-3 md:gap-4 text-center sm:text-left">
            <div className="text-xs sm:text-sm text-slate-400">
              <p>&copy; 2025 OneMaya - AI-Powered Learning Platform. All rights reserved.</p>
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-3 md:gap-4 lg:gap-6 text-xs sm:text-sm text-slate-400">
              <span>Empowering learners worldwide 🌍</span>
              <div className="flex items-center gap-2 sm:gap-3 md:gap-4">
                <Link to="/privacy-policy" className="hover:text-white transition-colors">
                  Privacy
                </Link>
                <Link to="/terms-conditions" className="hover:text-white transition-colors">
                  Terms
                </Link>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Contact
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}