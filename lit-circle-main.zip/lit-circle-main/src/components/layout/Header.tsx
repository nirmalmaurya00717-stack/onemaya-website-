import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LanguageSwitcher } from '@/components/ui/language-switcher';
import { useMember } from '@/integrations';
import { useSubscription } from '@/hooks/use-subscription';
import { Image } from '@/components/ui/image';
import { Brain, BookOpen, Users, MessageSquare, Bot, HelpCircle, Upload, Calendar, GraduationCap, User, LogOut, Crown } from 'lucide-react';

export function Header() {
  const location = useLocation();
  const { member, isAuthenticated, isLoading, actions } = useMember();
  const { status } = useSubscription();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const getSubscriptionBadge = () => {
    if (!isAuthenticated || !status) {
      return (
        <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-xs">
          Free Access
        </Badge>
      );
    }
    
    if (!status.isActive && status.canUpgrade) {
      return (
        <Badge variant="destructive" className="text-xs">
          Expired
        </Badge>
      );
    }
    
    if (status.subscriptionType === 'free') {
      return (
        <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">
          {status.daysRemaining}d Free Trial
        </Badge>
      );
    }
    
    if (status.subscriptionType === 'month1') {
      return (
        <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-xs">
          Month 1 Plan
        </Badge>
      );
    }
    
    if (status.subscriptionType === 'month2') {
      return (
        <Badge className="bg-purple-100 text-purple-800 border-purple-200 text-xs">
          Month 2 Plan
        </Badge>
      );
    }
    
    return (
      <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-xs">
        Free Access
      </Badge>
    );
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-blue-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="max-w-[120rem] mx-auto px-3 sm:px-4 md:px-6 lg:px-8 xl:px-10">
        <div className="flex h-12 sm:h-14 md:h-16 lg:h-18 xl:h-20 items-center justify-between">
          {/* Logo with SEO-optimized structure */}
          <Link to="/" className="flex items-center gap-1 sm:gap-2 md:gap-3 lg:gap-4 flex-shrink-0" aria-label="OneMaya - AI-Powered Learning Platform Home">
            <Image 
              src="https://static.wixstatic.com/media/179bf7_31e2e370d29e445d84881704af575470~mv2.png?originWidth=512&originHeight=512" 
              alt="OneMaya logo - open book with brain on top"
              width={56}
              className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 lg:w-12 lg:h-12 xl:w-14 xl:h-14 object-contain"
            />
            <h1 className="font-heading text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl 2xl:text-2xl text-blue-900 uppercase tracking-tight break-words">
              OneMaya
            </h1>
          </Link>

          {/* Desktop Navigation with SEO-optimized structure */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 2xl:gap-3" role="navigation" aria-label="Main navigation">
            <Link to="/" aria-label="Home - OneMaya Learning Platform">
              <Button 
                variant={isActive('/') ? 'default' : 'ghost'} 
                size="sm"
                className={`${isActive('/') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'} px-1.5 xl:px-2 py-1 xl:py-1.5 text-xs xl:text-sm`}
              >
                <GraduationCap className="w-3 h-3 xl:w-4 xl:h-4 mr-1 xl:mr-1.5" aria-hidden="true" />
                <span className="text-xs xl:text-sm">Home</span>
              </Button>
            </Link>
            <Link to="/create-group" aria-label="Create Study Groups - Join Learning Communities">
              <Button 
                variant={isActive('/create-group') ? 'default' : 'ghost'} 
                size="sm"
                className={`${isActive('/create-group') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'} px-1.5 xl:px-2 py-1 xl:py-1.5 text-xs xl:text-sm`}
              >
                <Users className="w-3 h-3 xl:w-4 xl:h-4 mr-1 xl:mr-1.5" aria-hidden="true" />
                <span className="text-xs xl:text-sm">Groups</span>
              </Button>
            </Link>
            <Link to="/library" aria-label="Digital Library - Access Academic Resources">
              <Button 
                variant={isActive('/library') ? 'default' : 'ghost'} 
                size="sm"
                className={`${isActive('/library') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'} px-1.5 xl:px-2 py-1 xl:py-1.5 text-xs xl:text-sm`}
              >
                <BookOpen className="w-3 h-3 xl:w-4 xl:h-4 mr-1 xl:mr-1.5" aria-hidden="true" />
                <span className="text-xs xl:text-sm">Library</span>
              </Button>
            </Link>
            <Link to="/discussions" aria-label="Academic Discussions - Join Book Discussions">
              <Button 
                variant={isActive('/discussions') ? 'default' : 'ghost'} 
                size="sm"
                className={`${isActive('/discussions') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'} px-1.5 xl:px-2 py-1 xl:py-1.5 text-xs xl:text-sm`}
              >
                <MessageSquare className="w-3 h-3 xl:w-4 xl:h-4 mr-1 xl:mr-1.5" aria-hidden="true" />
                <span className="text-xs xl:text-sm">Discuss</span>
              </Button>
            </Link>
            <Link to="/ask-ai" aria-label="AI Assistant - Get Learning Help">
              <Button 
                variant={isActive('/ask-ai') ? 'default' : 'ghost'} 
                size="sm"
                className={`${isActive('/ask-ai') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'} px-1.5 xl:px-2 py-1 xl:py-1.5 text-xs xl:text-sm`}
              >
                <Bot className="w-3 h-3 xl:w-4 xl:h-4 mr-1 xl:mr-1.5" aria-hidden="true" />
                <span className="text-xs xl:text-sm">AI</span>
              </Button>
            </Link>
            <Link to="/feedback">
              <Button 
                variant={isActive('/feedback') ? 'default' : 'ghost'} 
                size="sm"
                className={`${isActive('/feedback') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'} px-1.5 xl:px-2 py-1 xl:py-1.5 text-xs xl:text-sm`}
              >
                <MessageSquare className="w-3 h-3 xl:w-4 xl:h-4 mr-1 xl:mr-1.5" />
                <span className="text-xs xl:text-sm">Feedback</span>
              </Button>
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center gap-1 sm:gap-2">
            <div className="sm:hidden">
              <LanguageSwitcher />
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-blue-700 hover:text-blue-600 hover:bg-blue-50 p-1.5 sm:p-2"
              aria-label="Toggle mobile menu"
            >
              <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </Button>
          </div>

          {/* Right Side - Desktop */}
          <div className="hidden lg:flex items-center gap-1 xl:gap-2">
            <div className="hidden xl:block">
              <LanguageSwitcher />
            </div>
            
            {isAuthenticated && status && (status.canUpgrade || !status.isActive) && (
              <Link to="/subscription-plans">
                <Button 
                  size="sm" 
                  variant="outline"
                  className="border-orange-500 text-orange-600 hover:bg-orange-500 hover:text-white text-xs px-1.5 py-1"
                >
                  <Crown className="w-3 h-3 mr-1" />
                  <span className="hidden xl:inline">Upgrade</span>
                  <span className="xl:hidden">Up</span>
                </Button>
              </Link>
            )}
            
            {/* Authentication Section */}
            <div className="flex items-center gap-1">
              {isLoading ? (
                <div className="w-4 h-4 sm:w-5 sm:h-5 border-2 border-blue-600/30 border-t-blue-600 rounded-full animate-spin"></div>
              ) : isAuthenticated ? (
                <>
                  <Link to="/profile">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-blue-700 hover:text-blue-600 hover:bg-blue-50 text-xs px-1.5 py-1"
                    >
                      <User className="w-3 h-3 mr-1" />
                      <span className="hidden xl:inline">{member?.profile?.nickname || 'Profile'}</span>
                      <span className="xl:hidden">Profile</span>
                    </Button>
                  </Link>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={actions.logout}
                    className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white text-xs px-1.5 py-1"
                  >
                    <LogOut className="w-3 h-3 mr-1" />
                    <span className="hidden xl:inline">Sign Out</span>
                    <span className="xl:hidden">Out</span>
                  </Button>
                </>
              ) : (
                <Button 
                  onClick={actions.login}
                  className="bg-blue-600 text-white hover:bg-blue-700 text-xs px-1.5 py-1"
                  size="sm"
                >
                  <User className="w-3 h-3 mr-1" />
                  Sign In
                </Button>
              )}
            </div>
            
            {/* Subscription Badge */}
            <div className="flex items-center">
              {getSubscriptionBadge()}
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-blue-200 bg-white">
            <div className="px-3 sm:px-4 py-3 sm:py-4 space-y-2 sm:space-y-3">
              {/* Mobile Navigation */}
              <nav className="space-y-2">
                <Link to="/" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button 
                    variant={isActive('/') ? 'default' : 'ghost'} 
                    size="sm"
                    className={`w-full justify-start text-sm ${isActive('/') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'}`}
                  >
                    <GraduationCap className="w-4 h-4 mr-3" />
                    Home
                  </Button>
                </Link>
                <Link to="/create-group" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button 
                    variant={isActive('/create-group') ? 'default' : 'ghost'} 
                    size="sm"
                    className={`w-full justify-start text-sm ${isActive('/create-group') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'}`}
                  >
                    <Users className="w-4 h-4 mr-3" />
                    Study Groups
                  </Button>
                </Link>
                <Link to="/library" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button 
                    variant={isActive('/library') ? 'default' : 'ghost'} 
                    size="sm"
                    className={`w-full justify-start text-sm ${isActive('/library') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'}`}
                  >
                    <BookOpen className="w-4 h-4 mr-3" />
                    Library
                  </Button>
                </Link>
                <Link to="/discussions" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button 
                    variant={isActive('/discussions') ? 'default' : 'ghost'} 
                    size="sm"
                    className={`w-full justify-start text-sm ${isActive('/discussions') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'}`}
                  >
                    <MessageSquare className="w-4 h-4 mr-3" />
                    Discussions
                  </Button>
                </Link>
                <Link to="/ask-ai" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button 
                    variant={isActive('/ask-ai') ? 'default' : 'ghost'} 
                    size="sm"
                    className={`w-full justify-start text-sm ${isActive('/ask-ai') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'}`}
                  >
                    <Bot className="w-4 h-4 mr-3" />
                    AI Assistant
                  </Button>
                </Link>
                <Link to="/feedback" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button 
                    variant={isActive('/feedback') ? 'default' : 'ghost'} 
                    size="sm"
                    className={`w-full justify-start text-sm ${isActive('/feedback') ? 'bg-blue-600 text-white' : 'text-blue-700 hover:text-blue-600 hover:bg-blue-50'}`}
                  >
                    <MessageSquare className="w-4 h-4 mr-3" />
                    Feedback
                  </Button>
                </Link>
              </nav>

              {/* Mobile Authentication & Actions */}
              <div className="pt-3 border-t border-blue-200 space-y-2">
                {isLoading ? (
                  <div className="flex justify-center">
                    <div className="w-6 h-6 border-2 border-blue-600/30 border-t-blue-600 rounded-full animate-spin"></div>
                  </div>
                ) : isAuthenticated ? (
                  <>
                    <Link to="/profile" onClick={() => setIsMobileMenuOpen(false)}>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="w-full justify-start text-blue-700 hover:text-blue-600 hover:bg-blue-50 text-sm"
                      >
                        <User className="w-4 h-4 mr-3" />
                        {member?.profile?.nickname || 'Profile'}
                      </Button>
                    </Link>
                    {status && (status.canUpgrade || !status.isActive) && (
                      <Link to="/subscription-plans" onClick={() => setIsMobileMenuOpen(false)}>
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="w-full justify-start border-orange-500 text-orange-600 hover:bg-orange-500 hover:text-white text-sm"
                        >
                          <Crown className="w-4 h-4 mr-3" />
                          Upgrade Subscription
                        </Button>
                      </Link>
                    )}
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        actions.logout();
                        setIsMobileMenuOpen(false);
                      }}
                      className="w-full justify-start border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white text-sm"
                    >
                      <LogOut className="w-4 h-4 mr-3" />
                      Sign Out
                    </Button>
                  </>
                ) : (
                  <Button 
                    onClick={() => {
                      actions.login();
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full justify-start bg-blue-600 text-white hover:bg-blue-700 text-sm"
                    size="sm"
                  >
                    <User className="w-4 h-4 mr-3" />
                    Sign In
                  </Button>
                )}
                
                <div className="flex justify-center pt-2">
                  {getSubscriptionBadge()}
                </div>
                
                {/* Mobile Language Switcher */}
                <div className="flex justify-center pt-2 sm:hidden">
                  <LanguageSwitcher />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
