import { useState, useEffect } from 'react';
import { AlertCircle, Loader } from 'lucide-react';
import { motion } from 'framer-motion';

interface PDFViewerProps {
  pdfUrl: string;
  title?: string;
  className?: string;
}

export function PDFViewer({ pdfUrl, title, className = '' }: PDFViewerProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Validate URL
    if (!pdfUrl) {
      setError('No PDF URL provided');
      setIsLoading(false);
      return;
    }

    // Check if URL is valid (supports both regular URLs and data URLs)
    try {
      // Data URLs start with 'data:' and don't need URL validation
      if (pdfUrl.startsWith('data:')) {
        setError(null);
        setIsLoading(false);
      } else {
        new URL(pdfUrl);
        setError(null);
        setIsLoading(false);
      }
    } catch {
      setError('Invalid PDF URL');
      setIsLoading(false);
    }
  }, [pdfUrl]);

  if (error) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className={`flex items-center justify-center p-8 bg-red-50 border border-red-200 rounded-lg ${className}`}
      >
        <div className="text-center space-y-3">
          <AlertCircle className="w-8 h-8 text-red-600 mx-auto" />
          <div>
            <p className="font-heading text-sm text-red-900 uppercase tracking-wide">Error Loading PDF</p>
            <p className="font-paragraph text-xs text-red-700 mt-1">{error}</p>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className={`relative bg-gray-100 rounded-lg overflow-hidden ${className}`}
    >
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 z-10">
          <div className="text-center space-y-3">
            <Loader className="w-8 h-8 text-orange-600 mx-auto animate-spin" />
            <p className="font-paragraph text-sm text-gray-600">Loading PDF...</p>
          </div>
        </div>
      )}

      {/* PDF Viewer using iframe with restricted features */}
      <iframe
        src={pdfUrl.includes('#') ? pdfUrl : `${pdfUrl}#toolbar=0&navpanes=0&scrollbar=0`}
        title={title || 'PDF Viewer'}
        className="w-full h-full border-0"
        style={{ minHeight: '600px' }}
        onLoad={() => setIsLoading(false)}
        onError={() => {
          setError('Failed to load PDF. Please try again.');
          setIsLoading(false);
        }}
        onContextMenu={(e) => e.preventDefault()}
      />

      {/* Overlay to prevent interactions that could lead to download */}
      <style>{`
        iframe {
          pointer-events: auto;
        }
        /* Disable print functionality */
        @media print {
          iframe {
            display: none;
          }
        }
      `}</style>
    </motion.div>
  );
}
