import { useState } from 'react';
import { BaseCrudService, useMember } from '@/integrations';
import { UserFeedback } from '@/entities';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Star, Target, BookOpen, X, ThumbsUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { validateEmail, getEmailValidationMessage } from '@/lib/email-validation';

interface ExitFeedbackPromptProps {
  isOpen: boolean;
  onClose: () => void;
  featureName: string;
}

export function ExitFeedbackPrompt({ isOpen, onClose, featureName }: ExitFeedbackPromptProps) {
  const { member, isAuthenticated } = useMember();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    realLifeExamples: '',
    practicalKnowledge: '',
    feedbackType: 'content-evaluation',
    userName: '',
    userEmail: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Validate email in real-time
    if (field === 'userEmail') {
      const errorMessage = getEmailValidationMessage(value);
      setEmailError(errorMessage);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (rating === 0) {
      alert('Please provide a rating out of 10');
      return;
    }

    if (!formData.realLifeExamples.trim()) {
      alert('Please provide real-life examples');
      return;
    }

    if (!formData.practicalKnowledge.trim()) {
      alert('Please provide practical knowledge feedback');
      return;
    }

    // Validate email if not authenticated
    if (!isAuthenticated) {
      const emailValidation = validateEmail(formData.userEmail);
      if (!emailValidation.isValid) {
        setEmailError(emailValidation.errors[0]);
        alert(emailValidation.errors[0]);
        return;
      }
    }

    setIsSubmitting(true);
    
    try {
      const feedbackData: UserFeedback = {
        _id: crypto.randomUUID(),
        featureName,
        rating,
        comment: `Real-life examples: ${formData.realLifeExamples.trim()}\n\nPractical knowledge: ${formData.practicalKnowledge.trim()}`,
        feedbackType: formData.feedbackType,
        userName: isAuthenticated ? (member?.profile?.nickname || member?.contact?.firstName || 'Anonymous') : formData.userName,
        userEmail: isAuthenticated ? (member?.loginEmail || '') : formData.userEmail,
        submissionDateTime: new Date().toISOString()
      };

      await BaseCrudService.create('userfeedback', feedbackData);
      
      setIsSubmitted(true);
      setTimeout(() => {
        onClose();
        resetForm();
      }, 2000);
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStars = () => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            onMouseEnter={() => setHoveredRating(star)}
            onMouseLeave={() => setHoveredRating(0)}
            className="transition-colors duration-200"
          >
            <Star
              className={`w-4 h-4 ${
                star <= (hoveredRating || rating)
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
        <span className="ml-2 font-heading text-sm text-primary">
          {rating > 0 ? `${rating}/10` : '0/10'}
        </span>
      </div>
    );
  };

  const resetForm = () => {
    setRating(0);
    setEmailError(null);
    setIsSubmitted(false);
    setFormData({
      realLifeExamples: '',
      practicalKnowledge: '',
      feedbackType: 'content-evaluation',
      userName: '',
      userEmail: ''
    });
  };

  const handleClose = () => {
    onClose();
    resetForm();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <AnimatePresence mode="wait">
          {isSubmitted ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center py-8 space-y-4"
            >
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <ThumbsUp className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-heading text-lg text-green-600 uppercase tracking-wide">
                Thank You!
              </h3>
              <p className="font-paragraph text-sm text-secondary italic">
                Your content evaluation has been submitted successfully.
              </p>
            </motion.div>
          ) : (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <DialogHeader>
                <DialogTitle className="font-heading text-lg text-primary uppercase tracking-wide flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Evaluate {featureName}
                </DialogTitle>
                <DialogDescription className="font-paragraph text-secondary italic">
                  Help us evaluate content quality for Paid Creator selection with your detailed feedback
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Rating (1-10)
                  </Label>
                  {renderStars()}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="realLifeExamples" className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    Real-life Examples
                  </Label>
                  <Textarea
                    id="realLifeExamples"
                    value={formData.realLifeExamples}
                    onChange={(e) => handleInputChange('realLifeExamples', e.target.value)}
                    placeholder="How does this content relate to real-world situations? Share specific examples..."
                    className="border-subtleborder focus:border-primary font-paragraph"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="practicalKnowledge" className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Practical Knowledge
                  </Label>
                  <Textarea
                    id="practicalKnowledge"
                    value={formData.practicalKnowledge}
                    onChange={(e) => handleInputChange('practicalKnowledge', e.target.value)}
                    placeholder="What practical knowledge or skills can be gained from this content? How applicable is it?"
                    className="border-subtleborder focus:border-primary font-paragraph"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="font-heading text-sm text-primary uppercase tracking-wide">
                    Evaluation Type
                  </Label>
                  <Select value={formData.feedbackType} onValueChange={(value) => handleInputChange('feedbackType', value)}>
                    <SelectTrigger className="border-subtleborder focus:border-primary">
                      <SelectValue placeholder="Select evaluation type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="content-evaluation">Content Quality Evaluation</SelectItem>
                      <SelectItem value="creator-assessment">Creator Assessment</SelectItem>
                      <SelectItem value="educational-value">Educational Value</SelectItem>
                      <SelectItem value="practical-application">Practical Application</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {!isAuthenticated && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="userName" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Your Name
                      </Label>
                      <Input
                        id="userName"
                        value={formData.userName}
                        onChange={(e) => handleInputChange('userName', e.target.value)}
                        placeholder="Enter your name"
                        className="border-subtleborder focus:border-primary font-paragraph"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="userEmail" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Your Email
                      </Label>
                      <Input
                        id="userEmail"
                        type="email"
                        value={formData.userEmail}
                        onChange={(e) => handleInputChange('userEmail', e.target.value)}
                        placeholder="Enter your email"
                        className={`border-subtleborder focus:border-primary font-paragraph ${emailError ? 'border-red-500 focus:border-red-500' : ''}`}
                      />
                      {emailError && (
                        <p className="text-sm text-red-600 font-paragraph">
                          {emailError}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleClose}
                    className="flex-1 border-gray-300 text-gray-600 hover:bg-gray-100 font-heading uppercase tracking-wide"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Skip
                  </Button>
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                        Submitting...
                      </>
                    ) : (
                      'Submit Evaluation'
                    )}
                  </Button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}