import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X, Crown, Star, Zap, Clock, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogCancel } from '@/components/ui/alert-dialog';
import { UPIPaymentModal } from '@/components/ui/upi-payment-modal';

interface SubscriptionPromptProps {
  trigger?: 'content-limit' | 'ad-free' | 'premium-feature' | 'general';
  onDismiss?: () => void;
  className?: string;
}

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscribe: (planType: 'month1' | 'month2') => void;
  currentPlan?: string;
  canUpgrade?: boolean;
  nextPlan?: 'month1' | 'month2';
  daysRemaining?: number;
}

const promptContent = {
  'content-limit': {
    icon: Crown,
    title: 'Unlock Unlimited Access',
    description: 'You\'ve reached your monthly limit. Upgrade to Premium for unlimited reading groups and discussions.',
    benefits: ['Unlimited group access', 'Ad-free experience', 'Premium content'],
    ctaText: 'Upgrade Now',
    urgency: 'high'
  },
  'ad-free': {
    icon: Zap,
    title: 'Enjoy Ad-Free Reading',
    description: 'Remove all advertisements and enjoy a cleaner, faster browsing experience.',
    benefits: ['No more ads', 'Faster loading', 'Better focus'],
    ctaText: 'Go Ad-Free',
    urgency: 'medium'
  },
  'premium-feature': {
    icon: Star,
    title: 'Premium Feature',
    description: 'This feature is available to Premium and Elite subscribers only.',
    benefits: ['Exclusive features', 'Priority support', 'Advanced tools'],
    ctaText: 'Unlock Premium',
    urgency: 'medium'
  },
  'general': {
    icon: Crown,
    title: 'Upgrade Your Experience',
    description: 'Get the most out of your reading journey with our premium features.',
    benefits: ['Ad-free browsing', 'Unlimited access', 'Exclusive content'],
    ctaText: 'See Plans',
    urgency: 'low'
  }
};

export function SubscriptionPrompt({ 
  trigger = 'general', 
  onDismiss,
  className = '' 
}: SubscriptionPromptProps) {
  const [isVisible, setIsVisible] = useState(true);
  const navigate = useNavigate();
  const content = promptContent[trigger];
  const IconComponent = content.icon;

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss?.();
  };

  const handleUpgrade = () => {
    navigate('/subscription-plans');
  };

  if (!isVisible) return null;

  const urgencyColors = {
    high: 'border-red-200 bg-red-50',
    medium: 'border-yellow-200 bg-yellow-50',
    low: 'border-blue-200 bg-blue-50'
  };

  const urgencyBadges = {
    high: { text: 'Limited Access', variant: 'destructive' as const },
    medium: { text: 'Premium Feature', variant: 'secondary' as const },
    low: { text: 'Upgrade Available', variant: 'outline' as const }
  };

  return (
    <Card className={`relative ${urgencyColors[content.urgency]} ${className}`}>
      <button
        onClick={handleDismiss}
        className="absolute top-2 right-2 p-1 hover:bg-black hover:bg-opacity-10 rounded-full transition-all"
        aria-label="Dismiss"
      >
        <X className="w-4 h-4" />
      </button>

      <CardHeader className="pb-3">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-primary text-primary-foreground rounded-full">
            <IconComponent className="w-4 h-4" />
          </div>
          <Badge variant={urgencyBadges[content.urgency].variant}>
            {urgencyBadges[content.urgency].text}
          </Badge>
        </div>
        <CardTitle className="font-heading text-lg text-primary">
          {content.title}
        </CardTitle>
        <CardDescription className="font-paragraph text-foreground">
          {content.description}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2">
          {content.benefits.map((benefit, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              ✓ {benefit}
            </Badge>
          ))}
        </div>

        <div className="flex gap-2">
          <Button onClick={handleUpgrade} className="flex-1">
            {content.ctaText}
          </Button>
          <Button variant="outline" onClick={handleDismiss}>
            Maybe Later
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Modal version for subscription upgrade
export function SubscriptionModal({
  isOpen,
  onClose,
  onSubscribe,
  currentPlan = "Free Trial",
  canUpgrade = true,
  nextPlan = 'month1',
  daysRemaining = 0
}: SubscriptionModalProps) {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'month1' | 'month2' | null>(null);
  const isExpired = daysRemaining <= 0;

  const handlePlanSelect = (planType: 'month1' | 'month2') => {
    setSelectedPlan(planType);
    setShowPaymentModal(true);
  };

  const handlePaymentComplete = () => {
    if (selectedPlan) {
      onSubscribe(selectedPlan);
    }
    setShowPaymentModal(false);
    setSelectedPlan(null);
  };

  const handlePaymentClose = () => {
    setShowPaymentModal(false);
    setSelectedPlan(null);
  };
  
  return (
    <>
      <AlertDialog open={isOpen} onOpenChange={onClose}>
        <AlertDialogContent className="max-w-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-2xl font-heading">
              {isExpired ? 'Your subscription has expired' : 'Upgrade Your Plan'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {isExpired 
                ? 'Continue enjoying our premium features with an affordable monthly plan.'
                : `You have ${daysRemaining} days remaining on your ${currentPlan}.`
              }
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="space-y-4">
            {/* Current Plan Status */}
            <Card className="border-2">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-heading">Current Plan</CardTitle>
                  <Badge variant={isExpired ? "destructive" : "default"}>
                    {isExpired ? 'Expired' : 'Active'}
                  </Badge>
                </div>
                <CardDescription className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  {currentPlan} • {isExpired ? 'Expired' : `${daysRemaining} days remaining`}
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Available Plans */}
            {canUpgrade && (
              <div className="grid gap-4 md:grid-cols-2">
                {nextPlan === 'month1' && (
                  <Card className="border-2 border-primary">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="font-heading">Month 1 Plan</CardTitle>
                        <Badge className="bg-primary text-primary-foreground">Recommended</Badge>
                      </div>
                      <CardDescription>30 days of premium access</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold font-heading mb-4">₹49</div>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Access to all reading groups
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Unlimited discussion participation
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Video content library
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Live session scheduling
                        </li>
                      </ul>
                      <Button 
                        className="w-full mt-4" 
                        onClick={() => handlePlanSelect('month1')}
                      >
                        Pay ₹49 via UPI
                      </Button>
                    </CardContent>
                  </Card>
                )}

                {(nextPlan === 'month2' || nextPlan === 'month1') && (
                  <Card className="border-2">
                    <CardHeader>
                      <CardTitle className="font-heading">Month 2 Plan</CardTitle>
                      <CardDescription>30 days of premium access</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold font-heading mb-4">₹49</div>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          All Month 1 features
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Priority support
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Advanced AI features
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Exclusive content access
                        </li>
                      </ul>
                      <Button 
                        className="w-full mt-4" 
                        variant={nextPlan === 'month1' ? 'outline' : 'default'}
                        onClick={() => handlePlanSelect('month2')}
                        disabled={nextPlan === 'month1'}
                      >
                        {nextPlan === 'month1' ? 'Available after Month 1' : 'Pay ₹49 via UPI'}
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}

            {!canUpgrade && (
              <Card>
                <CardContent className="pt-6 text-center">
                  <h3 className="text-lg font-heading mb-2">All Plans Completed</h3>
                  <p className="text-muted-foreground">
                    You have completed all available subscription plans. Thank you for being a valued member!
                  </p>
                </CardContent>
              </Card>
            )}
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel onClick={onClose}>Maybe Later</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* UPI Payment Modal */}
      <UPIPaymentModal
        isOpen={showPaymentModal}
        onClose={handlePaymentClose}
        onPaymentComplete={handlePaymentComplete}
        planType={selectedPlan || 'month1'}
        amount={49}
      />
    </>
  );
}