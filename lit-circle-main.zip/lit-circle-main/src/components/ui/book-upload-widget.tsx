import { useState } from 'react';
import { BaseCrudService } from '@/integrations';
import { PopularBooks } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { Upload, BookOpen, X, CheckCircle, FileText, Paperclip } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';

interface BookUploadWidgetProps {
  className?: string;
  variant?: 'button' | 'card';
}

export function BookUploadWidget({ className = '', variant = 'button' }: BookUploadWidgetProps) {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    bookName: '',
    bookAuthor: '',
    attachedFile: null as File | null
  });

  const handleInputChange = (field: string, value: string | File | null) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    handleInputChange('attachedFile', file);
  };

  const removeFile = () => {
    handleInputChange('attachedFile', null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.bookName.trim()) {
      alert(t('forms.required'));
      return;
    }

    if (!formData.bookAuthor.trim()) {
      alert(t('forms.required'));
      return;
    }

    setIsSubmitting(true);
    
    try {
      const bookData: PopularBooks = {
        _id: crypto.randomUUID(),
        title: formData.bookName.trim(),
        author: formData.bookAuthor.trim(),
        genre: 'User Submitted',
        averageRating: 0,
        publicationYear: new Date().getFullYear(),
        synopsis: `Book submitted by community member: ${formData.bookName} by ${formData.bookAuthor}`,
        coverImage: 'https://static.wixstatic.com/media/179bf7_34b939db6ccd46209745c0c56ee7e005~mv2.png?originWidth=256&originHeight=384'
      };

      await BaseCrudService.create('popularbooks', bookData);
      
      setIsSubmitted(true);
      setTimeout(() => {
        setIsOpen(false);
        setIsSubmitted(false);
        setFormData({
          bookName: '',
          bookAuthor: '',
          attachedFile: null
        });
      }, 2000);
    } catch (error) {
      console.error('Error uploading book:', error);
      alert(t('home.uploadError'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const triggerButton = variant === 'card' ? (
    <Card className={`border-blue-200 bg-blue-50 hover:border-blue-400 transition-colors duration-300 cursor-pointer ${className}`}>
      <CardHeader className="text-center space-y-4">
        <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto">
          <Upload className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="font-heading text-lg text-blue-900 uppercase tracking-wide">
          {t('home.uploadBook')}
        </CardTitle>
        <CardDescription className="font-paragraph text-blue-600 italic">
          {t('home.uploadBookDesc')}
        </CardDescription>
      </CardHeader>
    </Card>
  ) : (
    <Button 
      className={`bg-blue-600 text-white hover:bg-blue-700 font-heading uppercase tracking-wide ${className}`}
    >
      <Upload className="w-4 h-4 mr-2" />
      {t('home.uploadBook')}
    </Button>
  );

  return (
    <>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          {triggerButton}
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          {isSubmitted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-8 space-y-4"
            >
              <CheckCircle className="w-12 h-12 text-green-600 mx-auto" />
              <h3 className="font-heading text-lg text-green-600 uppercase">{t('home.uploadSuccess')}</h3>
              <p className="font-paragraph text-sm text-secondary italic">
                {t('home.uploadBookDesc')}
              </p>
            </motion.div>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle className="font-heading text-lg text-blue-900 uppercase tracking-wide flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  {t('home.uploadBook')}
                </DialogTitle>
                <DialogDescription className="font-paragraph text-blue-600 italic">
                  {t('home.uploadBookDesc')}
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="bookName" className="font-heading text-sm text-blue-900 uppercase tracking-wide">
                    {t('home.bookName')} *
                  </Label>
                  <Input
                    id="bookName"
                    value={formData.bookName}
                    onChange={(e) => handleInputChange('bookName', e.target.value)}
                    placeholder={t('home.bookName')}
                    className="border-blue-200 focus:border-blue-600 font-paragraph"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bookAuthor" className="font-heading text-sm text-blue-900 uppercase tracking-wide">
                    {t('home.bookAuthor')} *
                  </Label>
                  <Input
                    id="bookAuthor"
                    value={formData.bookAuthor}
                    onChange={(e) => handleInputChange('bookAuthor', e.target.value)}
                    placeholder={t('home.bookAuthor')}
                    className="border-blue-200 focus:border-blue-600 font-paragraph"
                    required
                  />
                </div>

                {/* Media Attachments Section */}
                <div className="space-y-3 pt-2 border-t border-blue-100">
                  <Label className="font-heading text-sm text-blue-900 uppercase tracking-wide">
                    Media Attachments
                  </Label>
                  
                  <div className="space-y-3">
                    {/* File Upload */}
                    <div className="relative">
                      <input
                        type="file"
                        id="fileUpload"
                        onChange={handleFileChange}
                        className="hidden"
                        accept=".pdf,.doc,.docx,.txt,.epub,.mobi"
                      />
                      <Label
                        htmlFor="fileUpload"
                        className="flex items-center justify-center w-full p-4 border-2 border-dashed border-blue-300 rounded-lg cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-colors"
                      >
                        <div className="text-center space-y-2">
                          <Paperclip className="w-6 h-6 text-blue-500 mx-auto" />
                          <div className="font-paragraph text-sm text-blue-600">
                            <span className="font-medium">Click to upload file</span>
                            <br />
                            <span className="text-xs text-blue-400">PDF, DOC, TXT, EPUB (max 10MB)</span>
                          </div>
                        </div>
                      </Label>
                    </div>

                    {/* Selected File Display */}
                    {formData.attachedFile && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <FileText className="w-4 h-4 text-blue-600" />
                          <div>
                            <p className="font-paragraph text-sm text-blue-900 font-medium">
                              {formData.attachedFile.name}
                            </p>
                            <p className="font-paragraph text-xs text-blue-500">
                              {(formData.attachedFile.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                          </div>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={removeFile}
                          className="text-blue-600 hover:text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </motion.div>
                    )}
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsOpen(false)}
                    className="flex-1 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-heading uppercase tracking-wide"
                  >
                    {t('common.cancel')}
                  </Button>
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 bg-blue-600 text-white hover:bg-blue-700 font-heading uppercase tracking-wide"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                        {t('common.loading')}
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        {t('forms.submit')}
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Content Evaluation Widget for Book Uploads */}
      {isOpen && (
        <FeedbackWidget featureName="Book Upload Content" variant="floating" />
      )}
    </>
  );
}