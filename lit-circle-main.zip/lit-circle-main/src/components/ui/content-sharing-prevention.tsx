import { useEffect } from 'react';
import { AlertTriangle, Shield } from 'lucide-react';

interface ContentSharingPreventionProps {
  enabled?: boolean;
  showWarning?: boolean;
}

export function ContentSharingPrevention({ 
  enabled = true, 
  showWarning = true 
}: ContentSharingPreventionProps) {
  
  useEffect(() => {
    if (!enabled) return;

    // Disable right-click context menu
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      if (showWarning) {
        showProtectionWarning('Right-click is disabled to protect content from external sharing.');
      }
      return false;
    };

    // Disable text selection
    const handleSelectStart = (e: Event) => {
      e.preventDefault();
      return false;
    };

    // Disable drag and drop
    const handleDragStart = (e: DragEvent) => {
      e.preventDefault();
      if (showWarning) {
        showProtectionWarning('Drag and drop is disabled to prevent content sharing.');
      }
      return false;
    };

    // Disable keyboard shortcuts for copying, saving, etc.
    const handleKeyDown = (e: KeyboardEvent) => {
      // Disable Ctrl+S (Save), Ctrl+A (Select All), Ctrl+C (Copy), Ctrl+V (Paste), Ctrl+X (Cut)
      if (e.ctrlKey && ['s', 'a', 'c', 'v', 'x'].includes(e.key.toLowerCase())) {
        e.preventDefault();
        if (showWarning) {
          showProtectionWarning(`${e.key.toUpperCase()} shortcut is disabled to protect content.`);
        }
        return false;
      }
      
      // Disable F12 (Developer Tools), Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
      if (
        e.key === 'F12' || 
        (e.ctrlKey && e.shiftKey && ['i', 'j'].includes(e.key.toLowerCase())) ||
        (e.ctrlKey && e.key.toLowerCase() === 'u')
      ) {
        e.preventDefault();
        if (showWarning) {
          showProtectionWarning('Developer tools are disabled to protect content security.');
        }
        return false;
      }

      // Disable Print Screen
      if (e.key === 'PrintScreen') {
        e.preventDefault();
        if (showWarning) {
          showProtectionWarning('Screenshots are disabled to protect content from external sharing.');
        }
        return false;
      }
    };

    // Add event listeners
    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('selectstart', handleSelectStart);
    document.addEventListener('dragstart', handleDragStart);
    document.addEventListener('keydown', handleKeyDown);

    // Add CSS to prevent text selection and dragging
    const style = document.createElement('style');
    style.textContent = `
      * {
        -webkit-user-select: none !important;
        -moz-user-select: none !important;
        -ms-user-select: none !important;
        user-select: none !important;
        -webkit-user-drag: none !important;
        -khtml-user-drag: none !important;
        -moz-user-drag: none !important;
        -o-user-drag: none !important;
        user-drag: none !important;
      }
      
      input, textarea {
        -webkit-user-select: text !important;
        -moz-user-select: text !important;
        -ms-user-select: text !important;
        user-select: text !important;
      }
    `;
    document.head.appendChild(style);

    // Cleanup function
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('selectstart', handleSelectStart);
      document.removeEventListener('dragstart', handleDragStart);
      document.removeEventListener('keydown', handleKeyDown);
      document.head.removeChild(style);
    };
  }, [enabled, showWarning]);

  const showProtectionWarning = (message: string) => {
    // Create a temporary warning toast
    const warning = document.createElement('div');
    warning.className = 'fixed top-4 right-4 z-50 bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 max-w-sm';
    warning.innerHTML = `
      <svg class="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
      </svg>
      <span class="text-sm">${message}</span>
    `;
    
    document.body.appendChild(warning);
    
    // Remove warning after 3 seconds
    setTimeout(() => {
      if (warning.parentNode) {
        warning.parentNode.removeChild(warning);
      }
    }, 3000);
  };

  return null; // This component doesn't render anything visible
}

// Hook for easy integration
export function useContentSharingPrevention(options: ContentSharingPreventionProps = {}) {
  return ContentSharingPrevention(options);
}