import React, { useState } from 'react';
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Copy, CheckCircle, Smartphone, QrCode, CreditCard } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface UPIPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentComplete: () => void;
  planType: 'month1' | 'month2';
  amount: number;
}

const UPI_ID = 'nirmalmaurya00717-1@okicici';

export function UPIPaymentModal({
  isOpen,
  onClose,
  onPaymentComplete,
  planType,
  amount
}: UPIPaymentModalProps) {
  const [paymentStep, setPaymentStep] = useState<'details' | 'payment' | 'confirmation'>('details');
  const [transactionId, setTransactionId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const planName = planType === 'month1' ? 'Month 1 Plan' : 'Month 2 Plan';

  const copyUPIId = () => {
    navigator.clipboard.writeText(UPI_ID);
    toast({
      title: "UPI ID Copied!",
      description: "UPI ID has been copied to your clipboard.",
    });
  };

  const handlePaymentComplete = async () => {
    if (!transactionId.trim()) {
      toast({
        title: "Transaction ID Required",
        description: "Please enter your transaction ID to complete the payment.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // Simulate payment verification (in real app, this would verify with payment gateway)
    setTimeout(() => {
      setIsProcessing(false);
      setPaymentStep('confirmation');
      
      // Complete the subscription upgrade
      setTimeout(() => {
        onPaymentComplete();
        onClose();
        toast({
          title: "Payment Successful!",
          description: `Your ${planName} subscription has been activated.`,
        });
      }, 2000);
    }, 2000);
  };

  const resetModal = () => {
    setPaymentStep('details');
    setTransactionId('');
    setIsProcessing(false);
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={handleClose}>
      <AlertDialogContent className="max-w-md">
        {paymentStep === 'details' && (
          <>
            <AlertDialogHeader>
              <AlertDialogTitle className="text-xl font-heading flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Complete Payment
              </AlertDialogTitle>
              <AlertDialogDescription>
                You're subscribing to {planName} for ₹{amount}
              </AlertDialogDescription>
            </AlertDialogHeader>
            
            <div className="space-y-4">
              <Card className="border-2 border-primary">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-heading">Payment Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Plan:</span>
                    <Badge variant="default">{planName}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Duration:</span>
                    <span className="font-paragraph text-sm font-semibold">30 days</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Amount:</span>
                    <span className="font-heading text-lg font-bold text-primary">₹{amount}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Smartphone className="h-4 w-4 text-blue-600" />
                    <span className="font-heading text-sm text-blue-800">UPI Payment Only</span>
                  </div>
                  <p className="font-paragraph text-xs text-blue-700">
                    We currently accept payments only through UPI for your convenience and security.
                  </p>
                </CardContent>
              </Card>
            </div>

            <AlertDialogFooter className="flex gap-2">
              <Button variant="outline" onClick={handleClose}>
                Cancel
              </Button>
              <Button onClick={() => setPaymentStep('payment')} className="flex-1">
                Proceed to Pay ₹{amount}
              </Button>
            </AlertDialogFooter>
          </>
        )}

        {paymentStep === 'payment' && (
          <>
            <AlertDialogHeader>
              <AlertDialogTitle className="text-xl font-heading flex items-center gap-2">
                <Smartphone className="h-5 w-5" />
                UPI Payment
              </AlertDialogTitle>
              <AlertDialogDescription>
                Pay ₹{amount} using UPI to activate your {planName}
              </AlertDialogDescription>
            </AlertDialogHeader>
            
            <div className="space-y-4">
              <Card className="border-2 border-green-200 bg-green-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-heading text-green-800">
                    Pay to UPI ID
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <Label className="font-paragraph text-sm text-green-700 mb-2 block">
                      UPI ID:
                    </Label>
                    <div className="flex items-center gap-2">
                      <Input 
                        value={UPI_ID} 
                        readOnly 
                        className="font-mono text-sm bg-gray-50 border-green-300"
                      />
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={copyUPIId}
                        className="border-green-300 text-green-700 hover:bg-green-100"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <Label className="font-paragraph text-sm text-green-700 mb-2 block">
                      Amount to Pay:
                    </Label>
                    <div className="text-2xl font-heading font-bold text-green-800">
                      ₹{amount}
                    </div>
                  </div>

                  <div className="text-center space-y-2">
                    <div className="flex items-center justify-center gap-2 text-sm text-green-700">
                      <QrCode className="h-4 w-4" />
                      <span className="font-paragraph">Open your UPI app and pay to the above UPI ID</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-4">
                  <Label htmlFor="transactionId" className="font-paragraph text-sm font-medium">
                    Transaction ID / Reference Number *
                  </Label>
                  <Input
                    id="transactionId"
                    placeholder="Enter transaction ID from your UPI app"
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    className="mt-2"
                  />
                  <p className="font-paragraph text-xs text-muted-foreground mt-1">
                    Enter the transaction ID you received after making the UPI payment
                  </p>
                </CardContent>
              </Card>
            </div>

            <AlertDialogFooter className="flex gap-2">
              <Button variant="outline" onClick={() => setPaymentStep('details')}>
                Back
              </Button>
              <Button 
                onClick={handlePaymentComplete} 
                disabled={isProcessing || !transactionId.trim()}
                className="flex-1"
              >
                {isProcessing ? 'Verifying...' : 'Confirm Payment'}
              </Button>
            </AlertDialogFooter>
          </>
        )}

        {paymentStep === 'confirmation' && (
          <>
            <AlertDialogHeader>
              <AlertDialogTitle className="text-xl font-heading flex items-center gap-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                Payment Successful!
              </AlertDialogTitle>
              <AlertDialogDescription>
                Your {planName} has been activated successfully.
              </AlertDialogDescription>
            </AlertDialogHeader>
            
            <div className="space-y-4">
              <Card className="border-2 border-green-200 bg-green-50">
                <CardContent className="pt-6 text-center">
                  <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="font-heading text-lg text-green-800 mb-2">
                    Subscription Activated!
                  </h3>
                  <p className="font-paragraph text-sm text-green-700">
                    You now have access to all {planName} features for the next 30 days.
                  </p>
                </CardContent>
              </Card>

              <div className="text-center">
                <p className="font-paragraph text-xs text-muted-foreground">
                  Transaction ID: {transactionId}
                </p>
              </div>
            </div>

            <AlertDialogFooter>
              <Button onClick={handleClose} className="w-full">
                Continue
              </Button>
            </AlertDialogFooter>
          </>
        )}
      </AlertDialogContent>
    </AlertDialog>
  );
}