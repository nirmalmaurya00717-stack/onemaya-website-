import { Shield, AlertTriangle, Lock, Eye, Copyright } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';

interface ContentProtectionNoticeProps {
  variant?: 'upload' | 'display' | 'compact';
  className?: string;
}

export function ContentProtectionNotice({ variant = 'upload', className = '' }: ContentProtectionNoticeProps) {
  if (variant === 'compact') {
    return (
      <div className={`flex items-center gap-2 p-2 bg-red-50 border border-red-200 rounded-lg ${className}`}>
        <Shield className="w-4 h-4 text-red-600 flex-shrink-0" />
        <span className="text-xs font-medium text-red-800">
          Protected Content - No External Sharing
        </span>
      </div>
    );
  }

  if (variant === 'display') {
    return (
      <Alert className={`border-red-200 bg-red-50 ${className}`}>
        <Shield className="h-4 w-4 text-red-600" />
        <AlertDescription className="text-red-800">
          <div className="space-y-2">
            <p className="font-semibold">🔒 Protected Educational Content</p>
            <p className="text-sm">
              This content is protected and exclusively for registered members. 
              Sharing, downloading, or redistributing on external platforms is strictly prohibited.
            </p>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card className={`border-red-200 bg-red-50 ${className}`}>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
              <Shield className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <h3 className="font-heading text-lg text-red-800 uppercase tracking-wide">
                Content Protection Policy
              </h3>
              <p className="font-paragraph text-sm text-red-700 italic">
                Your uploads are protected from external sharing
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold text-red-800 text-sm">Prohibited Actions:</p>
                <ul className="text-xs text-red-700 space-y-1 mt-1">
                  <li>• Sharing on social media platforms (YouTube, Facebook, Instagram, Twitter, etc.)</li>
                  <li>• Uploading to external video/content platforms</li>
                  <li>• Redistributing through messaging apps (WhatsApp, Telegram, etc.)</li>
                  <li>• Commercial use or resale of content</li>
                  <li>• Downloading for external distribution</li>
                </ul>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Lock className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold text-red-800 text-sm">Technical Protections:</p>
                <ul className="text-xs text-red-700 space-y-1 mt-1">
                  <li>• Screenshot and screen recording prevention</li>
                  <li>• Right-click and copy protection</li>
                  <li>• Download restrictions and watermarking</li>
                  <li>• Access limited to registered members only</li>
                </ul>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Copyright className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold text-red-800 text-sm">Legal Notice:</p>
                <p className="text-xs text-red-700 mt-1">
                  All uploaded content remains the intellectual property of the creator and is protected 
                  under copyright law. Unauthorized sharing may result in account suspension and legal action.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 pt-2">
            <Badge variant="destructive" className="text-xs">
              <Eye className="w-3 h-3 mr-1" />
              Members Only
            </Badge>
            <Badge variant="destructive" className="text-xs">
              <Shield className="w-3 h-3 mr-1" />
              Protected Content
            </Badge>
            <Badge variant="destructive" className="text-xs">
              <Lock className="w-3 h-3 mr-1" />
              No External Sharing
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}