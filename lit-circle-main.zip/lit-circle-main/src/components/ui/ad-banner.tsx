import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AdBannerProps {
  size?: 'banner' | 'rectangle' | 'leaderboard' | 'sidebar';
  position?: 'top' | 'bottom' | 'inline';
  dismissible?: boolean;
  className?: string;
}

const adSizes = {
  banner: { width: '728px', height: '90px' },
  rectangle: { width: '300px', height: '250px' },
  leaderboard: { width: '728px', height: '90px' },
  sidebar: { width: '160px', height: '600px' }
};

export function AdBanner({ 
  size = 'banner', 
  position = 'inline', 
  dismissible = false,
  className = '' 
}: AdBannerProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [adContent, setAdContent] = useState<string>('');

  useEffect(() => {
    // Simulate ad loading - in real implementation, this would load actual ads
    const loadAd = () => {
      // Mock ad content - replace with actual ad network integration
      const mockAds = [
        {
          title: "Discover New Books",
          description: "Find your next favorite read with our curated book recommendations",
          cta: "Browse Now",
          background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
        },
        {
          title: "Premium Reading Experience",
          description: "Upgrade to Premium for ad-free browsing and exclusive content",
          cta: "Upgrade",
          background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)"
        },
        {
          title: "Join Reading Groups",
          description: "Connect with fellow book lovers in our vibrant community",
          cta: "Join Now",
          background: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)"
        }
      ];

      const randomAd = mockAds[Math.floor(Math.random() * mockAds.length)];
      setAdContent(JSON.stringify(randomAd));
    };

    loadAd();
  }, []);

  if (!isVisible) return null;

  const adSize = adSizes[size];
  const parsedAd = adContent ? JSON.parse(adContent) : null;

  const positionClasses = {
    top: 'fixed top-0 left-0 right-0 z-50',
    bottom: 'fixed bottom-0 left-0 right-0 z-50',
    inline: 'relative'
  };

  return (
    <div 
      className={`${positionClasses[position]} ${className}`}
      style={{ 
        width: position === 'inline' ? adSize.width : '100%',
        minHeight: adSize.height 
      }}
    >
      <div 
        className="relative flex items-center justify-center text-white rounded-lg overflow-hidden mx-auto"
        style={{ 
          width: adSize.width,
          height: adSize.height,
          background: parsedAd?.background || '#f0f0f0'
        }}
      >
        {/* Ad Content */}
        {parsedAd ? (
          <div className="text-center p-4">
            <h3 className="font-heading text-sm font-bold mb-1">
              {parsedAd.title}
            </h3>
            <p className="font-paragraph text-xs mb-2 opacity-90">
              {parsedAd.description}
            </p>
            <Button 
              size="sm" 
              variant="secondary"
              className="text-xs px-3 py-1"
              onClick={() => {
                // In real implementation, track ad clicks
                console.log('Ad clicked:', parsedAd.title);
              }}
            >
              {parsedAd.cta}
            </Button>
          </div>
        ) : (
          <div className="text-center text-gray-500">
            <div className="font-paragraph text-xs">Advertisement</div>
            <div className="font-paragraph text-xs opacity-70">Loading...</div>
          </div>
        )}

        {/* Dismiss button */}
        {dismissible && (
          <button
            onClick={() => setIsVisible(false)}
            className="absolute top-1 right-1 p-1 bg-black bg-opacity-20 rounded-full hover:bg-opacity-40 transition-all"
            aria-label="Close ad"
          >
            <X className="w-3 h-3 text-white" />
          </button>
        )}

        {/* Ad label */}
        <div className="absolute top-1 left-1 bg-black bg-opacity-20 px-2 py-0.5 rounded">
          <span className="font-paragraph text-xs text-white opacity-70">Ad</span>
        </div>
      </div>
    </div>
  );
}

// Google AdSense placeholder component
export function GoogleAdSense({ 
  adSlot, 
  adFormat = 'auto',
  fullWidthResponsive = true,
  className = ''
}: {
  adSlot: string;
  adFormat?: string;
  fullWidthResponsive?: boolean;
  className?: string;
}) {
  useEffect(() => {
    // In real implementation, load Google AdSense script
    // (window.adsbygoogle = window.adsbygoogle || []).push({});
  }, []);

  return (
    <div className={`ad-container ${className}`}>
      {/* This would be replaced with actual Google AdSense code */}
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-XXXXXXXXX" // Replace with actual publisher ID
        data-ad-slot={adSlot}
        data-ad-format={adFormat}
        data-full-width-responsive={fullWidthResponsive.toString()}
      />
      
      {/* Fallback for development */}
      <div className="bg-gray-100 border-2 border-dashed border-gray-300 p-4 text-center">
        <div className="font-paragraph text-sm text-gray-500">
          Google AdSense Placeholder
        </div>
        <div className="font-paragraph text-xs text-gray-400">
          Ad Slot: {adSlot}
        </div>
      </div>
    </div>
  );
}