import { useState } from 'react';
import { BaseCrudService, useMember } from '@/integrations';
import { UserFeedback } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Star, MessageSquare, Send, X, ThumbsUp, Target, BookOpen } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { validateEmail, getEmailValidationMessage } from '@/lib/email-validation';

interface FeedbackWidgetProps {
  featureName: string;
  className?: string;
  variant?: 'floating' | 'inline' | 'compact';
}

export function FeedbackWidget({ featureName, className = '', variant = 'floating' }: FeedbackWidgetProps) {
  const { member, isAuthenticated } = useMember();
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    realLifeExamples: '',
    practicalKnowledge: '',
    feedbackType: '',
    userName: '',
    userEmail: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Validate email in real-time
    if (field === 'userEmail') {
      const errorMessage = getEmailValidationMessage(value);
      setEmailError(errorMessage);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (rating === 0) {
      alert('Please provide a rating out of 10');
      return;
    }

    if (!formData.realLifeExamples.trim()) {
      alert('Please provide real-life examples');
      return;
    }

    if (!formData.practicalKnowledge.trim()) {
      alert('Please provide practical knowledge feedback');
      return;
    }

    // Validate email if not authenticated
    if (!isAuthenticated) {
      const emailValidation = validateEmail(formData.userEmail);
      if (!emailValidation.isValid) {
        setEmailError(emailValidation.errors[0]);
        alert(emailValidation.errors[0]);
        return;
      }
    }

    setIsSubmitting(true);
    
    try {
      const feedbackData: UserFeedback = {
        _id: crypto.randomUUID(),
        featureName,
        rating,
        comment: `Real-life examples: ${formData.realLifeExamples.trim()}\n\nPractical knowledge: ${formData.practicalKnowledge.trim()}`,
        feedbackType: formData.feedbackType || 'content-evaluation',
        userName: isAuthenticated ? (member?.profile?.nickname || member?.contact?.firstName || 'Anonymous') : formData.userName,
        userEmail: isAuthenticated ? (member?.loginEmail || '') : formData.userEmail,
        submissionDateTime: new Date().toISOString()
      };

      await BaseCrudService.create('userfeedback', feedbackData);
      
      setIsSubmitted(true);
      setTimeout(() => {
        setIsOpen(false);
        setIsSubmitted(false);
        setRating(0);
        setEmailError(null);
        setFormData({
          realLifeExamples: '',
          practicalKnowledge: '',
          feedbackType: '',
          userName: '',
          userEmail: ''
        });
      }, 2000);
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStars = () => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            onMouseEnter={() => setHoveredRating(star)}
            onMouseLeave={() => setHoveredRating(0)}
            className="transition-colors duration-200"
          >
            <Star
              className={`w-5 h-5 ${
                star <= (hoveredRating || rating)
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
        <span className="ml-2 font-heading text-sm text-primary">
          {rating > 0 ? `${rating}/10` : '0/10'}
        </span>
      </div>
    );
  };

  if (variant === 'compact') {
    return (
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            variant="outline" 
            size="sm"
            className={`border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white ${className}`}
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Feedback
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          {isSubmitted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-8 space-y-4"
            >
              <ThumbsUp className="w-12 h-12 text-green-600 mx-auto" />
              <h3 className="font-heading text-lg text-green-600 uppercase">Thank You!</h3>
              <p className="font-paragraph text-sm text-secondary italic">
                Your feedback has been submitted successfully.
              </p>
            </motion.div>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle className="font-heading text-lg text-primary uppercase tracking-wide">
                  Evaluate {featureName}
                </DialogTitle>
                <DialogDescription className="font-paragraph text-secondary italic">
                  Help us evaluate content quality for Paid Creator selection
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Rating (1-10)
                  </Label>
                  {renderStars()}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="realLifeExamples" className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    Real-life Examples
                  </Label>
                  <Textarea
                    id="realLifeExamples"
                    value={formData.realLifeExamples}
                    onChange={(e) => handleInputChange('realLifeExamples', e.target.value)}
                    placeholder="How does this content relate to real-world situations? Share specific examples..."
                    className="border-subtleborder focus:border-primary font-paragraph"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="practicalKnowledge" className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Practical Knowledge
                  </Label>
                  <Textarea
                    id="practicalKnowledge"
                    value={formData.practicalKnowledge}
                    onChange={(e) => handleInputChange('practicalKnowledge', e.target.value)}
                    placeholder="What practical knowledge or skills can be gained from this content? How applicable is it?"
                    className="border-subtleborder focus:border-primary font-paragraph"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="font-heading text-sm text-primary uppercase tracking-wide">
                    Evaluation Type
                  </Label>
                  <Select value={formData.feedbackType} onValueChange={(value) => handleInputChange('feedbackType', value)}>
                    <SelectTrigger className="border-subtleborder focus:border-primary">
                      <SelectValue placeholder="Select evaluation type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="content-evaluation">Content Quality Evaluation</SelectItem>
                      <SelectItem value="creator-assessment">Creator Assessment</SelectItem>
                      <SelectItem value="educational-value">Educational Value</SelectItem>
                      <SelectItem value="practical-application">Practical Application</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {!isAuthenticated && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="userName" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Your Name
                      </Label>
                      <Input
                        id="userName"
                        value={formData.userName}
                        onChange={(e) => handleInputChange('userName', e.target.value)}
                        placeholder="Enter your name"
                        className="border-subtleborder focus:border-primary font-paragraph"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="userEmail" className="font-heading text-sm text-primary uppercase tracking-wide">
                        Your Email
                      </Label>
                      <Input
                        id="userEmail"
                        type="email"
                        value={formData.userEmail}
                        onChange={(e) => handleInputChange('userEmail', e.target.value)}
                        placeholder="Enter your email"
                        className={`border-subtleborder focus:border-primary font-paragraph ${emailError ? 'border-red-500 focus:border-red-500' : ''}`}
                      />
                      {emailError && (
                        <p className="text-sm text-red-600 font-paragraph">
                          {emailError}
                        </p>
                      )}
                    </div>
                  </>
                )}

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                      Submitting Evaluation...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Submit Evaluation
                    </>
                  )}
                </Button>
              </form>
            </>
          )}
        </DialogContent>
      </Dialog>
    );
  }

  if (variant === 'inline') {
    return (
      <Card className={`border-subtleborder bg-background ${className}`}>
        <CardHeader>
          <CardTitle className="font-heading text-lg text-primary uppercase tracking-wide flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Evaluate {featureName}
          </CardTitle>
          <CardDescription className="font-paragraph text-secondary italic">
            Help us evaluate content quality for Paid Creator selection
          </CardDescription>
        </CardHeader>
        
        {isSubmitted ? (
          <CardContent>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-6 space-y-4"
            >
              <ThumbsUp className="w-10 h-10 text-green-600 mx-auto" />
              <h3 className="font-heading text-base text-green-600 uppercase">Thank You!</h3>
              <p className="font-paragraph text-sm text-secondary italic">
                Your feedback has been submitted successfully.
              </p>
            </motion.div>
          </CardContent>
        ) : (
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Rating (1-10)
                </Label>
                {renderStars()}
              </div>

              <div className="space-y-2">
                <Label htmlFor="realLifeExamples" className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                  <BookOpen className="w-4 h-4" />
                  Real-life Examples
                </Label>
                <Textarea
                  id="realLifeExamples"
                  value={formData.realLifeExamples}
                  onChange={(e) => handleInputChange('realLifeExamples', e.target.value)}
                  placeholder="How does this content relate to real-world situations?"
                  className="border-subtleborder focus:border-primary font-paragraph"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="practicalKnowledge" className="font-heading text-sm text-primary uppercase tracking-wide flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Practical Knowledge
                </Label>
                <Textarea
                  id="practicalKnowledge"
                  value={formData.practicalKnowledge}
                  onChange={(e) => handleInputChange('practicalKnowledge', e.target.value)}
                  placeholder="What practical knowledge can be gained from this content?"
                  className="border-subtleborder focus:border-primary font-paragraph"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-heading text-sm text-primary uppercase tracking-wide">
                    Type
                  </Label>
                  <Select value={formData.feedbackType} onValueChange={(value) => handleInputChange('feedbackType', value)}>
                    <SelectTrigger className="border-subtleborder focus:border-primary">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="content-evaluation">Content Quality</SelectItem>
                      <SelectItem value="creator-assessment">Creator Assessment</SelectItem>
                      <SelectItem value="educational-value">Educational Value</SelectItem>
                      <SelectItem value="practical-application">Practical Application</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {!isAuthenticated && (
                  <div className="space-y-2">
                    <Label htmlFor="userName" className="font-heading text-sm text-primary uppercase tracking-wide">
                      Name
                    </Label>
                    <Input
                      id="userName"
                      value={formData.userName}
                      onChange={(e) => handleInputChange('userName', e.target.value)}
                      placeholder="Your name"
                      className="border-subtleborder focus:border-primary font-paragraph"
                    />
                  </div>
                )}
              </div>

              {!isAuthenticated && (
                <div className="space-y-2">
                  <Label htmlFor="userEmail" className="font-heading text-sm text-primary uppercase tracking-wide">
                    Email
                  </Label>
                  <Input
                    id="userEmail"
                    type="email"
                    value={formData.userEmail}
                    onChange={(e) => handleInputChange('userEmail', e.target.value)}
                    placeholder="your.email@example.com"
                    className={`border-subtleborder focus:border-primary font-paragraph ${emailError ? 'border-red-500 focus:border-red-500' : ''}`}
                  />
                  {emailError && (
                    <p className="text-sm text-red-600 font-paragraph">
                      {emailError}
                    </p>
                  )}
                </div>
              )}

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                    Submitting Evaluation...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Submit Evaluation
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        )}
      </Card>
    );
  }

  // Floating variant (default)
  return (
    <div className={`fixed bottom-6 right-6 z-50 ${className}`}>
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.2 }}
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full w-14 h-14 shadow-lg"
            >
              <MessageSquare className="w-6 h-6" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="w-80 border-subtleborder bg-background shadow-xl">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle className="font-heading text-base text-primary uppercase tracking-wide">
                    Evaluate {featureName}
                  </CardTitle>
                  <CardDescription className="font-paragraph text-xs text-secondary italic">
                    Help evaluate content quality
                  </CardDescription>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="h-8 w-8 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </CardHeader>
              
              {isSubmitted ? (
                <CardContent>
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-4 space-y-3"
                  >
                    <ThumbsUp className="w-8 h-8 text-green-600 mx-auto" />
                    <h3 className="font-heading text-sm text-green-600 uppercase">Thank You!</h3>
                    <p className="font-paragraph text-xs text-secondary italic">
                      Feedback submitted successfully.
                    </p>
                  </motion.div>
                </CardContent>
              ) : (
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-3">
                    <div className="space-y-1">
                      <Label className="font-heading text-xs text-primary uppercase tracking-wide">
                        Rating (1-10)
                      </Label>
                      {renderStars()}
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="realLifeExamples" className="font-heading text-xs text-primary uppercase tracking-wide">
                        Real-life Examples
                      </Label>
                      <Textarea
                        id="realLifeExamples"
                        value={formData.realLifeExamples}
                        onChange={(e) => handleInputChange('realLifeExamples', e.target.value)}
                        placeholder="How does this relate to real situations?"
                        className="border-subtleborder focus:border-primary font-paragraph text-sm"
                        rows={2}
                      />
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="practicalKnowledge" className="font-heading text-xs text-primary uppercase tracking-wide">
                        Practical Knowledge
                      </Label>
                      <Textarea
                        id="practicalKnowledge"
                        value={formData.practicalKnowledge}
                        onChange={(e) => handleInputChange('practicalKnowledge', e.target.value)}
                        placeholder="What practical knowledge is gained?"
                        className="border-subtleborder focus:border-primary font-paragraph text-sm"
                        rows={2}
                      />
                    </div>

                    <div className="space-y-1">
                      <Label className="font-heading text-xs text-primary uppercase tracking-wide">
                        Type
                      </Label>
                      <Select value={formData.feedbackType} onValueChange={(value) => handleInputChange('feedbackType', value)}>
                        <SelectTrigger className="border-subtleborder focus:border-primary h-8">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="content-evaluation">Content Quality</SelectItem>
                          <SelectItem value="creator-assessment">Creator Assessment</SelectItem>
                          <SelectItem value="educational-value">Educational Value</SelectItem>
                          <SelectItem value="practical-application">Practical Application</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {!isAuthenticated && (
                      <>
                        <div className="space-y-1">
                          <Label htmlFor="userName" className="font-heading text-xs text-primary uppercase tracking-wide">
                            Name
                          </Label>
                          <Input
                            id="userName"
                            value={formData.userName}
                            onChange={(e) => handleInputChange('userName', e.target.value)}
                            placeholder="Your name"
                            className="border-subtleborder focus:border-primary font-paragraph text-sm h-8"
                          />
                        </div>

                        <div className="space-y-1">
                          <Label htmlFor="userEmail" className="font-heading text-xs text-primary uppercase tracking-wide">
                            Email
                          </Label>
                          <Input
                            id="userEmail"
                            type="email"
                            value={formData.userEmail}
                            onChange={(e) => handleInputChange('userEmail', e.target.value)}
                            placeholder="your.email@example.com"
                            className={`border-subtleborder focus:border-primary font-paragraph text-sm h-8 ${emailError ? 'border-red-500 focus:border-red-500' : ''}`}
                          />
                          {emailError && (
                            <p className="text-xs text-red-600 font-paragraph">
                              {emailError}
                            </p>
                          )}
                        </div>
                      </>
                    )}

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      size="sm"
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-heading uppercase tracking-wide text-xs"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-3 h-3 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Send className="w-3 h-3 mr-2" />
                          Submit Evaluation
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}