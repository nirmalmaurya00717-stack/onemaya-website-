import { useState, useEffect } from 'react';
import { X, Star, Crown, Upload, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useMember } from '@/integrations';

interface LoginWelcomeBannerProps {
  className?: string;
}

export function LoginWelcomeBanner({ className = '' }: LoginWelcomeBannerProps) {
  const [isVisible, setIsVisible] = useState(false);
  const { member, isAuthenticated } = useMember();

  useEffect(() => {
    // Only show if user is authenticated
    if (!isAuthenticated || !member) {
      setIsVisible(false);
      return;
    }

    // Use member's login email as unique identifier
    const memberEmail = (member as any)?.loginEmail || 'anonymous';
    const storageKey = `welcome-banner-dismissed-${memberEmail}`;
    const bannerDismissed = localStorage.getItem(storageKey);

    if (!bannerDismissed) {
      // Show banner after a short delay for better UX
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1500);

      return () => clearTimeout(timer);
    }
  }, [isAuthenticated, member]);

  const handleDismiss = () => {
    setIsVisible(false);
    // Mark banner as dismissed permanently for this user
    if (member) {
      const memberEmail = (member as any)?.loginEmail || 'anonymous';
      const storageKey = `welcome-banner-dismissed-${memberEmail}`;
      localStorage.setItem(storageKey, 'true');
    }
  };

  const handleCTAClick = () => {
    handleDismiss(); // Auto-dismiss when user takes action
  };

  if (!isVisible || !isAuthenticated) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -50, scale: 0.95 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className={`fixed top-20 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-4xl px-4 ${className}`}
        >
          <Card className="bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 text-white border-0 shadow-2xl">
            <CardContent className="relative p-6">
              {/* Close button */}
              <button
                onClick={handleDismiss}
                className="absolute top-3 right-3 p-2 bg-white/20 rounded-full hover:bg-white/30 transition-all duration-200"
                aria-label="Close welcome banner"
              >
                <X className="w-4 h-4 text-white" />
              </button>

              {/* Content */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                {/* Left side - Message */}
                <div className="lg:col-span-8 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                      <Crown className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-heading text-lg sm:text-xl font-bold uppercase tracking-wide">
                        Welcome to OneMaya Creator Program!
                      </h3>
                      <div className="flex flex-wrap gap-1 mt-1">
                        <Badge className="bg-white/20 text-white border-white/30 text-xs">
                          Hostel Boys
                        </Badge>
                        <Badge className="bg-white/20 text-white border-white/30 text-xs">
                          Researchers
                        </Badge>
                        <Badge className="bg-white/20 text-white border-white/30 text-xs">
                          Knowledge Lovers
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <p className="font-paragraph text-sm sm:text-base leading-relaxed opacity-95">
                    <strong>OneMaya gives every hostel boy, researcher, and knowledge lover the power to publish and earn.</strong> Upload your book summaries, notes, or research — get{' '}
                    <span className="inline-flex items-center gap-1 bg-white/20 px-2 py-1 rounded">
                      4<Star className="w-3 h-3 fill-yellow-300 text-yellow-300" />
                    </span>
                    , 50 feedback and become a Paid Creator just at{' '}
                    <span className="font-heading text-lg font-bold bg-white/20 px-2 py-1 rounded">
                      ₹49/month!
                    </span>
                  </p>

                  {/* Features */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div className="flex items-center gap-2 bg-white/10 rounded-lg p-2">
                      <Upload className="w-4 h-4 text-white" />
                      <span>Upload Content</span>
                    </div>
                    <div className="flex items-center gap-2 bg-white/10 rounded-lg p-2">
                      <Star className="w-4 h-4 text-yellow-300" />
                      <span>Get 4⭐ Rating</span>
                    </div>
                    <div className="flex items-center gap-2 bg-white/10 rounded-lg p-2">
                      <Crown className="w-4 h-4 text-white" />
                      <span>Earn ₹49/month</span>
                    </div>
                  </div>
                </div>

                {/* Right side - CTA Buttons */}
                <div className="lg:col-span-4 space-y-3">
                  <Button 
                    asChild
                    className="w-full bg-white text-blue-600 hover:bg-blue-50 font-heading uppercase tracking-wide text-sm py-3"
                    onClick={handleCTAClick}
                  >
                    <Link to="/upload-video">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Content
                    </Link>
                  </Button>
                  
                  <Button 
                    asChild
                    variant="outline"
                    className="w-full border-white text-white hover:bg-white hover:text-blue-600 font-heading uppercase tracking-wide text-sm py-3"
                    onClick={handleCTAClick}
                  >
                    <Link to="/submit-content">
                      <FileText className="w-4 h-4 mr-2" />
                      Submit Research
                    </Link>
                  </Button>

                  <Button 
                    asChild
                    variant="ghost"
                    className="w-full text-white hover:bg-white/20 font-heading uppercase tracking-wide text-xs py-2"
                    onClick={handleCTAClick}
                  >
                    <Link to="/become-paid-creator">
                      <Crown className="w-3 h-3 mr-2" />
                      Learn More
                    </Link>
                  </Button>
                </div>
              </div>

              {/* Bottom accent */}
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-yellow-400 via-pink-400 to-green-400"></div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}