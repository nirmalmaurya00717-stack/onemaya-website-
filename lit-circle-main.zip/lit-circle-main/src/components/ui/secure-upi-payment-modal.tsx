import React, { useState } from 'react';
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Copy, CheckCircle, Smartphone, QrCode, Shield, Clock, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SecureUPIPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentSubmitted: () => void;
  planType: 'month1' | 'month2';
  amount: number;
}

const CORRECT_UPI_ID = 'nirmalmaurya00717-1@okicici';

export function SecureUPIPaymentModal({
  isOpen,
  onClose,
  onPaymentSubmitted,
  planType,
  amount
}: SecureUPIPaymentModalProps) {
  const [paymentStep, setPaymentStep] = useState<'payment' | 'verification' | 'pending' | 'error'>('payment');
  const [enteredUPIId, setEnteredUPIId] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const planName = planType === 'month1' ? 'Month 1 Plan' : 'Month 2 Plan';

  const copyUPIId = () => {
    navigator.clipboard.writeText(CORRECT_UPI_ID);
    toast({
      title: "UPI ID Copied!",
      description: "UPI ID has been copied to your clipboard.",
    });
  };

  const handlePaymentSubmit = async () => {
    // Validate UPI ID
    if (enteredUPIId.trim() !== CORRECT_UPI_ID) {
      toast({
        title: "Incorrect UPI ID",
        description: "Please enter the correct UPI ID that you paid to.",
        variant: "destructive",
      });
      return;
    }

    // Validate transaction ID
    if (!transactionId.trim()) {
      toast({
        title: "Transaction ID Required",
        description: "Please enter your transaction ID to verify the payment.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // Simulate verification process
    setTimeout(() => {
      setIsProcessing(false);
      setPaymentStep('pending');
      
      // Auto close after showing pending message
      setTimeout(() => {
        onPaymentSubmitted();
        onClose();
        toast({
          title: "Payment Submitted for Verification",
          description: "Your payment will be verified by our team. You'll be notified once approved.",
        });
      }, 3000);
    }, 2000);
  };

  const resetModal = () => {
    setPaymentStep('payment');
    setEnteredUPIId('');
    setTransactionId('');
    setIsProcessing(false);
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={handleClose}>
      <AlertDialogContent className="max-w-lg">
        {paymentStep === 'payment' && (
          <>
            <AlertDialogHeader>
              <AlertDialogTitle className="text-xl font-heading flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-600" />
                Secure UPI Payment
              </AlertDialogTitle>
              <AlertDialogDescription>
                Pay ₹{amount} for {planName} with enhanced security verification
              </AlertDialogDescription>
            </AlertDialogHeader>
            
            <div className="space-y-4">
              {/* Security Notice */}
              <Card className="border-2 border-amber-200 bg-amber-50">
                <CardContent className="pt-4">
                  <div className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-amber-600 mt-0.5" />
                    <div>
                      <h4 className="font-heading text-sm font-semibold text-amber-800 mb-1">
                        Enhanced Security Process
                      </h4>
                      <p className="font-paragraph text-xs text-amber-700">
                        Your subscription will be activated only after manual verification by our team to ensure security and prevent unauthorized access.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Details */}
              <Card className="border-2 border-primary">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-heading">Payment Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Plan:</span>
                    <Badge variant="default">{planName}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Duration:</span>
                    <span className="font-paragraph text-sm font-semibold">30 days</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-paragraph text-sm">Amount:</span>
                    <span className="font-heading text-lg font-bold text-primary">₹{amount}</span>
                  </div>
                </CardContent>
              </Card>

              {/* UPI Payment Instructions */}
              <Card className="border-2 border-green-200 bg-green-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-heading text-green-800 flex items-center gap-2">
                    <Smartphone className="h-5 w-5" />
                    Step 1: Make UPI Payment
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <Label className="font-paragraph text-sm text-green-700 mb-2 block">
                      Pay to this UPI ID:
                    </Label>
                    <div className="flex items-center gap-2">
                      <Input 
                        value={CORRECT_UPI_ID} 
                        readOnly 
                        className="font-mono text-sm bg-gray-50 border-green-300"
                      />
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={copyUPIId}
                        className="border-green-300 text-green-700 hover:bg-green-100"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <Label className="font-paragraph text-sm text-green-700 mb-2 block">
                      Amount to Pay:
                    </Label>
                    <div className="text-2xl font-heading font-bold text-green-800">
                      ₹{amount}
                    </div>
                  </div>

                  <div className="text-center space-y-2">
                    <div className="flex items-center justify-center gap-2 text-sm text-green-700">
                      <QrCode className="h-4 w-4" />
                      <span className="font-paragraph">Open your UPI app and pay to the above UPI ID</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Verification Form */}
              <Card className="border-2 border-blue-200 bg-blue-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-heading text-blue-800 flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Step 2: Verify Payment Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="upiId" className="font-paragraph text-sm font-medium text-blue-800">
                      UPI ID you paid to *
                    </Label>
                    <Input
                      id="upiId"
                      placeholder="Enter the UPI ID you sent money to"
                      value={enteredUPIId}
                      onChange={(e) => setEnteredUPIId(e.target.value)}
                      className="mt-2 border-blue-300"
                    />
                    <p className="font-paragraph text-xs text-blue-600 mt-1">
                      This must match exactly with the UPI ID shown above
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="transactionId" className="font-paragraph text-sm font-medium text-blue-800">
                      Transaction ID / Reference Number *
                    </Label>
                    <Input
                      id="transactionId"
                      placeholder="Enter transaction ID from your UPI app"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      className="mt-2 border-blue-300"
                    />
                    <p className="font-paragraph text-xs text-blue-600 mt-1">
                      Enter the transaction ID you received after making the UPI payment
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <AlertDialogFooter className="flex gap-2">
              <Button variant="outline" onClick={handleClose}>
                Cancel
              </Button>
              <Button 
                onClick={handlePaymentSubmit} 
                disabled={isProcessing || !enteredUPIId.trim() || !transactionId.trim()}
                className="flex-1"
              >
                {isProcessing ? 'Verifying...' : 'Submit for Verification'}
              </Button>
            </AlertDialogFooter>
          </>
        )}

        {paymentStep === 'pending' && (
          <>
            <AlertDialogHeader>
              <AlertDialogTitle className="text-xl font-heading flex items-center gap-2 text-blue-600">
                <Clock className="h-5 w-5" />
                Payment Under Review
              </AlertDialogTitle>
              <AlertDialogDescription>
                Your payment has been submitted for manual verification.
              </AlertDialogDescription>
            </AlertDialogHeader>
            
            <div className="space-y-4">
              <Card className="border-2 border-blue-200 bg-blue-50">
                <CardContent className="pt-6 text-center">
                  <Clock className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="font-heading text-lg text-blue-800 mb-2">
                    Verification in Progress
                  </h3>
                  <p className="font-paragraph text-sm text-blue-700 mb-4">
                    Our team will verify your payment details and activate your {planName} within 24 hours.
                  </p>
                  <div className="space-y-2 text-left bg-white p-3 rounded border border-blue-200">
                    <p className="font-paragraph text-xs text-blue-600">
                      <strong>UPI ID:</strong> {enteredUPIId}
                    </p>
                    <p className="font-paragraph text-xs text-blue-600">
                      <strong>Transaction ID:</strong> {transactionId}
                    </p>
                    <p className="font-paragraph text-xs text-blue-600">
                      <strong>Amount:</strong> ₹{amount}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-amber-200 bg-amber-50">
                <CardContent className="pt-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                    <div>
                      <h4 className="font-heading text-sm font-semibold text-amber-800 mb-1">
                        What happens next?
                      </h4>
                      <ul className="font-paragraph text-xs text-amber-700 space-y-1">
                        <li>• Our team will verify your payment within 24 hours</li>
                        <li>• You'll receive a notification once your subscription is activated</li>
                        <li>• If there are any issues, we'll contact you for clarification</li>
                        <li>• You can check your subscription status in your profile</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <AlertDialogFooter>
              <Button onClick={handleClose} className="w-full">
                Continue
              </Button>
            </AlertDialogFooter>
          </>
        )}
      </AlertDialogContent>
    </AlertDialog>
  );
}