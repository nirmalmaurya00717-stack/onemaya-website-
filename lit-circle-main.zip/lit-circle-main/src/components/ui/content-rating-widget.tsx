import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { FeedbackWidget } from '@/components/ui/feedback-widget';
import { Star, MessageCircle, TrendingUp, Award } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { useMember } from '@/integrations';
import { motion, AnimatePresence } from 'framer-motion';

interface ContentRating {
  _id: string;
  contentId: string;
  userId: string;
  rating: number;
  feedbackText?: string;
  submissionDate: string;
}

interface ContentRatingWidgetProps {
  contentId: string;
  contentTitle: string;
  currentRating?: number;
  ratingCount?: number;
  onRatingUpdate?: (newRating: number, newCount: number) => void;
}

export function ContentRatingWidget({ 
  contentId, 
  contentTitle, 
  currentRating = 0, 
  ratingCount = 0,
  onRatingUpdate 
}: ContentRatingWidgetProps) {
  const { member, isAuthenticated } = useMember();
  const [ratings, setRatings] = useState<ContentRating[]>([]);
  const [userRating, setUserRating] = useState<ContentRating | null>(null);
  const [newRating, setNewRating] = useState(0);
  const [newFeedback, setNewFeedback] = useState('');
  const [hoveredStar, setHoveredStar] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [showAllRatings, setShowAllRatings] = useState(false);

  useEffect(() => {
    loadRatings();
  }, [contentId]);

  const loadRatings = async () => {
    try {
      const { items } = await BaseCrudService.getAll<ContentRating>('contentratings');
      const contentRatings = items.filter(r => r.contentId === contentId);
      setRatings(contentRatings);

      // Check if current user has already rated
      if (member?.loginEmail) {
        const existingRating = contentRatings.find(r => r.userId === member.loginEmail);
        setUserRating(existingRating || null);
        if (existingRating) {
          setNewRating(existingRating.rating);
          setNewFeedback(existingRating.feedbackText || '');
        }
      }
    } catch (error) {
      console.error('Error loading ratings:', error);
    }
  };

  const handleStarClick = (rating: number) => {
    setNewRating(rating);
    setShowFeedbackForm(true);
  };

  const handleSubmitRating = async () => {
    if (!isAuthenticated || !member?.loginEmail || newRating === 0) return;

    setIsSubmitting(true);
    try {
      const ratingData: ContentRating = {
        _id: userRating?._id || crypto.randomUUID(),
        contentId,
        userId: member.loginEmail,
        rating: newRating,
        feedbackText: newFeedback.trim() || undefined,
        submissionDate: new Date().toISOString()
      };

      if (userRating) {
        // Update existing rating
        await BaseCrudService.update('contentratings', ratingData);
      } else {
        // Create new rating
        await BaseCrudService.create('contentratings', ratingData);
      }

      // Reload ratings and update parent component
      await loadRatings();
      
      // Calculate new average
      const { items } = await BaseCrudService.getAll<ContentRating>('contentratings');
      const contentRatings = items.filter(r => r.contentId === contentId);
      const avgRating = contentRatings.length > 0 
        ? contentRatings.reduce((sum, r) => sum + r.rating, 0) / contentRatings.length 
        : 0;

      // Update the content submission with new rating data
      await BaseCrudService.update('userbooksubmissions', {
        _id: contentId,
        averageRating: avgRating,
        ratingCount: contentRatings.length
      });

      if (onRatingUpdate) {
        onRatingUpdate(avgRating, contentRatings.length);
      }

      setShowFeedbackForm(false);
      
      // Check for Paid Creator eligibility based on new evaluation criteria
      const qualityEvaluations = contentRatings.filter(r => r.rating >= 7); // 7+ out of 10 rating
      if (avgRating >= 7.0 && qualityEvaluations.length >= 25) {
        // Show AI suggestion for Paid Creator upgrade
        setTimeout(() => {
          alert('🎉 Congratulations! Your content has achieved 7+ rating with 25+ quality evaluations. You\'re now eligible for Paid Creator upgrade!');
        }, 1000);
      }

    } catch (error) {
      console.error('Error submitting rating:', error);
      alert('Failed to submit rating. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStars = (rating: number, interactive = false, size = 'w-5 h-5') => {
    return Array.from({ length: 10 }, (_, i) => {
      const starValue = i + 1;
      const isFilled = interactive 
        ? (hoveredStar > 0 ? starValue <= hoveredStar : starValue <= newRating)
        : starValue <= rating;

      return (
        <Star
          key={i}
          className={`${size} cursor-pointer transition-colors ${
            isFilled ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'
          } ${interactive ? 'hover:text-yellow-400' : ''}`}
          onClick={interactive ? () => handleStarClick(starValue) : undefined}
          onMouseEnter={interactive ? () => setHoveredStar(starValue) : undefined}
          onMouseLeave={interactive ? () => setHoveredStar(0) : undefined}
        />
      );
    });
  };

  const averageRating = ratings.length > 0 
    ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length 
    : currentRating;

  const displayRatings = showAllRatings ? ratings : ratings.slice(0, 3);

  return (
    <>
      <Card className="border-subtleborder">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="font-heading text-lg flex items-center space-x-2">
                <Star className="w-5 h-5 text-yellow-500" />
                <span>Ratings & Feedback</span>
              </CardTitle>
              <CardDescription>Community feedback for "{contentTitle}"</CardDescription>
            </div>
            
            {/* Overall Rating Display */}
            <div className="text-center">
              <div className="flex items-center space-x-1 mb-1">
                {renderStars(averageRating)}
              </div>
              <div className="text-sm text-secondary">
                {averageRating.toFixed(1)}/10 ({ratings.length} evaluation{ratings.length !== 1 ? 's' : ''})
              </div>
            </div>
          </div>

          {/* AI Eligibility Banner */}
          {averageRating >= 7.0 && ratings.filter(r => r.rating >= 7).length >= 25 && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg"
            >
              <div className="flex items-center space-x-2">
                <Award className="w-5 h-5 text-green-600" />
                <span className="text-sm font-medium text-green-800">
                  🎉 Eligible for Paid Creator upgrade! This content meets the 7+ rating with 25+ quality evaluations criteria.
                </span>
              </div>
            </motion.div>
          )}
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Rating Form */}
          {isAuthenticated ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-heading text-sm uppercase tracking-wide">
                  {userRating ? 'Update Your Rating' : 'Rate This Content'}
                </h4>
                {userRating && (
                  <Badge variant="outline">You rated: {userRating.rating}/10</Badge>
                )}
              </div>
              
              <div className="flex items-center space-x-2">
                {renderStars(newRating, true)}
                <span className="text-sm text-secondary ml-2">
                  {newRating > 0 ? `${newRating}/10` : 'Click to rate (1-10)'}
                </span>
              </div>

              <AnimatePresence>
                {showFeedbackForm && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-3"
                  >
                    <Textarea
                      value={newFeedback}
                      onChange={(e) => setNewFeedback(e.target.value)}
                      placeholder="Please provide detailed feedback including real-life examples and practical knowledge gained from this content..."
                      rows={4}
                      className="border-subtleborder focus:border-primary"
                    />
                    <div className="flex space-x-2">
                      <Button 
                        onClick={handleSubmitRating}
                        disabled={isSubmitting || newRating === 0}
                        size="sm"
                      >
                        {isSubmitting ? 'Submitting...' : (userRating ? 'Update Rating' : 'Submit Rating')}
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => setShowFeedbackForm(false)}
                        size="sm"
                      >
                        Cancel
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-secondary">Sign in to evaluate and provide detailed feedback</p>
            </div>
          )}

          {/* Existing Ratings */}
          {ratings.length > 0 && (
            <>
              <Separator />
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-heading text-sm uppercase tracking-wide">Content Evaluations</h4>
                  {ratings.length > 3 && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setShowAllRatings(!showAllRatings)}
                    >
                      {showAllRatings ? 'Show Less' : `Show All ${ratings.length}`}
                    </Button>
                  )}
                </div>

                <div className="space-y-3">
                  {displayRatings.map((rating) => (
                    <motion.div
                      key={rating._id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {renderStars(rating.rating, false, 'w-4 h-4')}
                          <span className="text-sm font-medium">
                            {rating.userId.split('@')[0]}
                          </span>
                        </div>
                        <span className="text-xs text-secondary">
                          {new Date(rating.submissionDate).toLocaleDateString()}
                        </span>
                      </div>
                      {rating.feedbackText && (
                        <p className="text-sm text-secondary italic">"{rating.feedbackText}"</p>
                      )}
                    </motion.div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Rating Statistics */}
          {ratings.length > 0 && (
            <>
              <Separator />
              <div className="grid grid-cols-10 gap-1 text-center">
                {[10, 9, 8, 7, 6, 5, 4, 3, 2, 1].map((rating) => {
                  const count = ratings.filter(r => r.rating === rating).length;
                  const percentage = ratings.length > 0 ? (count / ratings.length) * 100 : 0;
                  
                  return (
                    <div key={rating} className="space-y-1">
                      <div className="text-xs font-medium">{rating}</div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-yellow-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <div className="text-xs text-secondary">{count}</div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Enhanced Content Evaluation Widget */}
      <FeedbackWidget featureName={`${contentTitle} Content`} variant="floating" />
    </>
  );
}