import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Supported languages - 9 most spoken languages
export const LANGUAGES = {
  en: { code: 'en', name: 'English', nativeName: 'English' },
  zh: { code: 'zh', name: 'Chinese', nativeName: '中文' },
  hi: { code: 'hi', name: 'Hindi', nativeName: 'हिंदी' },
  es: { code: 'es', name: 'Spanish', nativeName: 'Español' },
  ar: { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
  bn: { code: 'bn', name: 'Bengali', nativeName: 'বাংলা' },
  pt: { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
  ru: { code: 'ru', name: 'Russian', nativeName: 'Русский' },
  fr: { code: 'fr', name: 'French', nativeName: 'Français' },
} as const;

export type LanguageCode = keyof typeof LANGUAGES;

// Language store
interface LanguageStore {
  currentLanguage: LanguageCode;
  setLanguage: (language: LanguageCode) => void;
}

export const useLanguageStore = create<LanguageStore>()(
  persist(
    (set) => ({
      currentLanguage: 'en',
      setLanguage: (language: LanguageCode) => set({ currentLanguage: language }),
    }),
    {
      name: 'language-preference',
    }
  )
);

// Translation type
export type TranslationKey = string;
export type Translations = Record<string, string | Record<string, string>>;

// Get nested translation value
export function getTranslation(translations: Translations, key: string): string {
  const keys = key.split('.');
  let value: any = translations;
  
  for (const k of keys) {
    if (value && typeof value === 'object' && k in value) {
      value = value[k];
    } else {
      return key; // Return key if translation not found
    }
  }
  
  return typeof value === 'string' ? value : key;
}

// Translation hook
export function useTranslation() {
  const { currentLanguage } = useLanguageStore();
  
  const t = (key: string): string => {
    const translations = getTranslations(currentLanguage);
    return getTranslation(translations, key);
  };
  
  return { t, currentLanguage };
}

// Get translations for a specific language
export function getTranslations(language: LanguageCode): Translations {
  return translations[language] || translations.en;
}

// Translation data
const translations: Record<LanguageCode, Translations> = {
  en: {
    // Navigation
    nav: {
      home: 'Home',
      discussions: 'Discussions',
      library: 'Library',
      help: 'Help',
      askAI: 'Ask AI',
      createGroup: 'Create Group',
      scheduleSession: 'Schedule Session',
      submitContent: 'Submit Content',
      uploadVideo: 'Upload Video',
    },
    
    // Common
    common: {
      loading: 'Loading...',
      error: 'Error',
      success: 'Success',
      cancel: 'Cancel',
      save: 'Save',
      delete: 'Delete',
      edit: 'Edit',
      view: 'View',
      back: 'Back',
      next: 'Next',
      previous: 'Previous',
      search: 'Search',
      filter: 'Filter',
      sort: 'Sort',
      language: 'Language',
    },
    
    // Home page
    home: {
      title: 'Welcome to GyaanWave',
      subtitle: 'Connect with fellow book lovers and engage in meaningful discussions',
      featuredGroups: 'Featured Reading Groups',
      popularBooks: 'Popular Books',
      recentDiscussions: 'Recent Discussions',
      joinCommunity: 'Join Our Community',
      startReading: 'Start Reading Together',
    },
    
    // Groups
    groups: {
      title: 'Reading Groups',
      create: 'Create New Group',
      join: 'Join Group',
      leave: 'Leave Group',
      members: 'Members',
      currentBook: 'Current Book',
      description: 'Description',
      public: 'Public Group',
      private: 'Private Group',
    },
    
    // Discussions
    discussions: {
      title: 'Discussions',
      newTopic: 'New Topic',
      reply: 'Reply',
      views: 'Views',
      replies: 'Replies',
      lastActivity: 'Last Activity',
      pinned: 'Pinned',
    },
    
    // Library
    library: {
      title: 'Library',
      books: 'Books',
      videos: 'Videos',
      sessions: 'Sessions',
      submissions: 'Submissions',
      rating: 'Rating',
      author: 'Author',
      genre: 'Genre',
      year: 'Publication Year',
    },
    
    // Forms
    forms: {
      title: 'Title',
      content: 'Content',
      description: 'Description',
      submit: 'Submit',
      required: 'Required field',
      optional: 'Optional',
    },
    
    // AI
    ai: {
      title: 'Ask AI Assistant',
      placeholder: 'Ask me anything about books, literature, or discussions...',
      send: 'Send',
      thinking: 'AI is thinking...',
    },
    
    // Help
    help: {
      title: 'Help & Support',
      faq: 'Frequently Asked Questions',
      contact: 'Contact Us',
      guides: 'User Guides',
    },
  },
  
  hi: {
    nav: {
      home: 'होम',
      discussions: 'चर्चा',
      library: 'पुस्तकालय',
      help: 'सहायता',
      askAI: 'AI से पूछें',
      createGroup: 'समूह बनाएं',
      scheduleSession: 'सत्र निर्धारित करें',
      submitContent: 'सामग्री जमा करें',
      uploadVideo: 'वीडियो अपलोड करें',
    },
    
    common: {
      loading: 'लोड हो रहा है...',
      error: 'त्रुटि',
      success: 'सफलता',
      cancel: 'रद्द करें',
      save: 'सहेजें',
      delete: 'हटाएं',
      edit: 'संपादित करें',
      view: 'देखें',
      back: 'वापस',
      next: 'अगला',
      previous: 'पिछला',
      search: 'खोजें',
      filter: 'फ़िल्टर',
      sort: 'क्रमबद्ध करें',
      language: 'भाषा',
    },
    
    home: {
      title: 'ज्ञान वेव में आपका स्वागत है',
      subtitle: 'साथी पुस्तक प्रेमियों से जुड़ें और सार्थक चर्चा में भाग लें',
      featuredGroups: 'विशेष पठन समूह',
      popularBooks: 'लोकप्रिय पुस्तकें',
      recentDiscussions: 'हाल की चर्चाएं',
      joinCommunity: 'हमारे समुदाय में शामिल हों',
      startReading: 'एक साथ पढ़ना शुरू करें',
    },
    
    groups: {
      title: 'पठन समूह',
      create: 'नया समूह बनाएं',
      join: 'समूह में शामिल हों',
      leave: 'समूह छोड़ें',
      members: 'सदस्य',
      currentBook: 'वर्तमान पुस्तक',
      description: 'विवरण',
      public: 'सार्वजनिक समूह',
      private: 'निजी समूह',
    },
    
    discussions: {
      title: 'चर्चाएं',
      newTopic: 'नया विषय',
      reply: 'उत्तर दें',
      views: 'दृश्य',
      replies: 'उत्तर',
      lastActivity: 'अंतिम गतिविधि',
      pinned: 'पिन किया गया',
    },
    
    library: {
      title: 'पुस्तकालय',
      books: 'पुस्तकें',
      videos: 'वीडियो',
      sessions: 'सत्र',
      submissions: 'प्रस्तुतियां',
      rating: 'रेटिंग',
      author: 'लेखक',
      genre: 'शैली',
      year: 'प्रकाशन वर्ष',
    },
    
    forms: {
      title: 'शीर्षक',
      content: 'सामग्री',
      description: 'विवरण',
      submit: 'जमा करें',
      required: 'आवश्यक फ़ील्ड',
      optional: 'वैकल्पिक',
    },
    
    ai: {
      title: 'AI सहायक से पूछें',
      placeholder: 'पुस्तकों, साहित्य या चर्चा के बारे में कुछ भी पूछें...',
      send: 'भेजें',
      thinking: 'AI सोच रहा है...',
    },
    
    help: {
      title: 'सहायता और समर्थन',
      faq: 'अक्सर पूछे जाने वाले प्रश्न',
      contact: 'संपर्क करें',
      guides: 'उपयोगकर्ता गाइड',
    },
  },
  
  // Placeholder translations for other languages
  zh: {
    nav: {
      home: '首页',
      discussions: '讨论',
      library: '图书馆',
      help: '帮助',
      askAI: '询问AI',
      createGroup: '创建群组',
      scheduleSession: '安排会话',
      submitContent: '提交内容',
      uploadVideo: '上传视频',
    },
    common: {
      loading: '加载中...',
      error: '错误',
      success: '成功',
      cancel: '取消',
      save: '保存',
      delete: '删除',
      edit: '编辑',
      view: '查看',
      back: '返回',
      next: '下一个',
      previous: '上一个',
      search: '搜索',
      filter: '筛选',
      sort: '排序',
      language: '语言',
    },
    home: {
      title: '欢迎来到知识波浪',
      subtitle: '与书友联系，参与有意义的讨论',
      featuredGroups: '精选阅读群组',
      popularBooks: '热门图书',
      recentDiscussions: '最近讨论',
      joinCommunity: '加入我们的社区',
      startReading: '开始一起阅读',
    },
    groups: { title: '阅读群组', create: '创建新群组', join: '加入群组', leave: '离开群组', members: '成员', currentBook: '当前图书', description: '描述', public: '公开群组', private: '私人群组' },
    discussions: { title: '讨论', newTopic: '新话题', reply: '回复', views: '浏览', replies: '回复', lastActivity: '最后活动', pinned: '置顶' },
    library: { title: '图书馆', books: '图书', videos: '视频', sessions: '会话', submissions: '提交', rating: '评分', author: '作者', genre: '类型', year: '出版年份' },
    forms: { title: '标题', content: '内容', description: '描述', submit: '提交', required: '必填字段', optional: '可选' },
    ai: { title: '询问AI助手', placeholder: '询问关于图书、文学或讨论的任何问题...', send: '发送', thinking: 'AI正在思考...' },
    help: { title: '帮助与支持', faq: '常见问题', contact: '联系我们', guides: '用户指南' },
  },
  
  es: {
    nav: { home: 'Inicio', discussions: 'Discusiones', library: 'Biblioteca', help: 'Ayuda', askAI: 'Preguntar a IA', createGroup: 'Crear Grupo', scheduleSession: 'Programar Sesión', submitContent: 'Enviar Contenido', uploadVideo: 'Subir Video' },
    common: { loading: 'Cargando...', error: 'Error', success: 'Éxito', cancel: 'Cancelar', save: 'Guardar', delete: 'Eliminar', edit: 'Editar', view: 'Ver', back: 'Atrás', next: 'Siguiente', previous: 'Anterior', search: 'Buscar', filter: 'Filtrar', sort: 'Ordenar', language: 'Idioma' },
    home: { title: 'Bienvenido a GyaanWave', subtitle: 'Conecta con otros amantes de los libros y participa en discusiones significativas', featuredGroups: 'Grupos de Lectura Destacados', popularBooks: 'Libros Populares', recentDiscussions: 'Discusiones Recientes', joinCommunity: 'Únete a Nuestra Comunidad', startReading: 'Comienza a Leer Juntos' },
    groups: { title: 'Grupos de Lectura', create: 'Crear Nuevo Grupo', join: 'Unirse al Grupo', leave: 'Dejar Grupo', members: 'Miembros', currentBook: 'Libro Actual', description: 'Descripción', public: 'Grupo Público', private: 'Grupo Privado' },
    discussions: { title: 'Discusiones', newTopic: 'Nuevo Tema', reply: 'Responder', views: 'Vistas', replies: 'Respuestas', lastActivity: 'Última Actividad', pinned: 'Fijado' },
    library: { title: 'Biblioteca', books: 'Libros', videos: 'Videos', sessions: 'Sesiones', submissions: 'Envíos', rating: 'Calificación', author: 'Autor', genre: 'Género', year: 'Año de Publicación' },
    forms: { title: 'Título', content: 'Contenido', description: 'Descripción', submit: 'Enviar', required: 'Campo requerido', optional: 'Opcional' },
    ai: { title: 'Preguntar al Asistente IA', placeholder: 'Pregunta cualquier cosa sobre libros, literatura o discusiones...', send: 'Enviar', thinking: 'IA está pensando...' },
    help: { title: 'Ayuda y Soporte', faq: 'Preguntas Frecuentes', contact: 'Contáctanos', guides: 'Guías de Usuario' },
  },
  
  ar: {
    nav: { home: 'الرئيسية', discussions: 'المناقشات', library: 'المكتبة', help: 'المساعدة', askAI: 'اسأل الذكي', createGroup: 'إنشاء مجموعة', scheduleSession: 'جدولة جلسة', submitContent: 'إرسال محتوى', uploadVideo: 'رفع فيديو' },
    common: { loading: 'جاري التحميل...', error: 'خطأ', success: 'نجح', cancel: 'إلغاء', save: 'حفظ', delete: 'حذف', edit: 'تحرير', view: 'عرض', back: 'رجوع', next: 'التالي', previous: 'السابق', search: 'بحث', filter: 'تصفية', sort: 'ترتيب', language: 'اللغة' },
    home: { title: 'مرحباً بك في موجة المعرفة', subtitle: 'تواصل مع محبي الكتب الآخرين وشارك في مناقشات مفيدة', featuredGroups: 'مجموعات القراءة المميزة', popularBooks: 'الكتب الشائعة', recentDiscussions: 'المناقشات الأخيرة', joinCommunity: 'انضم إلى مجتمعنا', startReading: 'ابدأ القراءة معاً' },
    groups: { title: 'مجموعات القراءة', create: 'إنشاء مجموعة جديدة', join: 'انضم للمجموعة', leave: 'ترك المجموعة', members: 'الأعضاء', currentBook: 'الكتاب الحالي', description: 'الوصف', public: 'مجموعة عامة', private: 'مجموعة خاصة' },
    discussions: { title: 'المناقشات', newTopic: 'موضوع جديد', reply: 'رد', views: 'المشاهدات', replies: 'الردود', lastActivity: 'آخر نشاط', pinned: 'مثبت' },
    library: { title: 'المكتبة', books: 'الكتب', videos: 'الفيديوهات', sessions: 'الجلسات', submissions: 'المساهمات', rating: 'التقييم', author: 'المؤلف', genre: 'النوع', year: 'سنة النشر' },
    forms: { title: 'العنوان', content: 'المحتوى', description: 'الوصف', submit: 'إرسال', required: 'حقل مطلوب', optional: 'اختياري' },
    ai: { title: 'اسأل المساعد الذكي', placeholder: 'اسأل أي شيء عن الكتب أو الأدب أو المناقشات...', send: 'إرسال', thinking: 'الذكي الاصطناعي يفكر...' },
    help: { title: 'المساعدة والدعم', faq: 'الأسئلة الشائعة', contact: 'اتصل بنا', guides: 'أدلة المستخدم' },
  },
  
  bn: {
    nav: { home: 'হোম', discussions: 'আলোচনা', library: 'লাইব্রেরি', help: 'সাহায্য', askAI: 'AI কে জিজ্ঞাসা করুন', createGroup: 'গ্রুপ তৈরি করুন', scheduleSession: 'সেশন নির্ধারণ করুন', submitContent: 'কন্টেন্ট জমা দিন', uploadVideo: 'ভিডিও আপলোড করুন' },
    common: { loading: 'লোড হচ্ছে...', error: 'ত্রুটি', success: 'সফল', cancel: 'বাতিল', save: 'সংরক্ষণ', delete: 'মুছুন', edit: 'সম্পাদনা', view: 'দেখুন', back: 'পিছনে', next: 'পরবর্তী', previous: 'পূর্ববর্তী', search: 'অনুসন্ধান', filter: 'ফিল্টার', sort: 'সাজান', language: 'ভাষা' },
    home: { title: 'GyaanWave-এ স্বাগতম', subtitle: 'সহযোগী বই প্রেমীদের সাথে সংযুক্ত হন এবং অর্থপূর্ণ আলোচনায় অংশগ্রহণ করুন', featuredGroups: 'বিশেষ পাঠ গ্রুপ', popularBooks: 'জনপ্রিয় বই', recentDiscussions: 'সাম্প্রতিক আলোচনা', joinCommunity: 'আমাদের সম্প্রদায়ে যোগ দিন', startReading: 'একসাথে পড়া শুরু করুন' },
    groups: { title: 'পাঠ গ্রুপ', create: 'নতুন গ্রুপ তৈরি করুন', join: 'গ্রুপে যোগ দিন', leave: 'গ্রুপ ছাড়ুন', members: 'সদস্য', currentBook: 'বর্তমান বই', description: 'বিবরণ', public: 'পাবলিক গ্রুপ', private: 'প্রাইভেট গ্রুপ' },
    discussions: { title: 'আলোচনা', newTopic: 'নতুন বিষয়', reply: 'উত্তর', views: 'দেখা', replies: 'উত্তর', lastActivity: 'শেষ কার্যকলাপ', pinned: 'পিন করা' },
    library: { title: 'লাইব্রেরি', books: 'বই', videos: 'ভিডিও', sessions: 'সেশন', submissions: 'জমা', rating: 'রেটিং', author: 'লেখক', genre: 'ধরন', year: 'প্রকাশের বছর' },
    forms: { title: 'শিরোনাম', content: 'বিষয়বস্তু', description: 'বিবরণ', submit: 'জমা দিন', required: 'প্রয়োজনীয় ক্ষেত্র', optional: 'ঐচ্ছিক' },
    ai: { title: 'AI সহায়ককে জিজ্ঞাসা করুন', placeholder: 'বই, সাহিত্য বা আলোচনা সম্পর্কে যেকোনো কিছু জিজ্ঞাসা করুন...', send: 'পাঠান', thinking: 'AI চিন্তা করছে...' },
    help: { title: 'সাহায্য ও সহায়তা', faq: 'প্রায়শই জিজ্ঞাসিত প্রশ্ন', contact: 'যোগাযোগ করুন', guides: 'ব্যবহারকারী গাইড' },
  },
  
  pt: {
    nav: { home: 'Início', discussions: 'Discussões', library: 'Biblioteca', help: 'Ajuda', askAI: 'Perguntar à IA', createGroup: 'Criar Grupo', scheduleSession: 'Agendar Sessão', submitContent: 'Enviar Conteúdo', uploadVideo: 'Carregar Vídeo' },
    common: { loading: 'Carregando...', error: 'Erro', success: 'Sucesso', cancel: 'Cancelar', save: 'Salvar', delete: 'Excluir', edit: 'Editar', view: 'Ver', back: 'Voltar', next: 'Próximo', previous: 'Anterior', search: 'Pesquisar', filter: 'Filtrar', sort: 'Ordenar', language: 'Idioma' },
    home: { title: 'Bem-vindo ao GyaanWave', subtitle: 'Conecte-se com outros amantes de livros e participe de discussões significativas', featuredGroups: 'Grupos de Leitura em Destaque', popularBooks: 'Livros Populares', recentDiscussions: 'Discussões Recentes', joinCommunity: 'Junte-se à Nossa Comunidade', startReading: 'Comece a Ler Juntos' },
    groups: { title: 'Grupos de Leitura', create: 'Criar Novo Grupo', join: 'Entrar no Grupo', leave: 'Sair do Grupo', members: 'Membros', currentBook: 'Livro Atual', description: 'Descrição', public: 'Grupo Público', private: 'Grupo Privado' },
    discussions: { title: 'Discussões', newTopic: 'Novo Tópico', reply: 'Responder', views: 'Visualizações', replies: 'Respostas', lastActivity: 'Última Atividade', pinned: 'Fixado' },
    library: { title: 'Biblioteca', books: 'Livros', videos: 'Vídeos', sessions: 'Sessões', submissions: 'Submissões', rating: 'Avaliação', author: 'Autor', genre: 'Gênero', year: 'Ano de Publicação' },
    forms: { title: 'Título', content: 'Conteúdo', description: 'Descrição', submit: 'Enviar', required: 'Campo obrigatório', optional: 'Opcional' },
    ai: { title: 'Perguntar ao Assistente IA', placeholder: 'Pergunte qualquer coisa sobre livros, literatura ou discussões...', send: 'Enviar', thinking: 'IA está pensando...' },
    help: { title: 'Ajuda e Suporte', faq: 'Perguntas Frequentes', contact: 'Entre em Contato', guides: 'Guias do Usuário' },
  },
  
  ru: {
    nav: { home: 'Главная', discussions: 'Обсуждения', library: 'Библиотека', help: 'Помощь', askAI: 'Спросить ИИ', createGroup: 'Создать Группу', scheduleSession: 'Запланировать Сессию', submitContent: 'Отправить Контент', uploadVideo: 'Загрузить Видео' },
    common: { loading: 'Загрузка...', error: 'Ошибка', success: 'Успех', cancel: 'Отмена', save: 'Сохранить', delete: 'Удалить', edit: 'Редактировать', view: 'Просмотр', back: 'Назад', next: 'Далее', previous: 'Предыдущий', search: 'Поиск', filter: 'Фильтр', sort: 'Сортировка', language: 'Язык' },
    home: { title: 'Добро пожаловать в GyaanWave', subtitle: 'Общайтесь с другими любителями книг и участвуйте в содержательных дискуссиях', featuredGroups: 'Рекомендуемые группы чтения', popularBooks: 'Популярные книги', recentDiscussions: 'Недавние обсуждения', joinCommunity: 'Присоединяйтесь к нашему сообществу', startReading: 'Начните читать вместе' },
    groups: { title: 'Группы чтения', create: 'Создать новую группу', join: 'Присоединиться к группе', leave: 'Покинуть группу', members: 'Участники', currentBook: 'Текущая книга', description: 'Описание', public: 'Публичная группа', private: 'Частная группа' },
    discussions: { title: 'Обсуждения', newTopic: 'Новая тема', reply: 'Ответить', views: 'Просмотры', replies: 'Ответы', lastActivity: 'Последняя активность', pinned: 'Закреплено' },
    library: { title: 'Библиотека', books: 'Книги', videos: 'Видео', sessions: 'Сессии', submissions: 'Материалы', rating: 'Рейтинг', author: 'Автор', genre: 'Жанр', year: 'Год публикации' },
    forms: { title: 'Заголовок', content: 'Содержание', description: 'Описание', submit: 'Отправить', required: 'Обязательное поле', optional: 'Необязательно' },
    ai: { title: 'Спросить ИИ-помощника', placeholder: 'Спросите что-нибудь о книгах, литературе или обсуждениях...', send: 'Отправить', thinking: 'ИИ думает...' },
    help: { title: 'Помощь и поддержка', faq: 'Часто задаваемые вопросы', contact: 'Связаться с нами', guides: 'Руководства пользователя' },
  },
  
  fr: {
    nav: { home: 'Accueil', discussions: 'Discussions', library: 'Bibliothèque', help: 'Aide', askAI: 'Demander à l\'IA', createGroup: 'Créer un Groupe', scheduleSession: 'Programmer une Session', submitContent: 'Soumettre du Contenu', uploadVideo: 'Télécharger une Vidéo' },
    common: { loading: 'Chargement...', error: 'Erreur', success: 'Succès', cancel: 'Annuler', save: 'Sauvegarder', delete: 'Supprimer', edit: 'Modifier', view: 'Voir', back: 'Retour', next: 'Suivant', previous: 'Précédent', search: 'Rechercher', filter: 'Filtrer', sort: 'Trier', language: 'Langue' },
    home: { title: 'Bienvenue sur Gyaan Wave', subtitle: 'Connectez-vous avec d\'autres amoureux des livres et participez à des discussions significatives', featuredGroups: 'Groupes de Lecture en Vedette', popularBooks: 'Livres Populaires', recentDiscussions: 'Discussions Récentes', joinCommunity: 'Rejoignez Notre Communauté', startReading: 'Commencez à Lire Ensemble' },
    groups: { title: 'Groupes de Lecture', create: 'Créer un Nouveau Groupe', join: 'Rejoindre le Groupe', leave: 'Quitter le Groupe', members: 'Membres', currentBook: 'Livre Actuel', description: 'Description', public: 'Groupe Public', private: 'Groupe Privé' },
    discussions: { title: 'Discussions', newTopic: 'Nouveau Sujet', reply: 'Répondre', views: 'Vues', replies: 'Réponses', lastActivity: 'Dernière Activité', pinned: 'Épinglé' },
    library: { title: 'Bibliothèque', books: 'Livres', videos: 'Vidéos', sessions: 'Sessions', submissions: 'Soumissions', rating: 'Évaluation', author: 'Auteur', genre: 'Genre', year: 'Année de Publication' },
    forms: { title: 'Titre', content: 'Contenu', description: 'Description', submit: 'Soumettre', required: 'Champ requis', optional: 'Optionnel' },
    ai: { title: 'Demander à l\'Assistant IA', placeholder: 'Demandez n\'importe quoi sur les livres, la littérature ou les discussions...', send: 'Envoyer', thinking: 'L\'IA réfléchit...' },
    help: { title: 'Aide et Support', faq: 'Questions Fréquemment Posées', contact: 'Nous Contacter', guides: 'Guides Utilisateur' },
  },
};