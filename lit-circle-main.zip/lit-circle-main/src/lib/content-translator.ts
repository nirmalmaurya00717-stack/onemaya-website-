import { LanguageCode } from './i18n';

// Translation cache to avoid repeated API calls
const translationCache = new Map<string, string>();

// Create a cache key for translations
function createCacheKey(text: string, targetLang: LanguageCode): string {
  return `${text}|||${targetLang}`;
}

// Mock translation function - in a real app, this would call a translation API
async function translateText(text: string, targetLang: LanguageCode): Promise<string> {
  // Return original text if target language is English or text is empty
  if (targetLang === 'en' || !text || text.trim() === '') {
    return text;
  }

  const cacheKey = createCacheKey(text, targetLang);
  
  // Check cache first
  if (translationCache.has(cacheKey)) {
    return translationCache.get(cacheKey)!;
  }

  // Mock translation mappings for demonstration
  // In a real implementation, you would use Google Translate API, Azure Translator, etc.
  const mockTranslations: Record<LanguageCode, Record<string, string>> = {
    en: {}, // English doesn't need translations - return original text
    hi: {
      'To Kill a Mockingbird': 'टू किल अ मॉकिंगबर्ड',
      'Harper Lee': 'हार्पर ली',
      'A gripping tale of racial injustice and childhood innocence in the American South.': 'अमेरिकी दक्षिण में नस्लीय अन्याय और बचपन की मासूमियत की एक मार्मिक कहानी।',
      'Fiction': 'कथा साहित्य',
      'Classic Literature': 'क्लासिक साहित्य',
      'The Great Gatsby': 'द ग्रेट गैट्सबी',
      'F. Scott Fitzgerald': 'एफ. स्कॉट फिट्जगेराल्ड',
      'A classic American novel about the Jazz Age and the American Dream.': 'जैज़ युग और अमेरिकी सपने के बारे में एक क्लासिक अमेरिकी उपन्यास।',
      'Pride and Prejudice': 'प्राइड एंड प्रेजुडिस',
      'Jane Austen': 'जेन ऑस्टेन',
      'A romantic novel about manners, upbringing, morality, and marriage.': 'शिष्टाचार, पालन-पोषण, नैतिकता और विवाह के बारे में एक रोमांटिक उपन्यास।',
      'Romance': 'रोमांस',
      'Book Club Discussions': 'पुस्तक क्लब चर्चा',
      'Literary Analysis': 'साहित्यिक विश्लेषण',
      'Reading Group': 'पठन समूह',
      'Book Summary': 'पुस्तक सारांश',
      'Chapter Review': 'अध्याय समीक्षा',
      'Discussion Topic': 'चर्चा विषय',
      'Book Review': 'पुस्तक समीक्षा',
      'Audio': 'ऑडियो',
      'Video': 'वीडियो',
      'Text': 'पाठ',
      'Image': 'छवि'
    },
    zh: {
      'To Kill a Mockingbird': '杀死一只知更鸟',
      'Harper Lee': '哈珀·李',
      'A gripping tale of racial injustice and childhood innocence in the American South.': '一个关于美国南部种族不公和童年纯真的扣人心弦的故事。',
      'Fiction': '小说',
      'Classic Literature': '经典文学',
      'The Great Gatsby': '了不起的盖茨比',
      'F. Scott Fitzgerald': 'F·斯科特·菲茨杰拉德',
      'A classic American novel about the Jazz Age and the American Dream.': '一部关于爵士时代和美国梦的经典美国小说。',
      'Pride and Prejudice': '傲慢与偏见',
      'Jane Austen': '简·奥斯汀',
      'A romantic novel about manners, upbringing, morality, and marriage.': '一部关于礼仪、教养、道德和婚姻的浪漫小说。',
      'Romance': '浪漫',
      'Book Club Discussions': '读书俱乐部讨论',
      'Literary Analysis': '文学分析',
      'Reading Group': '读书小组',
      'Book Summary': '书籍摘要',
      'Chapter Review': '章节回顾',
      'Discussion Topic': '讨论话题',
      'Book Review': '书评',
      'Audio': '音频',
      'Video': '视频',
      'Text': '文本',
      'Image': '图像'
    },
    es: {
      'To Kill a Mockingbird': 'Matar a un ruiseñor',
      'Harper Lee': 'Harper Lee',
      'A gripping tale of racial injustice and childhood innocence in the American South.': 'Una historia fascinante sobre la injusticia racial y la inocencia infantil en el sur de Estados Unidos.',
      'Fiction': 'Ficción',
      'Classic Literature': 'Literatura Clásica',
      'The Great Gatsby': 'El Gran Gatsby',
      'F. Scott Fitzgerald': 'F. Scott Fitzgerald',
      'A classic American novel about the Jazz Age and the American Dream.': 'Una novela americana clásica sobre la Era del Jazz y el Sueño Americano.',
      'Pride and Prejudice': 'Orgullo y Prejuicio',
      'Jane Austen': 'Jane Austen',
      'A romantic novel about manners, upbringing, morality, and marriage.': 'Una novela romántica sobre modales, educación, moralidad y matrimonio.',
      'Romance': 'Romance',
      'Book Club Discussions': 'Discusiones del Club de Lectura',
      'Literary Analysis': 'Análisis Literario',
      'Reading Group': 'Grupo de Lectura',
      'Book Summary': 'Resumen del Libro',
      'Chapter Review': 'Revisión del Capítulo',
      'Discussion Topic': 'Tema de Discusión',
      'Book Review': 'Reseña del Libro',
      'Audio': 'Audio',
      'Video': 'Video',
      'Text': 'Texto',
      'Image': 'Imagen'
    },
    ar: {
      'To Kill a Mockingbird': 'قتل طائر محاكي',
      'Harper Lee': 'هاربر لي',
      'A gripping tale of racial injustice and childhood innocence in the American South.': 'حكاية مثيرة عن الظلم العنصري وبراءة الطفولة في الجنوب الأمريكي.',
      'Fiction': 'خيال',
      'Classic Literature': 'الأدب الكلاسيكي',
      'The Great Gatsby': 'غاتسبي العظيم',
      'F. Scott Fitzgerald': 'ف. سكوت فيتزجيرالد',
      'A classic American novel about the Jazz Age and the American Dream.': 'رواية أمريكية كلاسيكية عن عصر الجاز والحلم الأمريكي.',
      'Pride and Prejudice': 'كبرياء وتحامل',
      'Jane Austen': 'جين أوستن',
      'A romantic novel about manners, upbringing, morality, and marriage.': 'رواية رومانسية عن الآداب والتربية والأخلاق والزواج.',
      'Romance': 'رومانسية',
      'Book Club Discussions': 'مناقشات نادي الكتاب',
      'Literary Analysis': 'التحليل الأدبي',
      'Reading Group': 'مجموعة القراءة',
      'Book Summary': 'ملخص الكتاب',
      'Chapter Review': 'مراجعة الفصل',
      'Discussion Topic': 'موضوع النقاش',
      'Book Review': 'مراجعة الكتاب',
      'Audio': 'صوتي',
      'Video': 'فيديو',
      'Text': 'نص',
      'Image': 'صورة'
    },
    bn: {
      'To Kill a Mockingbird': 'টু কিল আ মকিংবার্ড',
      'Harper Lee': 'হার্পার লি',
      'A gripping tale of racial injustice and childhood innocence in the American South.': 'আমেরিকান দক্ষিণে জাতিগত অন্যায় এবং শৈশবের নির্দোষতার একটি আকর্ষণীয় গল্প।',
      'Fiction': 'কথাসাহিত্য',
      'Classic Literature': 'ক্লাসিক সাহিত্য',
      'The Great Gatsby': 'দ্য গ্রেট গ্যাটসবি',
      'F. Scott Fitzgerald': 'এফ. স্কট ফিটজেরাল্ড',
      'A classic American novel about the Jazz Age and the American Dream.': 'জ্যাজ যুগ এবং আমেরিকান স্বপ্ন সম্পর্কে একটি ক্লাসিক আমেরিকান উপন্যাস।',
      'Pride and Prejudice': 'প্রাইড অ্যান্ড প্রেজুডিস',
      'Jane Austen': 'জেন অস্টেন',
      'A romantic novel about manners, upbringing, morality, and marriage.': 'শিষ্টাচার, লালন-পালন, নৈতিকতা এবং বিবাহ সম্পর্কে একটি রোমান্টিক উপন্যাস।',
      'Romance': 'রোমান্স',
      'Book Club Discussions': 'বুক ক্লাব আলোচনা',
      'Literary Analysis': 'সাহিত্যিক বিশ্লেষণ',
      'Reading Group': 'পাঠ গ্রুপ',
      'Book Summary': 'বইয়ের সারসংক্ষেপ',
      'Chapter Review': 'অধ্যায় পর্যালোচনা',
      'Discussion Topic': 'আলোচনার বিষয়',
      'Book Review': 'বই পর্যালোচনা',
      'Audio': 'অডিও',
      'Video': 'ভিডিও',
      'Text': 'টেক্সট',
      'Image': 'ছবি'
    },
    pt: {
      'To Kill a Mockingbird': 'O Sol é Para Todos',
      'Harper Lee': 'Harper Lee',
      'A gripping tale of racial injustice and childhood innocence in the American South.': 'Uma história cativante sobre injustiça racial e inocência infantil no sul americano.',
      'Fiction': 'Ficção',
      'Classic Literature': 'Literatura Clássica',
      'The Great Gatsby': 'O Grande Gatsby',
      'F. Scott Fitzgerald': 'F. Scott Fitzgerald',
      'A classic American novel about the Jazz Age and the American Dream.': 'Um romance americano clássico sobre a Era do Jazz e o Sonho Americano.',
      'Pride and Prejudice': 'Orgulho e Preconceito',
      'Jane Austen': 'Jane Austen',
      'A romantic novel about manners, upbringing, morality, and marriage.': 'Um romance sobre boas maneiras, educação, moralidade e casamento.',
      'Romance': 'Romance',
      'Book Club Discussions': 'Discussões do Clube do Livro',
      'Literary Analysis': 'Análise Literária',
      'Reading Group': 'Grupo de Leitura',
      'Book Summary': 'Resumo do Livro',
      'Chapter Review': 'Revisão do Capítulo',
      'Discussion Topic': 'Tópico de Discussão',
      'Book Review': 'Resenha do Livro',
      'Audio': 'Áudio',
      'Video': 'Vídeo',
      'Text': 'Texto',
      'Image': 'Imagem'
    },
    ru: {
      'To Kill a Mockingbird': 'Убить пересмешника',
      'Harper Lee': 'Харпер Ли',
      'A gripping tale of racial injustice and childhood innocence in the American South.': 'Захватывающая история о расовой несправедливости и детской невинности на американском Юге.',
      'Fiction': 'Художественная литература',
      'Classic Literature': 'Классическая литература',
      'The Great Gatsby': 'Великий Гэтсби',
      'F. Scott Fitzgerald': 'Ф. Скотт Фицджеральд',
      'A classic American novel about the Jazz Age and the American Dream.': 'Классический американский роман об эпохе джаза и американской мечте.',
      'Pride and Prejudice': 'Гордость и предубеждение',
      'Jane Austen': 'Джейн Остин',
      'A romantic novel about manners, upbringing, morality, and marriage.': 'Романтический роман о манерах, воспитании, морали и браке.',
      'Romance': 'Романтика',
      'Book Club Discussions': 'Обсуждения книжного клуба',
      'Literary Analysis': 'Литературный анализ',
      'Reading Group': 'Группа чтения',
      'Book Summary': 'Краткое содержание книги',
      'Chapter Review': 'Обзор главы',
      'Discussion Topic': 'Тема для обсуждения',
      'Book Review': 'Рецензия на книгу',
      'Audio': 'Аудио',
      'Video': 'Видео',
      'Text': 'Текст',
      'Image': 'Изображение'
    },
    fr: {
      'To Kill a Mockingbird': 'Ne tirez pas sur l\'oiseau moqueur',
      'Harper Lee': 'Harper Lee',
      'A gripping tale of racial injustice and childhood innocence in the American South.': 'Une histoire captivante sur l\'injustice raciale et l\'innocence de l\'enfance dans le Sud américain.',
      'Fiction': 'Fiction',
      'Classic Literature': 'Littérature Classique',
      'The Great Gatsby': 'Gatsby le Magnifique',
      'F. Scott Fitzgerald': 'F. Scott Fitzgerald',
      'A classic American novel about the Jazz Age and the American Dream.': 'Un roman américain classique sur l\'âge du jazz et le rêve américain.',
      'Pride and Prejudice': 'Orgueil et Préjugés',
      'Jane Austen': 'Jane Austen',
      'A romantic novel about manners, upbringing, morality, and marriage.': 'Un roman romantique sur les bonnes manières, l\'éducation, la moralité et le mariage.',
      'Romance': 'Romance',
      'Book Club Discussions': 'Discussions du Club de Lecture',
      'Literary Analysis': 'Analyse Littéraire',
      'Reading Group': 'Groupe de Lecture',
      'Book Summary': 'Résumé du Livre',
      'Chapter Review': 'Révision du Chapitre',
      'Discussion Topic': 'Sujet de Discussion',
      'Book Review': 'Critique de Livre',
      'Audio': 'Audio',
      'Video': 'Vidéo',
      'Text': 'Texte',
      'Image': 'Image'
    }
  };

  // Try to find translation in mock data
  const langTranslations = mockTranslations[targetLang];
  let translatedText = text;
  
  if (langTranslations && langTranslations[text]) {
    translatedText = langTranslations[text];
  } else {
    // For demonstration, we'll use a simple fallback
    // In a real app, you would call a translation API here
    translatedText = text; // Keep original if no translation found
  }

  // Cache the translation
  translationCache.set(cacheKey, translatedText);
  
  return translatedText;
}

// Hook for translating content
export function useContentTranslator() {
  const translateContent = async (text: string | undefined, targetLang: LanguageCode): Promise<string> => {
    if (!text) return '';
    return await translateText(text, targetLang);
  };

  // Translate multiple fields of an object
  const translateObject = async <T extends Record<string, any>>(
    obj: T,
    fieldsToTranslate: (keyof T)[],
    targetLang: LanguageCode
  ): Promise<T> => {
    const translatedObj = { ...obj };
    
    for (const field of fieldsToTranslate) {
      if (obj[field] && typeof obj[field] === 'string') {
        translatedObj[field] = await translateContent(obj[field] as string, targetLang) as T[keyof T];
      }
    }
    
    return translatedObj;
  };

  // Translate an array of objects
  const translateArray = async <T extends Record<string, any>>(
    items: T[],
    fieldsToTranslate: (keyof T)[],
    targetLang: LanguageCode
  ): Promise<T[]> => {
    const translatedItems = await Promise.all(
      items.map(item => translateObject(item, fieldsToTranslate, targetLang))
    );
    
    return translatedItems;
  };

  return {
    translateContent,
    translateObject,
    translateArray
  };
}

// Clear translation cache (useful for memory management)
export function clearTranslationCache(): void {
  translationCache.clear();
}

// Get cache size (for debugging)
export function getTranslationCacheSize(): number {
  return translationCache.size;
}