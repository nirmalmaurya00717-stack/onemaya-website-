import { useLanguageStore, type LanguageCode } from '@/lib/i18n';

// CMS content translation helper
export function useCMSTranslation() {
  const { currentLanguage } = useLanguageStore();
  
  // Helper function to get translated CMS content
  const translateCMSField = (
    originalValue: string | undefined,
    fieldName: string,
    itemId: string
  ): string => {
    if (!originalValue) return '';
    
    // For now, return original value as we're using placeholder translations
    // In a real implementation, you would:
    // 1. Check if translation exists in CMS for this field + language
    // 2. Return translated value if available
    // 3. Fall back to original value
    
    return originalValue;
  };
  
  // Helper to translate book titles
  const translateBookTitle = (title: string | undefined, bookId?: string): string => {
    if (!title) return '';
    
    // Placeholder translations for demo purposes
    const bookTitleTranslations: Record<LanguageCode, Record<string, string>> = {
      en: {},
      zh: {
        'To Kill a Mockingbird': '杀死一只知更鸟',
        '1984': '一九八四',
        'Pride and Prejudice': '傲慢与偏见',
        'The Great Gatsby': '了不起的盖茨比',
      },
      hi: {
        'To Kill a Mockingbird': 'टू किल ए मॉकिंगबर्ड',
        '1984': '१९८४',
        'Pride and Prejudice': 'प्राइड एंड प्रेजुडिस',
        'The Great Gatsby': 'द ग्रेट गैट्सबी',
      },
      es: {
        'To Kill a Mockingbird': 'Matar a un ruiseñor',
        '1984': '1984',
        'Pride and Prejudice': 'Orgullo y prejuicio',
        'The Great Gatsby': 'El gran Gatsby',
      },
      ar: {
        'To Kill a Mockingbird': 'قتل طائر الحسون',
        '1984': '١٩٨٤',
        'Pride and Prejudice': 'الكبرياء والتحامل',
        'The Great Gatsby': 'غاتسبي العظيم',
      },
      bn: {
        'To Kill a Mockingbird': 'টু কিল এ মকিংবার্ড',
        '1984': '১৯৮৪',
        'Pride and Prejudice': 'প্রাইড অ্যান্ড প্রেজুডিস',
        'The Great Gatsby': 'দ্য গ্রেট গ্যাটসবি',
      },
      pt: {
        'To Kill a Mockingbird': 'O Sol é Para Todos',
        '1984': '1984',
        'Pride and Prejudice': 'Orgulho e Preconceito',
        'The Great Gatsby': 'O Grande Gatsby',
      },
      ru: {
        'To Kill a Mockingbird': 'Убить пересмешника',
        '1984': '1984',
        'Pride and Prejudice': 'Гордость и предубеждение',
        'The Great Gatsby': 'Великий Гэтсби',
      },
      fr: {
        'To Kill a Mockingbird': 'Ne tirez pas sur l\'oiseau moqueur',
        '1984': '1984',
        'Pride and Prejudice': 'Orgueil et Préjugés',
        'The Great Gatsby': 'Gatsby le Magnifique',
      },
    };
    
    const translations = bookTitleTranslations[currentLanguage];
    return translations?.[title] || title;
  };
  
  // Helper to translate author names
  const translateAuthorName = (author: string | undefined): string => {
    if (!author) return '';
    
    // Most author names remain the same across languages
    // Only translate if there's a commonly used translated version
    const authorTranslations: Record<LanguageCode, Record<string, string>> = {
      en: {},
      zh: {},
      hi: {},
      es: {},
      ar: {},
      bn: {},
      pt: {},
      ru: {},
      fr: {},
    };
    
    const translations = authorTranslations[currentLanguage];
    return translations?.[author] || author;
  };
  
  // Helper to translate genre names
  const translateGenre = (genre: string | undefined): string => {
    if (!genre) return '';
    
    const genreTranslations: Record<LanguageCode, Record<string, string>> = {
      en: {},
      zh: {
        'Fiction': '小说',
        'Non-Fiction': '非小说',
        'Mystery': '悬疑',
        'Romance': '爱情',
        'Science Fiction': '科幻',
        'Fantasy': '奇幻',
        'Biography': '传记',
        'History': '历史',
      },
      hi: {
        'Fiction': 'कथा साहित्य',
        'Non-Fiction': 'गैर-कथा',
        'Mystery': 'रहस्य',
        'Romance': 'प्रेम कहानी',
        'Science Fiction': 'विज्ञान कथा',
        'Fantasy': 'कल्पना',
        'Biography': 'जीवनी',
        'History': 'इतिहास',
      },
      es: {
        'Fiction': 'Ficción',
        'Non-Fiction': 'No ficción',
        'Mystery': 'Misterio',
        'Romance': 'Romance',
        'Science Fiction': 'Ciencia ficción',
        'Fantasy': 'Fantasía',
        'Biography': 'Biografía',
        'History': 'Historia',
      },
      ar: {
        'Fiction': 'خيال',
        'Non-Fiction': 'غير خيالي',
        'Mystery': 'غموض',
        'Romance': 'رومانسي',
        'Science Fiction': 'خيال علمي',
        'Fantasy': 'فانتازيا',
        'Biography': 'سيرة ذاتية',
        'History': 'تاريخ',
      },
      bn: {
        'Fiction': 'কথাসাহিত্য',
        'Non-Fiction': 'অকথাসাহিত্য',
        'Mystery': 'রহস্য',
        'Romance': 'প্রেমের গল্প',
        'Science Fiction': 'বিজ্ঞান কল্পকাহিনী',
        'Fantasy': 'ফ্যান্টাসি',
        'Biography': 'জীবনী',
        'History': 'ইতিহাস',
      },
      pt: {
        'Fiction': 'Ficção',
        'Non-Fiction': 'Não ficção',
        'Mystery': 'Mistério',
        'Romance': 'Romance',
        'Science Fiction': 'Ficção científica',
        'Fantasy': 'Fantasia',
        'Biography': 'Biografia',
        'History': 'História',
      },
      ru: {
        'Fiction': 'Художественная литература',
        'Non-Fiction': 'Документальная литература',
        'Mystery': 'Детектив',
        'Romance': 'Романтика',
        'Science Fiction': 'Научная фантастика',
        'Fantasy': 'Фэнтези',
        'Biography': 'Биография',
        'History': 'История',
      },
      fr: {
        'Fiction': 'Fiction',
        'Non-Fiction': 'Non-fiction',
        'Mystery': 'Mystère',
        'Romance': 'Romance',
        'Science Fiction': 'Science-fiction',
        'Fantasy': 'Fantaisie',
        'Biography': 'Biographie',
        'History': 'Histoire',
      },
    };
    
    const translations = genreTranslations[currentLanguage];
    return translations?.[genre] || genre;
  };
  
  return {
    translateCMSField,
    translateBookTitle,
    translateAuthorName,
    translateGenre,
    currentLanguage,
  };
}

// Helper function to format dates according to language locale
export function formatDateForLanguage(
  date: Date | string | undefined,
  language: LanguageCode
): string {
  if (!date) return '';
  
  const d = new Date(date);
  
  const localeMap: Record<LanguageCode, string> = {
    en: 'en-US',
    zh: 'zh-CN',
    hi: 'hi-IN',
    es: 'es-ES',
    ar: 'ar-SA',
    bn: 'bn-BD',
    pt: 'pt-BR',
    ru: 'ru-RU',
    fr: 'fr-FR',
  };
  
  try {
    return d.toLocaleDateString(localeMap[language], {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  } catch {
    // Fallback to English if locale is not supported
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  }
}