// Re-export from main entities file for backward compatibility
export type { DiscussionTopics } from './index';
