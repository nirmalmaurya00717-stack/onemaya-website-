/**
 * Auto-generated entity types
 * Contains all CMS collection interfaces in a single file 
 */

/**
 * Collection ID: academiccourses
 * Interface for AcademicCourses
 */
export interface AcademicCourses {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  courseName?: string;
  /** @wixFieldType text */
  courseCode?: string;
  /** @wixFieldType text */
  department?: string;
  /** @wixFieldType number */
  durationYears?: number;
  /** @wixFieldType boolean */
  isUndergraduate?: boolean;
  /** @wixFieldType text */
  courseDescription?: string;
}


/**
 * Collection ID: adminauditlogs
 * Interface for AdminAuditLogs
 */
export interface AdminAuditLogs {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  adminEmail?: string;
  /** @wixFieldType datetime */
  loginTime?: Date | string;
  /** @wixFieldType text */
  location?: string;
  /** @wixFieldType text */
  deviceInfo?: string;
  /** @wixFieldType text */
  ipAddress?: string;
  /** @wixFieldType text */
  loginStatus?: string;
  /** @wixFieldType text */
  failureReason?: string;
}


/**
 * Collection ID: bookdiscussionvideos
 * Interface for BookDiscussionVideos
 */
export interface BookDiscussionVideos {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  videoTitle?: string;
  /** @wixFieldType url */
  videoUrl?: string;
  /** @wixFieldType text */
  description?: string;
  /** @wixFieldType image */
  thumbnail?: string;
  /** @wixFieldType date */
  uploadDate?: Date | string;
  /** @wixFieldType text */
  associatedTopic?: string;
}


/**
 * Collection ID: bookreadinggroups
 * Interface for BookReadingGroups
 */
export interface BookReadingGroups {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  groupName?: string;
  /** @wixFieldType text */
  description?: string;
  /** @wixFieldType text */
  currentBook?: string;
  /** @wixFieldType text */
  bookAuthor?: string;
  /** @wixFieldType image */
  bookCover?: string;
  /** @wixFieldType boolean */
  isPublic?: boolean;
  /** @wixFieldType datetime */
  creationDate?: Date | string;
}


/**
 * Collection ID: contentpurchases
 * Interface for ContentPurchases
 */
export interface ContentPurchases {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  userId?: string;
  /** @wixFieldType text */
  contentId?: string;
  /** @wixFieldType datetime */
  purchaseDate?: Date | string;
  /** @wixFieldType number */
  pricePaid?: number;
  /** @wixFieldType text */
  accessStatus?: string;
}


/**
 * Collection ID: contentratings
 * Interface for ContentRatings
 */
export interface ContentRatings {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  contentId?: string;
  /** @wixFieldType text */
  userId?: string;
  /** @wixFieldType number */
  rating?: number;
  /** @wixFieldType text */
  feedbackText?: string;
  /** @wixFieldType datetime */
  submissionDate?: Date | string;
}


/**
 * Collection ID: creatorprofiles
 * Interface for CreatorProfiles
 */
export interface CreatorProfiles {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  userId?: string;
  /** @wixFieldType number */
  totalEarnings?: number;
  /** @wixFieldType text */
  badges?: string;
  /** @wixFieldType number */
  leaderboardRank?: number;
  /** @wixFieldType boolean */
  isPaidCreator?: boolean;
  /** @wixFieldType image */
  profilePicture?: string;
}


/**
 * Collection ID: discussiontopics
 * Interface for DiscussionTopics
 */
export interface DiscussionTopics {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  topicTitle?: string;
  /** @wixFieldType text */
  topicContent?: string;
  /** @wixFieldType datetime */
  creationDate?: Date | string;
  /** @wixFieldType datetime */
  lastUpdatedDate?: Date | string;
  /** @wixFieldType boolean */
  isPinned?: boolean;
  /** @wixFieldType number */
  viewCount?: number;
}


/**
 * Collection ID: livediscussionsessions
 * Interface for LiveDiscussionSessions
 */
export interface LiveDiscussionSessions {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  sessionTopic?: string;
  /** @wixFieldType date */
  sessionDate?: Date | string;
  /** @wixFieldType time */
  sessionTime?: any;
  /** @wixFieldType text */
  discussedBook?: string;
  /** @wixFieldType number */
  maxParticipants?: number;
  /** @wixFieldType url */
  sessionLink?: string;
  /** @wixFieldType text */
  sessionDescription?: string;
}


/**
 * Collection ID: paymenttransactions
 * Interface for PaymentTransactions
 */
export interface PaymentTransactions {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType number */
  amount?: number;
  /** @wixFieldType text */
  currency?: string;
  /** @wixFieldType datetime */
  transactionDateTime?: Date | string;
  /** @wixFieldType text */
  status?: string;
  /** @wixFieldType text */
  userId?: string;
  /** @wixFieldType text */
  purpose?: string;
}


/**
 * Collection ID: popularbooks
 * Interface for PopularBooks
 */
export interface PopularBooks {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType url */
  downloadLink?: string;
  /** @wixFieldType text */
  title?: string;
  /** @wixFieldType text */
  author?: string;
  /** @wixFieldType text */
  genre?: string;
  /** @wixFieldType number */
  averageRating?: number;
  /** @wixFieldType number */
  publicationYear?: number;
  /** @wixFieldType text */
  synopsis?: string;
  /** @wixFieldType image */
  coverImage?: string;
  /** @wixFieldType document */
  document?: string;
}


/**
 * Collection ID: userbooksubmissions
 * Interface for UserBookSubmissions
 */
export interface UserBookSubmissions {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType number */
  ratingCount?: number;
  /** @wixFieldType text */
  moderationStatus?: string;
  /** @wixFieldType url */
  discussionVideoUrl?: string;
  /** @wixFieldType url */
  pdfNotesUrl?: string;
  /** @wixFieldType number */
  price?: number;
  /** @wixFieldType boolean */
  isPremium?: boolean;
  /** @wixFieldType text */
  submissionTitle?: string;
  /** @wixFieldType number */
  averageRating?: number;
  /** @wixFieldType image */
  imageSubmission?: string;
  /** @wixFieldType url */
  audioSubmission?: string;
  /** @wixFieldType text */
  submissionType?: string;
  /** @wixFieldType text */
  content?: string;
  /** @wixFieldType text */
  bookTitle?: string;
  /** @wixFieldType text */
  bookAuthor?: string;
  /** @wixFieldType datetime */
  submissionDate?: Date | string;
  /** @wixFieldType text */
  submittedBy?: string;
  /** @wixFieldType array_document */
  arraydocument?: any;
  /** @wixFieldType document */
  document?: string;
}


/**
 * Collection ID: userfeedback
 * Interface for UserFeedback
 */
export interface UserFeedback {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  featureName?: string;
  /** @wixFieldType number */
  rating?: number;
  /** @wixFieldType text */
  comment?: string;
  /** @wixFieldType text */
  userName?: string;
  /** @wixFieldType text */
  userEmail?: string;
  /** @wixFieldType datetime */
  submissionDateTime?: Date | string;
  /** @wixFieldType text */
  feedbackType?: string;
}


/**
 * Collection ID: usersubscriptions
 * Interface for UserSubscriptions
 */
export interface UserSubscriptions {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType boolean */
  isCreatorUpgrade?: boolean;
  /** @wixFieldType text */
  userEmail?: string;
  /** @wixFieldType text */
  subscriptionType?: string;
  /** @wixFieldType date */
  startDate?: Date | string;
  /** @wixFieldType date */
  expiryDate?: Date | string;
  /** @wixFieldType text */
  paymentStatus?: string;
  /** @wixFieldType number */
  amountPaid?: number;
}
