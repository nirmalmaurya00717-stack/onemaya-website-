import { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';

interface UseExitFeedbackOptions {
  featureName: string;
  triggerOnRouteChange?: boolean;
  triggerOnBeforeUnload?: boolean;
  cooldownMinutes?: number;
}

export function useExitFeedback({
  featureName,
  triggerOnRouteChange = true,
  triggerOnBeforeUnload = true,
  cooldownMinutes = 30
}: UseExitFeedbackOptions) {
  const [showFeedbackPrompt, setShowFeedbackPrompt] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);
  const location = useLocation();

  // Track user interaction with the feature
  const trackInteraction = useCallback(() => {
    setHasInteracted(true);
  }, []);

  // Check if feedback was recently given for this feature
  const shouldShowFeedback = useCallback(() => {
    const lastFeedbackKey = `lastFeedback_${featureName}`;
    const lastFeedbackTime = localStorage.getItem(lastFeedbackKey);
    
    if (!lastFeedbackTime) return true;
    
    const timeDiff = Date.now() - parseInt(lastFeedbackTime);
    const cooldownMs = cooldownMinutes * 60 * 1000;
    
    return timeDiff > cooldownMs;
  }, [featureName, cooldownMinutes]);

  // Handle route change
  useEffect(() => {
    if (!triggerOnRouteChange || !hasInteracted || !shouldShowFeedback()) return;

    const handleRouteChange = () => {
      setShowFeedbackPrompt(true);
    };

    // Trigger on route change (when location changes)
    return () => {
      if (hasInteracted) {
        handleRouteChange();
      }
    };
  }, [location, hasInteracted, triggerOnRouteChange, shouldShowFeedback]);

  // Handle browser close/refresh
  useEffect(() => {
    if (!triggerOnBeforeUnload || !hasInteracted || !shouldShowFeedback()) return;

    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      // Note: Modern browsers don't allow custom messages in beforeunload
      // We'll show the feedback prompt when they return to the page
      localStorage.setItem(`pendingFeedback_${featureName}`, 'true');
      e.preventDefault();
      e.returnValue = '';
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [hasInteracted, triggerOnBeforeUnload, featureName, shouldShowFeedback]);

  // Check for pending feedback on mount
  useEffect(() => {
    const pendingFeedbackKey = `pendingFeedback_${featureName}`;
    const hasPendingFeedback = localStorage.getItem(pendingFeedbackKey);
    
    if (hasPendingFeedback && shouldShowFeedback()) {
      setShowFeedbackPrompt(true);
      localStorage.removeItem(pendingFeedbackKey);
    }
  }, [featureName, shouldShowFeedback]);

  const closeFeedbackPrompt = useCallback(() => {
    setShowFeedbackPrompt(false);
    setHasInteracted(false);
    
    // Record that feedback was requested (even if not given)
    const lastFeedbackKey = `lastFeedback_${featureName}`;
    localStorage.setItem(lastFeedbackKey, Date.now().toString());
  }, [featureName]);

  return {
    showFeedbackPrompt,
    trackInteraction,
    closeFeedbackPrompt,
    hasInteracted
  };
}