import { useState, useEffect } from 'react';
import { useMember } from '@/integrations';
import { BaseCrudService } from '@/integrations';
import { UserSubscriptions } from '@/entities';

export interface SubscriptionStatus {
  isActive: boolean;
  subscriptionType: 'free' | 'month1' | 'month2' | 'expired';
  daysRemaining: number;
  canUpgrade: boolean;
  nextPlan?: 'month1' | 'month2';
  currentPlan: string;
}

export function useSubscription() {
  const { member, isAuthenticated } = useMember();
  const [subscription, setSubscription] = useState<UserSubscriptions | null>(null);
  const [status, setStatus] = useState<SubscriptionStatus | null>(null);
  const [loading, setLoading] = useState(true);

  const calculateStatus = (sub: UserSubscriptions): SubscriptionStatus => {
    const now = new Date();
    const expiryDate = new Date(sub.expiryDate || '');
    const daysRemaining = Math.max(0, Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
    
    const isActive = daysRemaining > 0;
    const subscriptionType = sub.subscriptionType as 'free' | 'month1' | 'month2' | 'expired';
    
    let canUpgrade = false;
    let nextPlan: 'month1' | 'month2' | undefined;
    
    if (subscriptionType === 'free' && !isActive) {
      canUpgrade = true;
      nextPlan = 'month1';
    } else if (subscriptionType === 'month1' && !isActive) {
      canUpgrade = true;
      nextPlan = 'month2';
    }
    
    const currentPlan = subscriptionType === 'free' ? '60 Days Free Trial' :
                      subscriptionType === 'month1' ? 'Month 1 Plan (₹49)' :
                      subscriptionType === 'month2' ? 'Month 2 Plan (₹49)' :
                      'Subscription Expired';

    return {
      isActive,
      subscriptionType: isActive ? subscriptionType : 'expired',
      daysRemaining,
      canUpgrade,
      nextPlan,
      currentPlan
    };
  };

  const loadSubscription = async () => {
    if (!isAuthenticated || !member?.loginEmail) {
      setLoading(false);
      return;
    }

    try {
      // Try to find existing subscription
      const { items } = await BaseCrudService.getAll<UserSubscriptions>('usersubscriptions');
      const userSub = items.find(sub => sub.userEmail === member.loginEmail);
      
      if (userSub) {
        setSubscription(userSub);
        setStatus(calculateStatus(userSub));
      } else {
        // Create new free trial subscription
        const newSub = await createFreeTrialSubscription();
        setSubscription(newSub);
        setStatus(calculateStatus(newSub));
      }
    } catch (error) {
      console.error('Error loading subscription:', error);
    } finally {
      setLoading(false);
    }
  };

  const createFreeTrialSubscription = async (): Promise<UserSubscriptions> => {
    const startDate = new Date();
    const expiryDate = new Date();
    expiryDate.setDate(startDate.getDate() + 60); // 60 days free trial

    const newSubscription: UserSubscriptions = {
      _id: crypto.randomUUID(),
      userEmail: member?.loginEmail,
      subscriptionType: 'free',
      startDate: startDate.toISOString(),
      expiryDate: expiryDate.toISOString(),
      paymentStatus: 'free',
      amountPaid: 0
    };

    return await BaseCrudService.create('usersubscriptions', newSubscription);
  };

  const upgradeSubscription = async (planType: 'month1' | 'month2'): Promise<boolean> => {
    if (!subscription || !member?.loginEmail) return false;

    try {
      const startDate = new Date();
      const expiryDate = new Date();
      expiryDate.setDate(startDate.getDate() + 30); // 30 days for paid plans

      const updatedSubscription: UserSubscriptions = {
        ...subscription,
        subscriptionType: planType,
        startDate: startDate.toISOString(),
        expiryDate: expiryDate.toISOString(),
        paymentStatus: 'paid',
        amountPaid: 49
      };

      await BaseCrudService.update('usersubscriptions', updatedSubscription);
      setSubscription(updatedSubscription);
      setStatus(calculateStatus(updatedSubscription));
      return true;
    } catch (error) {
      console.error('Error upgrading subscription:', error);
      return false;
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadSubscription();
    } else {
      setLoading(false);
      setSubscription(null);
      setStatus(null);
    }
  }, [isAuthenticated, member?.loginEmail]);

  return {
    subscription,
    status,
    loading,
    upgradeSubscription,
    refreshSubscription: loadSubscription
  };
}