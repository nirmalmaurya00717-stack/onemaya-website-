import { useEffect, useRef } from 'react';

interface ScreenshotProtectionOptions {
  enableBlur?: boolean;
  enableWatermark?: boolean;
  enableKeyboardBlocking?: boolean;
  enableDevToolsBlocking?: boolean;
  enableRightClickBlocking?: boolean;
  showWarningMessage?: boolean;
}

export function useScreenshotProtection(options: ScreenshotProtectionOptions = {}) {
  const {
    enableBlur = true,
    enableWatermark = true,
    enableKeyboardBlocking = true,
    enableDevToolsBlocking = true,
    enableRightClickBlocking = true,
    showWarningMessage = true
  } = options;

  const warningShownRef = useRef(false);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (enableBlur && document.hidden) {
        // Blur content when tab becomes hidden (potential screenshot)
        document.body.style.filter = 'blur(10px)';
        document.body.style.transition = 'filter 0.1s';
      } else if (enableBlur) {
        document.body.style.filter = 'none';
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!enableKeyboardBlocking) return;

      // Block common screenshot shortcuts
      const blockedCombinations = [
        // Print Screen
        e.key === 'PrintScreen',
        // Alt + Print Screen
        e.altKey && e.key === 'PrintScreen',
        // Ctrl + Shift + S (Firefox screenshot)
        e.ctrlKey && e.shiftKey && e.key === 'S',
        // Cmd + Shift + 3/4/5 (Mac screenshots)
        e.metaKey && e.shiftKey && ['3', '4', '5'].includes(e.key),
        // F12 (Dev tools)
        e.key === 'F12',
        // Ctrl + Shift + I (Dev tools)
        e.ctrlKey && e.shiftKey && e.key === 'I',
        // Ctrl + Shift + J (Console)
        e.ctrlKey && e.shiftKey && e.key === 'J',
        // Ctrl + U (View source)
        e.ctrlKey && e.key === 'u',
        // Ctrl + Shift + C (Inspect element)
        e.ctrlKey && e.shiftKey && e.key === 'C'
      ];

      if (blockedCombinations.some(blocked => blocked)) {
        e.preventDefault();
        e.stopPropagation();
        
        if (showWarningMessage && !warningShownRef.current) {
          alert('Screenshots and developer tools are disabled to protect content.');
          warningShownRef.current = true;
          // Reset warning after 5 seconds
          setTimeout(() => {
            warningShownRef.current = false;
          }, 5000);
        }
        
        return false;
      }
    };

    const handleRightClick = (e: MouseEvent) => {
      if (enableRightClickBlocking) {
        e.preventDefault();
        if (showWarningMessage && !warningShownRef.current) {
          alert('Right-click is disabled to protect content.');
          warningShownRef.current = true;
          setTimeout(() => {
            warningShownRef.current = false;
          }, 3000);
        }
        return false;
      }
    };

    const handleDevToolsDetection = () => {
      if (!enableDevToolsBlocking) return;

      let devtools = {
        open: false,
        orientation: null as string | null
      };

      const threshold = 160;

      setInterval(() => {
        if (
          window.outerHeight - window.innerHeight > threshold ||
          window.outerWidth - window.innerWidth > threshold
        ) {
          if (!devtools.open) {
            devtools.open = true;
            if (showWarningMessage) {
              alert('Developer tools detected. Please close them to continue.');
            }
            // Blur the page when dev tools are open
            document.body.style.filter = 'blur(10px)';
          }
        } else {
          if (devtools.open) {
            devtools.open = false;
            document.body.style.filter = 'none';
          }
        }
      }, 500);
    };

    // Add event listeners
    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('keydown', handleKeyDown, true);
    document.addEventListener('contextmenu', handleRightClick);

    // Start dev tools detection
    if (enableDevToolsBlocking) {
      handleDevToolsDetection();
    }

    // Add watermark if enabled
    if (enableWatermark) {
      const watermark = document.createElement('div');
      watermark.innerHTML = 'PROTECTED CONTENT';
      watermark.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) rotate(-45deg);
        font-size: 48px;
        color: rgba(0, 0, 0, 0.1);
        pointer-events: none;
        z-index: 9999;
        user-select: none;
        font-weight: bold;
        white-space: nowrap;
      `;
      document.body.appendChild(watermark);

      return () => {
        document.removeEventListener('visibilitychange', handleVisibilityChange);
        document.removeEventListener('keydown', handleKeyDown, true);
        document.removeEventListener('contextmenu', handleRightClick);
        document.body.removeChild(watermark);
        document.body.style.filter = 'none';
      };
    }

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('keydown', handleKeyDown, true);
      document.removeEventListener('contextmenu', handleRightClick);
      document.body.style.filter = 'none';
    };
  }, [enableBlur, enableWatermark, enableKeyboardBlocking, enableDevToolsBlocking, enableRightClickBlocking, showWarningMessage]);
}